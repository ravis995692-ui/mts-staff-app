const APP_CONFIG = {"url": "https://xvctfmxavqzkslhwfxia.supabase.co", "key": "sb_publishable_u_5dJzH4_ih65HdWUaMZ9g_LWkVro2R", "siteUrl": "https://ravis995692-ui.github.io/mts-staff-app/"};
const LOGO_SRC = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJ0AAACgCAYAAAAWwm6lAAA6BklEQVR42u29d3hU17W4/e59zhRVVFBFSBTRRDUdAwYbY1xw745L7LjGdpz6S/IlTm7azU1u4tzYjh33GDs2Nsa9YBvbYDqIDqIJJCGh3tuUU/b3x4wEGDDSjCTA0XqeeSSN5uxzZp/3rL33WmuvBb3SK73SK73SK73SxaL1dkHnZVCqPjE+UvwuIVY/VNdsl/X2SK90qwxM1a7tn0B1ZiKqfwLVA1O1a3t7pVe6RSaAY2CS9pvUWMwLZ41Vby56Wc2bNValxmIOTNF+MwEcvb3UK103nKa5M7MSxXtpfVB33XKlqqwoV0opVVlRpr5z8+UqrQ8qK1G8NyjNndnbW70S/nCaol3aL57Cwaku9fe//E6ZhqGOFMMw1N/+/Bs1KNWp+sVTODBFu7S313olJMlOIHZAkngkNQZz5sQhatlnS9TXyRdLP1IzJgxWqbGYA5LEI4Pi6dPbi73SYRmcop2bkcDmjATUg3d/S5WXHVIdkfKyQ+r+u25UGfGojAQ2D07Rzu3tzV75WklPJ3FAkvhragy+iSPT1aJX/6VCkdf+/byakJOmUmPxDUgSj6Snk9jbu71yPFPINf3i2dU/EfXdO29QB4sOqHCkqHC/uu+O61T/BFS/eHYPTNWu6e3lXgmsTFMcozL7isWpsahzJg1V7731mupKeefNV9U5k4ao1FhUZl/x5qAUx6jeXv+PhY3kAcnij6mxNAzrH61+/6ufqJrqKtUdUlNdpX7/qx+rYf2jVVosDQOSxX8PTCal9y78h0hOEtEDUuSD6X0ozEwU6vabLlXbtuSqnpBtW3LVt2+crzIThUrvQ9GAFPm9nCSie+/KN9UEko1rQKq8tV882/rFoeafP0kt+eAtdSrk4w/fVpfNnaL6xaH6xbF9QKq8LSsLd+9d+gbBNihZ3tQvng1pfVDnTh2hXlnwjPJ6POpUis/nVQtffk7NOXukSuuD6hdP7sBk+a1e+M7wYTQrRX67Xzwb0/qgZk4cop576u+qsaFenU7S1NSgXnjmMTVr8rA2+DYNSpG39w67Z5LpI5mUrGT5/X5x5KX3Qc2eMlw998+/q/q6WnU6S0NDnXrhmcfUedNyVHocKj2OvKxk+YPeBcfpbvpIEn9Ji+VQ/wTUxedOUK8seFo1NTaoM0mamxrVwpefU5fMmaT6J6LSYjmU2Vf8pdfUcppIRgYRA1O0+f0TeCslhtbsNJe6+Zp56qP33lQ+r1edyeLz+dTHH76tbrnuIpWd7lIpMbT2T+TNgSna/IwMIs7k+ybOyCG0r3OojXmtYdg3KsXItPQU5l18Jdd963bGjZ/8jXu4tmxaz+v/foGPP3yLstIKhGCn7pILNV1/vaDUv7cXum6SoWn09VlyrmXaN5kGs90RWvTosRO44uqbuPiya0hN6/eN1+zlZYf48N03eHvxq+zYmovHYzXrDpY5dLnQodkf7y2juhe6LggvMpzadNuwrjUM5mmS9Iz+Gcw+/2KuuPomJk6Zjq7rp+TaampaSEyMOiXnNk2TjetX89Yb/2bZ0g8pKS7Bsil1OFji0LU38VsrD9TR0AtdByUzk3jh16Yq07rC8DMXwcC+SQlMnjqTSy67llnnXUBCYtIpvcaXXsrl6WfXctedU7n1lomn9Fpqa6r5ctknvPfWa2xYu5Lq6lpQFDqcfKzr2rum01pz8CB1vdB9RQan09+y5NmWYc83TGYJQf++feMZN2EqF1x4GbPmXEj/zAGn/Dpr61r53//9grff2YGmSWzb5vLLRvGTH59LQkLkKb++koOFLP/iEz7+4C02b1xLbU09tqLEobNMc8j3dd1elX+Ikv9I6HKSiG4R+iiUfa5h2OdbFuMdOnHJKSmMmzCFORfMZ+bs8+mfOfC0eTrXrSviD3/8jD17K4lwH96D4/EYDBuWzC9+fj5Tppw+WyQOFh1g9Yov+OyT99mUu4bK8goMkzpdY6PukJ8JKb+ItM2deVU0fyOhy0kiusXhGIJhTbUse7ZpMAnBgKgop8gamM2kKTOYdd48JkyaRnJK2mk13Le0+nnmmbW8uCAXv9/E4Th2q7BhWDidOrfdOpG77pxKVJTztPoOlRXlbNywmi8//5gN61ZSWJBPS4tfoSjQHWzQdLkMXVvntYy9FRW0nJHQZSWRitSGK1tNtE17mmkyDshyu6WWmt6PUaPHM2X6bCZPncHQ4SNxu09Ps9O6dQf56yPL2LqtFJdLR8oTd5dtK3w+kzFj0vjxj85lyuTTc2OY1+th7+6drFuzgrWrlrFz+yYqykrxem0TKNJ1NmtSrhUOmStsc3dBJRWnG3R6/0SSHVIfZAl7lGXa4y2LMbZFtpQkRkY6SEnrx4icMUyYfDbjJ05jWM4o4uISTuslfWVlM089vYbFb27D77dwOjueCKHt89dcPYa775pGcvLp7UKtr6tlz64dbNywmo0bVrNn1w7Ky0pobTGwFdVSkq9pbNN0uVlTcodhmwcG1VC5HMweg25Aqj5LWdZ5hqlylMUQ2yZTSuJdbkl8fCL9MwcyPGcMY8dPYuTosxg0eCgxsWfGxiifz+Stt7fz7HPrKC6ux+3WEaLzz6VSCq/XpH//OO76zlSuvHJ0p8A9ldLU2EDBgX3s3L6ZrZs3sDtvO8VFB6itrcbntbFt6qSkWEj2OhwiT2ja54Xl5vJugy47G5fZqO1wOZ3ZSSlp9MvIYsiwEQwfMYYhw0cyYOBg+ialIKXkTJMvluXz1NNr2Lq1FE2T6LrsAnuajWXZnDWuH/fcPY1Zswafcf2ilKK6qoKigv3s2b2TPbu2k793FyUHC6isKMPn9+frsdao/Hx83QJdWhqRtLDz4ssuG/B/T75MdHQMZ7qs33CQ555fz6rVBdiW6haN5PdbaJpgxvSB3HHHFCZN7H/G91tLcxMP3XczH777biFRjCwro7XDc7LOnCjWj1avkLGxfc544NavP8iCl3JZsfJAcB6mo3fTCOh0aigFy5bvZ/WaImadM4hbbpl4RsMXFR1DTGwfbIWM86N1JnVVp6AzbCSgSe3MzDBmmjYrVxXwyqubWLeuqH3S73J1vytNCHC5dJRSfLp0L8u/3M+0aQO46YbxnH32gC4ZzntaNKkBaEEuugc6MwZJHZqun1kJihoavCxdupc3Fm9l+45yLMvG6dR7BLZj4RNB+GD58v2sXFnAmDFpXHP1WM6fM4TY2DMnWj3o99aCXHQPdJEm0gtSO0M03d69Vbz/QR4ff7yHg8V1SClwOLTTQqsc1nywZUspmzcf4umn47noouFccnEO2dl9T39Np+sokKbZnZrORorTHLra2lZWrirggw/y2LiphKZmHw6Hdkq0Wkfha1u8lBxq4Il/rublf29i4sT+XHLxCKafPZD4+NPTeK5pGgJkZHcOr5aNRCFPtzldS4ufTZtL+PTTvaxaXUBpaSMIcDq0o/ykXWlGME0bXZch2fFOPFwFTDV+v8myZfksW5ZPv/Q+TJ8+kAvmDmXcuH6nlYtNSg0UwupO6GyFAISUpx66+gYP27aVsWzZftauK+TgwXpM08bhkN2q1fx+C7dbZ+TINHbvrsDrNbvczNI27wOoqGzitde3sPjNbWT2j2PylExmz8pm7Nh04uMiTjF0EkAGuege6FQbdKLng1MsW3HwYB2bN5Wwek0hW7aWUl7eiGmqdg3RnXM1y7IxDIsxY9J56MGZTJ06gDVrC3n0sRVs21aKw6GhabIbhjDZ3u7B4noOFNSyaNFWUlNjGTs2nelnD2D8+Awy+8ejaeJUQCdUT0AnesDjYFk2ZeVN7N5VQe6mErZsPsSBghoaG30I0TYUaXR34LBS4PMZ9O0bzR23T+bGG84iIiIwZM+YPpAJ4zN4deFmnn9hPdXVzbhcDrrrmTzywaqsbOKjj3bx4Ye7iI11MXBgImeN68eE8RmMGJFCWlpMtzwER2tkeSQX3QOdWyH8QfXf5cNlvYeSQw3s3VPJth1l5OVVUFxcT0ODF9u22594t7vnFgSGYSGl4LJLR3H/d6eTlRV/zGciIhzccftk5pw3hH88sYqPluzCttVxQ6C6SwN6vSY7dpSxdeshFryUS2ysm8zMOEbmpDJqVCpDhyaRkRHX5cNxkIPu1XRdFZpi24rc3GJ27a7kwIEaCgprOFTSQE1tK16vGexUgabJ4HypZ+eQtq3w+U1G5aTy4IMzmd0Bn2lWVjx//tN8Lr54BI89voIdO8txOb8+HKrrhjmBlFo76K2tfnbuLGfbtoCfwO3WSUiIpF96HwYMTGDwoERGjEhh0sT+4V1f8NDOotwp6DxtQ04XTMYf/vUS9u+vRtc1pBRomkDKntVkxx9KTRISIrj/luncfPOE464WlVLsP1DD4EGJx2j92bMGM2lif17+90ZeXJBLbW0rLpdOT06DD0N4+HtVVTVTXt7EhtxiTNNi8OC+vPPWHV3S357uhO6ouxOmJpFS4HY7Thv3j2FYCCG46MLhPPDADAYPSjwubCtXFfDiixvYuOkQE8b347bbJjFj+sCj4IuKcnLP3dOYe/5QHvvHSj79dC9Kdf+Q+3W2wMBwTNAdKJFSYNsq/Kc00L7qNuiCjSsV9rUqbFshToNtQW0Rv8OHJfPAAzOYe/7Q417vipUFLFiwgXXrD2KaNk6nxqrVhaxbf5ApkzO59dZJzJxxNHyDBiXyt79eztLP9vLY4yvZvbvypBHIPQWhslXYNzJ4fKcbCQk6W9lhX2zY5HbRUNqnj5u775rKbbdOIibGdSxsKwp4ccEG1m9og03H5Qpo5zY3Vht8kydlctutk5g582j4zp8zlCmTs3hxwQZe/vdG6uu9PT7kHmtzDf8e2LYNoLpV02kSG1C2ZYV9w5WtTulQCjD3/KE8+MAMhg5NOkb7rVh5gBcX5LJ+/UEs28bpOAzbiXyoq9cG4ZucyW23TmTmjEHtWi0mxsUD98/ggguG8dhjK/n8i30Ap2zIDTz4dAl0QS66WdPZ9in/wuEMpUOG9OWB787gwguHHwvbiiBsGw7D1jbvtG2FZdlYlmpfvUkh0PXAHMnlDMC3Zm0h69s130RmzjwM39AhSTz26JUs+Xg3j/9jFfv2VZ2SIVcpukDTWd2v6XSJrQSWZZnhfeEuWAETwv6HmBgXd9w+mdu/PZk+fdxHwfbligO8uGADGzYUY9s2jq/A5vdbxMdHMCS7L5mZ8bjdDjwePyWHGsjfV01NbStOp3YUfGvXFbJ+w0EmTerPbbdO4pwj4Ltw3nCmTR3AC/9azyuvbqKxyYe7B4MSuuKhN00LJbD07tR0rRq2ANs0TcKmroewM00b21bMnjWY7z04kxEjUo6G7cv9vLgglw25x8IGAc9IZKST7953NlddOYY+fdw0N/vx+02cLp2YaBcNjV4WL97KC//aQGurH02TweiRAHzr1hWxYUMxkyb257ZbJ3LOOYORUtCnj5vvP3QO8y4YxqOPr2T58v1IKXpsRR8ueJZlIsD2OrC6DTpnC5YBVtjQ9eBQOmhQIt+9bzrzLxnRPrm3bcXy5ft58aVcck8AW9vnIiOdPPbolQwdksTzL6xn+fL9VFY1t0eZpCRHM2vWYG7/9mTGj8/gwe+9hcdjtGu0o+BbX8SG3GImBuGbFYRvxIgUnnj8Kj74YBf/eHIVBw7UnBar3JM/0AaApTd1o6Zz61gtJpZp+Ltgt63o1qE0KsrJLbdM5M47JhMfHxl8MhXLv9zPggUbyN1YEnBXOTX0E0Tm+P0WN914FjkjUrjp5n+za1dFOwxCgM8H+ftr2JlXwRfL9vPKy9/iiitG8eKLuccYXY+Eb/36g+TmFjNxQga33jqJ2bMC8M2fn8P06QN47vn1LHxtMy0t/m6NmAl39WwYBoDp1rtR0zW6sIQX0wgTOtEFX/iEW/5smxkzBvK9B2cyelRa+xC5bPl+FizIZeOmAGwdCUdSSpHRL46y8ib27q3C7daPcqILQRBAnb17qygvbyKjX9zXTtCPDNpcv6GY3I0lTBifwa23TmT2rMHEx0fy4x/NZt68YTz62ApWripAk10fQSO64CYYfj8CzEZXN0LndmM3NWL4/f6wHcVdGTRgK4XPa5KVFc99957NFZePQgiBZSmWLc/nxQW5bNxYjFJ0KvZN1yUff7KH668fx0//37k89fQa6uo8wXslgMAqPD4+gnvunkZWVjy/+e0nHQak7Vo25BaTu7GYCRMCw+7sWdmMHpXG0/+8lrff2cGT/1xNUVFdlw65QoiwxxrD8KMEZmxsN0KXn4+ZGovf7/eF/ZR1VUyez2cSEeHgxtsmcfdd00hMjMS2FZ9/vo8XX9rAxo0lnYatTRwOjY2bSvjFwx/x85/N4ZKLc1izppC9+6pobTWIjnaSnd2XaVMH4HBo/OLhj9i4qaTT52r7fG5uMRs3FjNhQga33TKJc8/N5sorRnPOOYN5+uk1LHpjKx6P0SVDrpQCESbAfp8PAf68vG6EDrCFwO/3+brAIS3CWj217Z6fOjWL73/vHMaOTQdg6Wf7WLBgAxs3hQ7bV4F4772dbNpYwkUXjWD69EDQpNOlY/hNSg418NLLuXz40W5KSxvCAuIwfCVsbB92J3H+nCH8/GdzuPjiEfz97ytYs7YwrCwESgUe+nCVpt/vQwj80I0LibY0Hb4woRNSIEOMcm3PE5IRx733ns01V48JwLZ0Ly++lMumLoLtSHG5dCoqm3jm2bU8/8I63G4HmiaxLBuv18CyVJeGybfDt7GEjZtKGD8+g9tuncj5c4by/HPXs3jxNp58anVY+VakJsIeqn0+L0rh7az9Sw9haPT4fF5syyLUDTpSCLQQvrDfb+Jy6XzrWxO49+5pxMVF8N77O3lxQS6bNx9qj+QQArxem+4Q01I0N/tQqm0yHpjdGYbV7l7ralvaqlUFrF5dyPizAlEtl146kpkzB/HU02t4861t+HwmTqfe6SDQcIZX27Lw+XwI0enIppBCmzx+nxfTMnGGCp0UaJ0YGizLxjBtJk3sz0MPzmTixP4YhsWHH+5i4+YSckakMHZM+mkRtdKdhlzDsALuOcvm4otG8PAv53LRRcN59NEVrM8txqHLDoeo65oMK9GRaZn4fd5Qwuk6D50UtPi8XgzDwOl0hbyhQ9e1k/r+lApot7S0WO6+cyrXXDO2fR7jcGhcfvkoLr/8P7uQzMQJ/Xn+uRt4442tPP3sWsrKGnE6vz6CRanAZiYtDE1nGAZerxcpOp+5s/OaTtLs83kx/H6ICn0h4XDIkwKnaYKrrhzDffdOIyMjrt3h3ivH9ucNN5zFjBkDefKfa/hoyS4s6+vjFR0OLaw5neH3BTSd7HzOYj0Ew26jz+/DF1Ctoe9qd2gnXb3quuTAgRp+8MN38HjNXrpOIhFuvX3HmPU14WdKgSPMhZbX6w3M6aCx+4dXSaPh9+H1tIZ10U6X/rWLnoCbyWLzlsCc7Ybrx532vkhOsa958Zvb2L6jrAPbIFXYK22v14Ph9yFlD0CnoN7v99PSEl4Sbncw8LEjvsGZMwdx87cm9JJ1EqmqambXroqTLqiUIuwwqtaWFvyGHwX1nZ+hdVI0IetNw6CluSk86CIcnTDu9Gq4ruwnpWjfME4YmThNw0ATsr77FxJC1JumTWNjeKWnIiMcHTIp6rrG2nVFvPb6liOMoAqfzzrl+yxO7eYagcultYOmlGLtuiL0DqYTDRe6xsZ6TEuh67KuB1avos6yoKG+NqyLDuwnVR1yuufllbN166HDLhwpuOSSHJKSor82ElFx+BSdteEpFXr4jwrznG0G56+bd1RVNfPBB3lH7arreO49FXb2p4b6OiwLdCm6X9MJW9QrG6uurias5U90tKvDvtcjUyjYtiI62smPfziL1NTYk+6tPdHfHdmXeyQMHQHoq58L55wnO7a8vJHVqwtobvZ3eoGlFGFDV1dXg7KxRE9AZwuj0VZ462qqw6o7GRPjCkmLSCloaTH49h0LT7D7PnDDrrpyNNdfNw6XS8c0bd5YvDUwRCMQ8sRBBPHxkdx3zzSmTMkCoKy8kaeeWsPGjSU4XdrXRFxYTJiQwb33TGt/GDZsOMiTT62hrq71hBpI2aBQXH/dOK65OmD89vlMXnt9C2++uR2pieP2U0uLn5YWI6QVvRAcs92SEKov2gqvkkZDt0NnOWgUguaa6sqwoQt1gSAEHDrUcNwd6n6/xf3fnc4tN09k1eoCtm4tZeTIVK6/7iwaG3385a/LjmuYtu3AkPPwL+cyMieV1xdtob7Ow/nnD+VHP5zNd+9fzLr1RSesDTZlchY/+uFsqqoC1Xbi4yO4dP5IHrh/Ovfe9wYtrf7jhnMZhs2PfzSb6687i+XL97Mzr5yxY9O55eaJ1Na28o8nVh03eCGQikOGvOAIF7qa6kqEoNnUaep26NxuWsxGGmpqqlLCuejYGHdYdrcj0yQcqalGjEjhgftn8OrCTfzu959iWTZSCn78o3O5686pLF26l5155cfA4/Wa3HTjeCaM78+99y3is8/3IYTgxZdyeeH5G/j5z+Zw080vHzOEKhWYS/38Z3MoK2/k9jsWUlnZjFKKzz7bxz+fvJYbbxzPM8+sxeHWjoF13Lh07rpzKs89v5a//HUZtq3QNMnDv5zLA/fP4PMv8jlwoKZLI4elFGEn1K6prkIIGtzuzrvBOv1N8vPxCUFtTXVVWBcdE+tC00SX7n81TZuRI1PQdcnChZsRUhAZ6UTXJa8v2oJt24wZm35cV5qUgqlTs9i5s4wVKwuIinIRFeWksrKZxW9uY9iwJJKTo/nqnl/btklOjmbYsGQWL95GZWUzUVFOoqJcrFhZwM6d5UybknXcB8yybMaOSce2bV5ftBVdl0RGOhFSsPC1zei6ZGROCqZpd2nggKZJYmPcYQ6vVQhBbWcq5YQMXVAq6+tqwnKFxcS4g9qma80ebpeOZdn4/NYRO7IEfr+NYdhEnCBLUWCnvkZTcyDpYps20zRJc7Mv4C/Wj3XdKQUOXUNKaG7xtQ95bW00NXtxubUTzl/dbh3DsPH77XaTkJQCn8/CsuxuyGIViP0LZ3j1+bzU19UAVIakaUMb2ihtaKijuSl0A3FMtKs9HUN37OX86k1u+/vrzhcYOsWJkv91NEngMe+d7JyhXm+o/eNy6USHAV1zUxMNDXVoGqU9Bh2SQy3NTdSHYauLinISGen4jzbwcopymERGOsMymdTX19LS3ISQoZVmDwk6Xchij8dDdVXo9WcjIhydstX1StdpupgYV8AjFKJUV1bg8XjQhCzuMeikECWGX1FeWkI4+wDi4iLCT8zXK52ORomLc4eVLaqsrATDr7Cl6DlNZ0mt1LLxlxQXhdUBiQmRvcPrKRheExPCMrFyqLgIy8YvRKeKH4YHnSH9lQLqiw8WhHXxyckxvdCdAujCLfFeXHQAAfWG9Pfc6rW0lAYEFSUHC8O6+NTUmN453SmY032dz7ojUlJcCILy0lIaem71CqamUVRWWhyWrS4tLbY3Gpie30+RlhoTlo2urLQETeMgYPYkdAhJfnVVJbU11aFrupSY9qrPvdIzWs7p1EhJiQnL0V9dVYGAfSGDH+qBupC7mhobKD10MOQvkJQURWSks3de18M2uqSk0BcSpYcO0tTYiK7J3T0OndLEXq/PomB/yMATFx/ZazbpcXNJRHu+vlCkYP8+vD4LpYm9PQ6dEFaBbdG8d89OwglZT0mO7oWuB6FLSYkJK1R97+6d2BbNQlgFPT+8RlMuJIf27d4ZVkf07x/XC10PQtc/o09YbezdsxMhOaRHU97j0OXn49M09hYc2BfWHtgBAxJ753Q9OKcbODAx5OM9nlYKD+xD09gTSkhT2NAFN15vqSgvpTQMd9igQQndXpe0V2gP0xo0KHToykpLqCgvRUq2hsVNWAdr2ubmphb27ckLuY2szPjeaJMeW7k6yOwfF3Ib+/bk0dTUgtS0TacMOs3Wdhgm3u1bckNuIyUlhr6JUb3zOrq/HH3fvlGkhmEY3rYlF9PEq9nazlOn6eL8B4WgaNvW3LDi6jIz4w+XPuqV7llEWDaZmfFERoYeR7d9Sy5CUCTj/AdPGXT5+fg0nS379uTR2FAfcjtDhyVh2b0pwLpb0w0flhzy8Y0N9ezbsxNNZ0s4i4iwoQNwSLm6oryM/H27Qm5jZE5ql2Vb75UTp9zNyQl9A1/+vl1UVJSjSbk67GsJtwGhybUej2lvyl0buqYbmkRUVNe5w463L0Ep1aG9DoFjVQjJacRxJ+8dO+exFQlPtF8j1EVEdJTrmBKjnZFNG9bi8Zi2psm1pxw6p2nuQlGyfs2XIbeR0a8P6Wl9wp7XSSkoK2tESsGwoUl4PAaWZePxGGRn98Xl0jh0qOG4N9OyFIcONTB4UCJ9+kTg85mYpo1pWowb24+mJi8NDZ5jomKkFDQ0emhq8jJubDqmaWGadrCAcQSDByVyqKThuN9NCMGhYBmA7MF9j7reYcOSjvo+4RWOU6Slx9IvPXTD8Po1X4KixGmau045dHtqaNJ1NuzYujHkeZ3LpTN8RDJmmKldHQ7Jxk2HyMur4OFfzuWCucNITIxi9uxsfvPreRw4UMOatcffpa9pgkVvbCM+PoI//O4ihg5NIiUlhnvvCZQNWPTGVmpqW48LXU1NK4ve2MY1V4/l3nvOJiUlmqFDk/jD7y8iPj6CRYu3oh2nhIHDobFmTREHCmr4zX/NY/bsbBITo7hg7jAe/sVc8vIq2Lip5KSpcjlpUmqbEcOTQ06E2NhQz/ZtG9F1NuypoYkeSWh2EslKkvcBTyx863OmTp8VUhsLX9vMf/3mY9xuR9hVqwcOTOR//zSfESNS8PstnE6N/P3V/PSn77N7T+UJ9wf4/SZXXTmGn/9sDlFRzvZKh++8u4Pf/f5T/Efspf2qe8np1Hj4l3O5/LJR7ce1tPj54/98xptvbTthyn3DsBg+LJk//2k+gwf3bb/eXbsq+MlP36egoCbs6tder8F//XoeN1x/VkjHr121jBuunAPw3aIq+8lweemSnby61L5sbjX8K79c6gwVunFj+xER4Twq9dWJKhOezKa3a1cF19/4ElOnZJGeHkt5RRPr1hXR2OjD4dA4cZFkxb9f3cTKVQVMmtifiAgHu3ZXsmXLoWDxOfm1N/bHP3mPl/+9iRHDk/F4DDbkFlN0sA6XU8P7NTmTt2wt5ZrrXmTKlCxSU2IoLW1k7boiWlr8J7negKb9ukItSikiIpyMG9sv5Pu78svP8Hptf0yUczn4OS003QRwlPZhw5Rp08a+8f4KtBDqS/h8Jtde9yIHCmpPnOFIKaZNHUBaWmyHnNuGYbVP5juTTdy0bMxgIRKpSRwOSUfKtykUhmFjB6cJukND76CLL9TrLStrZM3awhMuOkzTZtDABBa9fltIw6ttWVw9fwbr1qzdmt7ApI1gnBaabiMY/R3i091528YWFuQzOHtYSPO6seP6sXdf9XGhU0rhdOr88hdzyQgzUuKbJCUlDVx59Qv4/eZxwTNNm7Fj+4U8nyso2MfuvO3oDvHpRpTRFdfcZZ52qckPG+pb1Ipln4bcxtnTBpw0Z13vnopja3ydzBxz9tkDQm5/xbJPaahvUVKTH3TVNXdZdhYv1noJhUs/fnfgbd+5PyQb0/iz+pGQEElTk+8YuAJJcEz+9vflZPaP76UtKAeL606o5WxbkZgYyfjxoc/nli55D6DQi7XhtIOuooKWjL4s2Zy79r6DRQfIGjCYUJz/o0el8eWK/YEiwUcsGEQwv9Pixdt6gwO+upBw6e39024CkgEj96hRaaQkh+bkLyrcz5ZN69B1PiquoOW0gw7AqWlv1NY23fv5Jx+I2+/+XkhtzJ41mE+X7uXSS3M479whvVSFKJ9/sY/33stj9qzBIbfx2SfvU1PTqFwR2hvQdRUeuxQ6v8NaI7zs++Dd14feduf9SNn5Vez06QOJjnZx/pyhzL8kp5eeMDTgsmX7mX72QEILbbf48N03EIJ9lsNa26XX1rUrKTwOh1i8dXMueTtCCy7NyIhj7Nh0fL21wMISn9dk7Nh0MjJCC9rM27GVrZs34HCKN0pKOl9es8egC8wl9IVNTT7/O4tfJdQk1vMuGEZzi6+XnDCkucXHvLnDQq6B+87iV2hq8vl1oS/klNT16WSbGfF8ljVwwLkffrGF2NjO29QqK5u5867XiIpyInv3T4QUsNnSavDs09eFlCynsbGBi88dR1FB4Rcldczp6hy9ejd8Z+VwyOcLDxSe+9nH73HltTfT+WxO0eTkpLLoja3dkHP3my9er8G1144LOTvT0iXvUnigEKdTPg9dbyroljuqmfa7tk3Rqy8/k3XZVTeG5Ba78opRfPBhXu9OsRAXEVeGWPHbsiwWvvwstk2RZtrvdsv1dUej+bU0Ol1iwYa1q8ldtyqkNsaPzyBnRAqGYfVSROeibHJyUhk/PiOk43PXr2LDutU4XeLF/NrO13I9ZdABKOl8wesxG1964QlCi43TuPLK0b3l0zutqWyuumJ0yOFQLz3/BF6P2aik81/dpom7q+GDFb4Cl1MsWvrxe+zO2x5SGxfOG06/fnG94HUCuIyMOObNGxbS8bvztrN0yXs4nOL1gxW+gjMOukAOO/2x+vpW3wvPPBrS8XFxEVx+2Uj8/t4htiPi91tcftko4uIiQjr+X88+Rn1Dq0/X9Me6dc7ZnY0XVhlbXU7xzvtvv87+faGlM7v2mrH07du7Gbsj8XhJSVFcc/WYkI7fv2837731Gi6neLug0th2xkIH4HDqf66pafQ/88QjhJoi9rJLR+LzmZ0oRNT2EtgIrODLRGIEX340/Gj4jnh5j/PyhfA6WTtt5267FhPZfo02AoVo/w50Igj2sktHdSjA9XjyzJOPUFPT6Hc49T9zWhR9D1MyE8WrkVFRN7y1ZDXDR4zu9PElhxq44aaXqW/wIqQIwhSAqg0yEXxJFBKFjo0j+HJi4RQWLixc2IGfwmz/24kV+KwI/K6jcGCjYaMJFfiJCj6h6phOa4PEDoJtqgBABhomIgCYkviPgN2Lhk8dhtCHhk/JdhjNI2A8EkLRfuNU+/e1bUV8HzevvXoL/dI7D93uXdu58sKzaW1pefVgjbqpu3noEcurrun/XV/XfPnjj/wh4vFnFoa0RXHIgD7kbawnzmUThUEMBrHCTyz+o37GCD9RmERiEiHMAHBBoPQgPFrwNsqgLhHte07VUT/a/1Ad0zoBl9NXaqGLo59tFfRL2UGtZh+phYPQedHwKo1WdFpw0KwcNCkHTThpVE4agz+bcNCMk3pTMHRAckjAATz+yB+or2tujYx0/HcXRKOfHpoOIK0vj+tSv3/BG0uYPXPO0ZrC68VuakY1NGDV1GJXV2NVVWNXV2NX12DV1lG29xDS00qkNHFho2MF4FEqWLVNtVe1Drylgr8H3zdMlGUF/1YgJQgJbX8fUf1N2TbKMI/KiSY0LfBZwzhBL34l6NShB45r+4BSKMtE2CrApSYRDgdC0xBCBF6S9t+lDFS0lkIggr8HDhQoEYC1bZrQamvYEZGkDklHi49HJiYi+yaiJSchk5KQiQnIuDhkTDTCfXTJzWUrPuPWay7Ess3HS6t5sCdY6BHo1IQJjp/XV41Z11y9dNa4iXE//s5DqIoKzNIy7KpqrNpaVGMTqrUV5fejTBNsO8iAaq9RqpTCthS2baNsFYBDKZQdBE8p1JFqqR0ihZ6WgpaY0D5GmcUlWA1NCCmO7gplI6KicAzIPDxJb2jALC5FRLhxDBpAR7zoxsFiVFMzSIny+RBRUTiHDcXRvx9IiVlWjn/PPqyaWqTLdeydOOIcoq2OZxuAUiCEREiBlDJYcl1gWYfLdwoRfFh0HeF0IiIjELGxaAkJyOQktJQURGoKf3n+Ub7ckls/Jbrv+X+MS9omNm40znjoikbPiHdGyvcdQmSbyk4Qtq1bfn8AFNq0Eu0aSB0BFEFN1f6hrx/XTgy9x0Pf//4v+tx+S/t7Dc8toPqXv0VEuI/5bPwPHyThJ99vf69p8TtU3PsQrrGjyfhwMcJ58sxHZbfeRetnywBB5HnnkPDTH+IalRPQsG1gFh6k/p/P0vjywoAm7UhIyMn6IagpkQIh5VGAChnY0xaAOPBTczqxpTSdUtb4bbXf32rPz9q+su6MntMZwnJoXmOkVKqPYZpYphUEyz5KQ50UpHDzekh51A2Pvuxi6h7/J3ZtHe112W0b2acPMVdfcdRn23+X8pjh6cQ9q6P8BhEzzyb12X8gIo61nTkGZJL0P79FSEnDCy8hXK6OThy/FkqlFNiglHliMNug9PrRNE2Xup5iCeE2hHRwpi8k7Moq5XM4/KYAq33c++pkW/RM5Y4jREtJJmruHBpfeqUdCOU3iJxzLo7sQcccKzSJVV1Nze//hNA0lGEQdeEFuCdPCDxc+QdofHURQteCf+9HaJI+3765vX2ruobaP/4FZVok/PxH6KmBLErxD32XprfeQ7W0HA17+JmETgympVBmwOhuQcBko/DbhqG+EavXoE4/7QyqMddfRdPrb7alSAIpiLn+qhNqSruunvrH/hm4b60etJSUw9AVFFL3yGMIZ0BRCKcTERGBntW/vQnvpi3UP/UcQtNRXi9Rl1wY+IdpICMjMZub6dFeEl9dZveMAf4/OljNPX4crvFj8K7fCFLiHDKYiHOmf+1NOnKYFLp+VI15ERHRDl2b5rTrDicVipg6mfjvP0DzO+/T9MbbNC16MzA/FCIAqab9R/R7t3sk+lgNnh57hDooVkUlyucDTSPm2qvAtsEwiL58PjIyEmUYmOUV4Z9I2TQtfONwZ8fG0Pf3vyLjk3dJfuwvRM49D+Fyg9ROl5FABe/X6a/p9mZnu+pa9WihO/poEG8KK0kJkQykFqMG9LFVrDiNuPNt34mMicY9ZRJRF86l7i9/x25qJvqKSwHw796LUVRM9PwLwxu9XC6aP1iC/NmvSPjBA2gpgfSreloqsTddR+xN1+FZsYqqn/4Ko6g4YNs7RWKjsCG2OCrpz2uj+haCLBdQgSVqhBC1yjQa4iPN5qH5+b5ug+510NKHDYuMaCXGEFocmkpUlkxGWCkCkQqkAikIkVRrkIBDxdnCjLEQEQ4hhBZMOSMRCGGdVqrO9nho/Xw57imT0BITiJwzG7OsPGCDA1o+WILeP6NLziV0ncZ/vUzrJ58ROWc2UfPOxz15IjI2sAE6YuZ0kh//K2XX34by+eEUpc1QgdmD2ynkfXowGZAFmJqtbJRHOkRTjeFsWDsgpwalqoAKCeWgyi2lVQjNrsQSNQ5l1XsiaSrds6f1uhNslj0KurVZw6fqUvuhqVSCUqqv8BJvaMQqpaI0JRy6BvKIQ1Tg6UAJUEoQNM1iKoUZxEwCET3p+ugICA4HLR8vJeHnP0LGxBBz47XYDYEgWeXz0fzBx8Q/eG/Xnc/pxKyopOFfL9P479dwZGWS8PMfEX3ZJYfnlmNG4VmzrkM2wO4Ez6ts7KOXF0IiIoUQkZogRQTzFx+ZxcpGBfzNQhmGlC26l8b+WSPq1gtRLYWoNW3rkalFu9ceFzpPq9wRGWU3x0r9Wk/w5EqpAFSAX6nTbXoWsvYxCg/i+XI1UZfMwz3hcLJAb+5m/Lv3HL1ICMNEk/Sn3+HIDuyy923bTvXPfo1vZx51jz5J9PyL2k0kMjqK07Hw7eE7/lUHtDrGQCGFcAiIE1LESciMEJJG23zB0yp3nFDTnVuV16yquHP9gBGtLqHdbyob9Q2uuNv01rtEXTLvqLeb334P5TfCV81CoLxekBL3xADUrrPGYFXV4Nu2ndhvXd8OnPJ48R8oPGykPhO788hhWikcQtJgm/+YWrjre4KjlOexczoBtirc9b31WSOUS2oP+L6h4AmnA8+qtZjFJe3zN6u2jtbPlx9l9ghvxqxT/8TTRM6eiZachNA0En76g2M+1rDgFYz9B07p0NqVJlmXkHhs6/ElRbsemvYV4E5oMhFgf1i06yGPbT3uEvK0mo91iSE0kMsVu7aW5g8/aX+79bNlmIdKj/WDnsiccZLPCF3HvzefslvuonX5yoDmO9J0U11D3d8ep/Z//hr+cH4aAee1rceWFO166DfHAe6kDv9fg7woa8T/uaX2YKgaTwLxSiFPbSw3elYmemoyKLDr6/Hv2QdKIRPicQbnXEZBIWZFJQCOwYMCUSmAVVWNsb/g6JWlbePIykJLTW6PRPHvyQ9+5gg3nxDgN0DXcWYPwjEwCxEdhV3fgH/XXsxDhwIaTp76/b02UCcEdnga7rElRbu+fyLgOhRlEgAv529uKb8XCnjdBt0R0SdHRaIEo1eOmpQLgbKswHsyGMfmdh+l0YRDR7hcCLcr4KZSKhD2pGkI3YFwOY8AKvgyjEB8nQrGS2kSLCtwLssK+DZNE2VaKNNA+XwBs4hpoWwLCMTJBSJq7MPXfpT2DLjnjoogOfJ1GkB3WMPZj35UlPeDrwOuw6FNCsS6rJz/CwW8zkInDq+EgnY+aFugB1bSAguFCQiXExkRgYiMREZHI2NjjnjFosXGIKKjkTHRgf9HRSIiIgLHuF0IlxPhcAbmcMGASnQt8DMYldKhm6zaVnaHQ7JQNsqyoQ1Ay0QZFpgGyjADAHq92B4vyuPBbmnBbm5BNTdjNzVjNzZiNTRhNzVhNzQG3mtuRrW0YLd6UD4fOgJNCEQwObY60owF2Ep1aq9FKNAdCdyUorzviw6cTnRidSLWZOX8X2QnwTsedOIrqx5dCHQCMBlKWSiaFapeCFGDokpA2T7bG/GJ1Xh9q9PBd372K8afNxfL5UJERyEi3IFAyG+y79KyUD4/dmsrqqUFzeNj0xef8tyff0eEz+BCLfa1IZrba0MaSiUBCSDiEETrQmg6AhOFqdQx/R8qdEcA9/cpRXk/EB3kW3RyWSzWZeX8TZfie6ZSoqPQJSqF1r55RQVDaRQCgRQCS6nlTlgghH0I9HLd9Fe7fI6G5Kq81iOX2zFJ3BapxP+lpqbHPfyb/+Xqq27kP1XeWPwKv//1TyivKKtvFeoHTVX864j7JCuTciJ9LqOPcLgSDWWmCiX7eVG3aULMsoMR1hoCrc1rFLwnNZ2AThdCmbZ6tDPAhRw5vCZrxLsuKS/1d8CYKQGP6afGNPCh8CnVbvUe4Y4mTnPgVdaSaYW7LurIuQel6hP9fvMpIRh/4y138bOH/0h8QuJ/DGx1tdX88bc/Z+HLz4Jik8Op33Og3OxQwd3VWSOWREhtXr1lsMvbjATcQuISAheCRN1BhO7sEHROIfDZ9nvTinZd1u1RJuszRw+SQozvaO04G0DTaRFQYvqpNA1abJsW26LA58FQCpQ4e2326A45Ow+Um7laDHOkFE8teP4Zrr10FuGUETiTZMWyT7n20tm89MKzSCmekjHM6Shwa7NHZwjENEPZFPg8tNgWLbZNpWlQYvppEYH71FEtZymQQoxfnzl6ULdCp0BawnrUJWS/zrjw3UIyzBXNmIhYYjUdhUIiqLX8lBpeIjUZqwxjRkfbKyqivqhK3euOkDfszttZ/O0b5/Pbh39EfX3tNxK2+rpafvvLH/LtG+ezO29nsTtC3lBUpe4tKqLDFQCVYc+I1GRsqeGj1vIjCfjK+2g6YyJiGeaKxi06joOFwiVkP0tYj6pOctSpD68ZkHOXW4pLvMrutIvERhGvORgTEUOmMwIZfL/I76HVstCQF3X2ZhRW2K+5I93TTct45clHH+Hqi2fy0ftvfqOAW/LBW1x9yUyefOxvmJax0BXhnlFYYb9Gp9PyqotaLYsivwcVvPGZzghGR8QQrzmwg8EanRGvsnFLccmaATl3dctusI2Dc7Iti7UCkRhOoJIImkAaLYMCv4c60yDF4WSYO7rQ7dFHjavYFlK9ggEp8jrDb/9B00T2xZdeww/+368ZOnzkGQvbvj15/O3Pv+GDdxdhmirf6ZK/KKywXw+lrS0pY6K8EeaOPd7mARWGn3jdwUBnZPuoE46bM7BAVDWmydSzS/Lyu0zTvQ6aYfF3p5CJ4UbGtWm9WM3BqIgYBrsiqTUNSg1vlhZljQu13cIK+/UIF2dLwSNvL17kufqSGfz5D7+gprryjIKtpqaK//3vX3LVxTN4643XW6Xgr5Fuzg4VOAAtSowrM7xZtaZBtiuSURExxGp6SNrteMOsU8hEqfP310HrGKgdkB9njbjHJeUPfF0YetOm4uN1B311J17bEk2WVf1KU93SUNusbaa1vpVPkuP1j1tbW/utWrFi6JIPFiOlZOiwHJxO12kLW0tLM68seJr/99CdfPjeuxiG9323W/92QaX9r9pmWsNp+5LI6AdsxYxBriiSHM7jBCaFJyYKlxBDIvv0LXuuoTo37OF1zaARQzSbtQKZEKqWa4sgluKwhwHAUAoL5RFQLaGk0vR/dElJ/u+6qjMGJ2tXeA3r/1M2k3JGjeKOex7i8qtvJDIy6rSBzdPawrtvvcaz//wbedt3ICQbHA7tD4WV1jtddY4PMrIfTtadFwP9bOgrhYhwtCcfCngwbEVYmi8wzNq1lmTqtAO79oUM3etcq2UO2PmeS8iLfCdZPBzpvpJByNrUr9+2DSGoAVEGFArFPqTYpyx1wOHgoCH8lVPz87slv21WFm7NK2/0+ewfKRg5ctRobv3O/Vx21Q0hlRvoKmlqbODdt15jwXP/YOf2bSjY4XDJRxwx9iv5+XRLEY292dmxNbYjRZiiv5AMRjFECbJBDRSKNAUJDikdGuLIfRMddqe5hcSjrCVTC0fNFyyyQoJuTdaI+9xSe6INuBOBZQeMvkqi6hRUAEUC8kHsFUrlK5uDWKp8cunuOgGnJJdrThLRrULe6DfsB7EZnT10CNfddAdXXXczaekZPXYdpYeKeWvRv1n06gvs27MXJNudDvmYR9ivVHRh0bfOyOugZaUPj0MTqVKSZQuygSEKsoEsASk2It4lhJAnATLgFjPvn1a0+4lOQ7c2MydHSNZHSBllq2DVZqWwUc1ApVCiWAl1QCixV0nysewCHUrd0bJmVF6en9NU0tKIdJnyatO0v2tZTE1LT+GiS6/mmhtuY9z4yd123i2b1rPo1X/x0ftvUlZaga6zxqHLJ7ya/WZZWXhztu6UHTk5Tm+znWhCutS0AcpWQxAMAQYpVH+USBaCGGdw34QU4LXtFttm8tSDeXkdhi53wgSHUeN50o0Y68feh2KfEnK/kuoAllXS6HVVzQvRtHG6yCzQi1O1uX6/dY9hMC8m2uWeOGUGV113M+fNvYTEvkldshL9/JMPeHPRy+SuXUlTs8/rcPCx06k9daDc+hQ4owug5aZNiCTC09c2RQaaPUjZDLEFQ9xo2V5lb3P0jbhvYkezQCmu1bZljv6PqeQ7KNkxOquv+FNaLAfS41CTR2eon/7gbrVy+VLlaW1VnZHW1ha1YvlS9dMf3K2mjM5Q6XGotFgOZPUVfxqU7Bj9n9Kn2zJHxyuu1U5pUsQzQbL6ECfc8gLTsG82DWa73CIme0gO5829mLkXXsbocRNwu4/NvuTxtLJ96yY++egdvlj6Ifv37cLnVU26g2W6Q76svPYnRQ0dd1l906UXuhNIdpJrsKmM+YZlX2OaTIyM1NyDsocz45w5nHv+xQwZNoL8fbv57OP3Wbl8KQX799Lqsby6Tq6uycUO4Xgvv8q3v7cne6ELzd6X4hhp2NZFlmnPt0wmuFxE94mLp6GhHp9XtWg6uZouP3BI7cP9FcbO3h7rha7LNaBfGbPBnoiUGx3KsWx/lS+/t2d6pVd6pVd6pVd65RTK/w+BX37eWugP5AAAAABJRU5ErkJggg==";
/* ===== Meridian The School — sample data & constants ===== */
const SCHOOL = { name: 'Meridian The School', short: 'MTS', place: 'Gopalganj, Bihar' };

const PERIODS = [
  { n: 1, start: '09:00', end: '09:40' },
  { n: 2, start: '09:40', end: '10:20' },
  { n: 3, start: '10:20', end: '11:00' },
  { n: 4, start: '11:00', end: '11:40' },
  { n: 5, start: '12:00', end: '12:40' },
  { n: 6, start: '12:40', end: '13:20' },
  { n: 7, start: '13:20', end: '14:00' },
];
const LUNCH = { after: 4, start: '11:40', end: '12:00' };
/* Section names in the order they should be listed within a grade */
const SECTION_ORDER = ['ARJUNA', 'ARYABHATTA', 'RAMANUJAN', 'CHANAKYA', 'VASHISTHA', 'SHARPER', 'ACHIEVER', 'ELITE'];
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const DAYS_LONG = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const DAYS_HI = ['सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'];

const SUBJECTS = {
  ENG: { en: 'English', hi: 'अंग्रेज़ी' },
  HIN: { en: 'Hindi', hi: 'हिंदी' },
  MAT: { en: 'Mathematics', hi: 'गणित' },
  SCI: { en: 'Science', hi: 'विज्ञान' },
  SST: { en: 'Social Science', hi: 'सामाजिक विज्ञान' },
  SKT: { en: 'Sanskrit', hi: 'संस्कृत' },
  CMP: { en: 'Computer', hi: 'कंप्यूटर' },
  GAM: { en: 'Games', hi: 'खेल' },
  ART: { en: 'Art', hi: 'कला' },
  LIB: { en: 'Library', hi: 'पुस्तकालय' },
};
const WEEKLY = { ENG: 7, HIN: 6, MAT: 8, SCI: 8, SST: 6, SKT: 3, CMP: 3, GAM: 3, ART: 2, LIB: 2 };
const CLASSES = ['6A', '6B', '7A', '7B', '8A', '8B', '9A', '9B', '10A', '10B'];

/* Sample staff — names and numbers are made up for the demo */
const SEED_STAFF = [
  { id: 'u1', name: 'Office Admin', phone: '9000000001', role: 'admin', subjects: [] },
  { id: 'u2', name: 'Nidhi Srivastava', phone: '9000000002', role: 'coordinator', subjects: [] },
  { id: 't1', name: 'Rajesh Kumar', phone: '9000000101', role: 'teacher', subjects: ['MAT'] },
  { id: 't2', name: 'Sunita Devi', phone: '9000000102', role: 'teacher', subjects: ['MAT'] },
  { id: 't3', name: 'Amit Singh', phone: '9000000103', role: 'teacher', subjects: ['MAT'] },
  { id: 't4', name: 'Priya Sharma', phone: '9000000104', role: 'teacher', subjects: ['SCI'] },
  { id: 't5', name: 'Manoj Prasad', phone: '9000000105', role: 'teacher', subjects: ['SCI'] },
  { id: 't6', name: 'Neha Kumari', phone: '9000000106', role: 'teacher', subjects: ['SCI'] },
  { id: 't7', name: 'Anjali Verma', phone: '9000000107', role: 'teacher', subjects: ['ENG'] },
  { id: 't8', name: 'Rahul Mishra', phone: '9000000108', role: 'teacher', subjects: ['ENG'] },
  { id: 't9', name: 'Kavita Sinha', phone: '9000000109', role: 'teacher', subjects: ['ENG'] },
  { id: 't10', name: 'Ramesh Pandey', phone: '9000000110', role: 'teacher', subjects: ['HIN'] },
  { id: 't11', name: 'Pooja Tiwari', phone: '9000000111', role: 'teacher', subjects: ['HIN', 'SKT'] },
  { id: 't12', name: 'Vikash Yadav', phone: '9000000112', role: 'teacher', subjects: ['SST'] },
  { id: 't13', name: 'Archana Jha', phone: '9000000113', role: 'teacher', subjects: ['SST'] },
  { id: 't14', name: 'Shashi Bhushan Dubey', phone: '9000000114', role: 'teacher', subjects: ['SKT', 'HIN'] },
  { id: 't15', name: 'Ravi Ranjan', phone: '9000000115', role: 'teacher', subjects: ['CMP', 'MAT'] },
  { id: 't16', name: 'Sanjay Kumar', phone: '9000000116', role: 'teacher', subjects: ['GAM'] },
  { id: 't17', name: 'Meena Kumari', phone: '9000000117', role: 'teacher', subjects: ['ART'] },
  { id: 't18', name: 'Dinesh Gupta', phone: '9000000118', role: 'teacher', subjects: ['LIB', 'ENG'] },
];

/* Which teacher teaches which subject in which class */
const SEED_MAPPING = (() => {
  const m = {};
  CLASSES.forEach(c => (m[c] = {}));
  const split = (subject, groups) => groups.forEach(([tid, list]) => list.forEach(c => (m[c][subject] = tid)));
  split('MAT', [['t1', ['6A', '6B', '7A']], ['t2', ['7B', '8A', '8B']], ['t3', ['9A', '9B', '10A', '10B']]]);
  split('SCI', [['t4', ['6A', '6B', '7A']], ['t5', ['7B', '8A', '8B']], ['t6', ['9A', '9B', '10A', '10B']]]);
  split('ENG', [['t7', ['6A', '6B', '7A']], ['t8', ['7B', '8A', '8B']], ['t9', ['9A', '9B', '10A', '10B']]]);
  split('HIN', [['t10', ['6A', '6B', '7A', '7B', '8A']], ['t11', ['8B', '9A', '9B', '10A', '10B']]]);
  split('SST', [['t12', ['6A', '6B', '7A', '7B', '8A']], ['t13', ['8B', '9A', '9B', '10A', '10B']]]);
  split('SKT', [['t14', CLASSES]]);
  split('CMP', [['t15', CLASSES]]);
  split('GAM', [['t16', CLASSES]]);
  split('ART', [['t17', CLASSES]]);
  split('LIB', [['t18', CLASSES]]);
  return m;
})();

const SEED_CLASS_TEACHERS = {
  '6A': 't7', '6B': 't10', '7A': 't1', '7B': 't5', '8A': 't12',
  '8B': 't2', '9A': 't6', '9B': 't9', '10A': 't3', '10B': 't13',
};

/* Seeded random numbers so the sample timetable is the same every time */
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* Build a clash-free weekly timetable: no teacher in two classes at once,
   at most 2 periods of a subject per class per day. */
function generateTimetable(mapping, seed) {
  const ND = DAYS.length, NP = PERIODS.length, NS = ND * NP;
  for (let attempt = 0; attempt < 50; attempt++) {
    const rnd = mulberry32(seed + attempt * 7919);
    // each class: a flat list of 48 subject codes, shuffled
    const rows = {};
    CLASSES.forEach(c => {
      const list = [];
      Object.keys(WEEKLY).forEach(s => { for (let i = 0; i < WEEKLY[s]; i++) list.push(s); });
      for (let i = list.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [list[i], list[j]] = [list[j], list[i]]; }
      rows[c] = list;
    });
    const teacherAt = (c, i) => mapping[c][rows[c][i]];
    // cost of one cell: clashes of its teacher in that slot + too many of that subject that day
    const cellCost = (c, i) => {
      const t = teacherAt(c, i);
      let cost = 0;
      for (const o of CLASSES) if (o !== c && teacherAt(o, i) === t) cost += 1;
      const d = Math.floor(i / NP), s = rows[c][i];
      let same = 0;
      for (let k = d * NP; k < d * NP + NP; k++) if (rows[c][k] === s) same++;
      if (same > 2) cost += same - 2;
      return cost;
    };
    const totalCost = () => { let t = 0; CLASSES.forEach(c => { for (let i = 0; i < NS; i++) t += cellCost(c, i); }); return t; };
    let cost = totalCost();
    for (let step = 0; step < 60000 && cost > 0; step++) {
      const c = CLASSES[Math.floor(rnd() * CLASSES.length)];
      const i = Math.floor(rnd() * NS);
      if (cellCost(c, i) === 0 && rnd() > 0.02) continue;
      let best = null, bestDelta = Infinity;
      for (let tries = 0; tries < 20; tries++) {
        const j = Math.floor(rnd() * NS);
        if (j === i || rows[c][j] === rows[c][i]) continue;
        const before = cellCost(c, i) + cellCost(c, j);
        [rows[c][i], rows[c][j]] = [rows[c][j], rows[c][i]];
        const after = cellCost(c, i) + cellCost(c, j);
        [rows[c][i], rows[c][j]] = [rows[c][j], rows[c][i]];
        const delta = after - before + (rnd() - 0.5) * 0.2;
        if (delta < bestDelta) { bestDelta = delta; best = j; }
      }
      if (best !== null && bestDelta <= 0.1) {
        [rows[c][i], rows[c][best]] = [rows[c][best], rows[c][i]];
        if (step % 200 === 0) cost = totalCost();
      }
      if (step % 1000 === 0) cost = totalCost();
    }
    cost = totalCost();
    if (cost === 0) {
      const tt = {};
      CLASSES.forEach(c => {
        tt[c] = [];
        for (let d = 0; d < ND; d++) {
          tt[c].push([]);
          for (let p = 0; p < NP; p++) { const s = rows[c][d * NP + p]; tt[c][d].push({ s, t: mapping[c][s] }); }
        }
      });
      return tt;
    }
  }
  throw new Error('Could not build sample timetable');
}

/* ===== English / Hindi labels ===== */
const I18N = {
  en: {
    dashboard: 'Dashboard', myDay: 'My Day', substitutions: 'Substitutions', leave: 'Leave', timetable: 'Timetable',
    requests: 'DPP & Worksheets', staff: 'Staff', reports: 'Reports', assistant: 'Smart Assistant', notices: 'Notices',
    audit: 'Audit Log', settings: 'Settings', logout: 'Log out', today: 'Today', markAbsent: 'Mark absent',
    publish: 'Publish', regenerate: 'Re-plan', approve: 'Approve', reject: 'Reject', apply: 'Apply',
    loginTitle: 'Staff login', mobile: 'Mobile number', sendOtp: 'Send OTP', otp: 'Enter OTP', verify: 'Verify & log in',
    period: 'Period', class: 'Class', subject: 'Subject', teacher: 'Teacher', free: 'Free', lunch: 'Lunch break',
    absentToday: 'Absent today', toCover: 'Periods to cover', unfilled: 'Not covered', pendingLeave: 'Leave to decide',
    openRequests: 'Open requests', applyLeave: 'Apply for leave', raiseDpp: 'Raise DPP request', raiseWs: 'Raise worksheet request',
    newRequest: 'New request', status: 'Status', description: 'Description', save: 'Save', cancel: 'Cancel', close: 'Close',
    seen: 'Seen', markSeen: 'Mark as seen', substitution: 'Substitution', forTeacher: 'for', noClasses: 'No school today (Sunday)',
    onLeave: 'You are on leave', date: 'Date', from: 'From', to: 'To', type: 'Type', duration: 'Duration',
    fullDay: 'Full day', firstHalf: 'First half (P1–4)', secondHalf: 'Second half (P5–7)', specific: 'Specific periods',
    pending: 'Pending', approved: 'Approved', rejected: 'Rejected', requested: 'Requested', in_progress: 'In progress',
    ready: 'Ready', delivered: 'Delivered', draft: 'Draft', published: 'Published', notifications: 'Notifications',
    language: 'भाषा: हिंदी', copySheet: 'Copy sheet', print: 'Print', ask: 'Ask', aiDraft: 'Make sheet template',
    worksheet: 'Worksheet', dpp: 'DPP', all: 'All', myRequests: 'My requests', remark: 'Remark', builder: 'Timetable Builder',
  },
  hi: {
    dashboard: 'डैशबोर्ड', myDay: 'मेरा दिन', substitutions: 'अरेंजमेंट (प्रॉक्सी)', leave: 'छुट्टी', timetable: 'समय-सारणी',
    requests: 'DPP और वर्कशीट', staff: 'स्टाफ़', reports: 'रिपोर्ट', assistant: 'स्मार्ट सहायक', notices: 'सूचनाएँ',
    audit: 'बदलाव रिकॉर्ड', settings: 'सेटिंग्स', logout: 'लॉग आउट', today: 'आज', markAbsent: 'अनुपस्थित दर्ज करें',
    publish: 'प्रकाशित करें', regenerate: 'फिर से योजना', approve: 'स्वीकृत करें', reject: 'अस्वीकार करें', apply: 'आवेदन करें',
    loginTitle: 'स्टाफ़ लॉगिन', mobile: 'मोबाइल नंबर', sendOtp: 'OTP भेजें', otp: 'OTP डालें', verify: 'सत्यापित करें',
    period: 'पीरियड', class: 'कक्षा', subject: 'विषय', teacher: 'शिक्षक', free: 'खाली', lunch: 'भोजनावकाश',
    absentToday: 'आज अनुपस्थित', toCover: 'भरने वाले पीरियड', unfilled: 'खाली रह गए', pendingLeave: 'लंबित छुट्टी',
    openRequests: 'खुले अनुरोध', applyLeave: 'छुट्टी के लिए आवेदन', raiseDpp: 'DPP अनुरोध', raiseWs: 'वर्कशीट अनुरोध',
    newRequest: 'नया अनुरोध', status: 'स्थिति', description: 'विवरण', save: 'सहेजें', cancel: 'रद्द करें', close: 'बंद करें',
    seen: 'देख लिया', markSeen: 'देख लिया ✓', substitution: 'अरेंजमेंट', forTeacher: 'की जगह', noClasses: 'आज स्कूल बंद (रविवार)',
    onLeave: 'आप छुट्टी पर हैं', date: 'तारीख़', from: 'से', to: 'तक', type: 'प्रकार', duration: 'अवधि',
    fullDay: 'पूरा दिन', firstHalf: 'पहली पाली (P1–4)', secondHalf: 'दूसरी पाली (P5–7)', specific: 'चुने हुए पीरियड',
    pending: 'लंबित', approved: 'स्वीकृत', rejected: 'अस्वीकृत', requested: 'अनुरोधित', in_progress: 'काम जारी',
    ready: 'तैयार', delivered: 'पहुँचा दिया', draft: 'ड्राफ़्ट', published: 'प्रकाशित', notifications: 'सूचनाएँ',
    language: 'Language: English', copySheet: 'शीट कॉपी करें', print: 'प्रिंट', ask: 'पूछें', aiDraft: 'शीट टेम्पलेट बनाएँ',
    worksheet: 'वर्कशीट', dpp: 'DPP', all: 'सभी', myRequests: 'मेरे अनुरोध', remark: 'टिप्पणी', builder: 'टाइमटेबल बनाएँ',
  },
};

/* ===== State, storage and the substitution engine ===== */
let S = null; // whole app state

/* ---------- small helpers ---------- */
const uid = (p = 'id') => p + '_' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-3);
const pad = n => String(n).padStart(2, '0');
const toISO = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const todayISO = () => toISO(new Date());
const parseISO = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (iso, n) => { const d = parseISO(iso); d.setDate(d.getDate() + n); return toISO(d); };
/* 0 = Monday … 5 = Saturday, -1 = Sunday */
const holidayName = iso => { try { const h = (S && S.config && S.config.holidays && S.config.holidays.days) || {}; return h[iso] || null; } catch (e) { return null; } };
const dayIdx = iso => { const g = parseISO(iso).getDay(); return g === 0 || holidayName(iso) ? -1 : g - 1; };
const closedName = iso => (holidayName(iso) ? '🎉 ' + holidayName(iso) : L('Sunday', 'रविवार'));
const noSchoolMsg = iso => (holidayName(iso) ? L(`No school — holiday: ${holidayName(iso)}`, `स्कूल बंद — अवकाश: ${holidayName(iso)}`) : t('noClasses'));
const weekStart = iso => { const d = parseISO(iso); const g = d.getDay(); const back = g === 0 ? 6 : g - 1; d.setDate(d.getDate() - back); return toISO(d); };
const nowStamp = () => new Date().toISOString();
const fmtDate = iso => {
  if (!iso) return '';
  const d = parseISO(iso);
  return d.toLocaleDateString(S && S.lang === 'hi' ? 'hi-IN' : 'en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
};
const fmtTime = ts => new Date(ts).toLocaleString(S && S.lang === 'hi' ? 'hi-IN' : 'en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

/* ---------- storage ----------
   Data lives in the shared Supabase database (see sync.js). */
function saveState() { queueFlush(); }

/* ---------- lookups ---------- */
const staffById = id => S.staff.find(s => s.id === id);
const nameOf = id => (staffById(id) || { name: id === 'system' ? 'System' : '—' }).name;
const teachers = () => S.staff.filter(s => s.role === 'teacher' && s.active);
const subjName = code => (SUBJECTS[code] ? SUBJECTS[code][S.lang] || SUBJECTS[code].en : code);
const isManager = u => u && (u.role === 'admin' || u.role === 'coordinator');

function lessonAt(cls, d, p) { return (S.tt[cls] && S.tt[cls][d] && S.tt[cls][d][p - 1]) || null; }
/* A period can hold more than one group at the same time (for example Sanskrit / Urdu):
   the first group is { s, t }; further groups are in x: [{ s, t }].
   j: true marks a combined class, where the same teacher takes two classes together. */
function partsOf(l) { return l ? [{ s: l.s, t: l.t }].concat(Array.isArray(l.x) ? l.x.filter(g => g && g.s) : []) : []; }
const cellSubj = l => partsOf(l).map(g => subjName(g.s)).join(' / ');
const cellTeachers = (l, short) => partsOf(l).map(g => (short ? nameOf(g.t).split(' ')[0] : nameOf(g.t))).join(' / ');
function teacherLessonAt(tid, d, p) {
  let hit = null;
  for (const c of CLASSES) {
    const parts = partsOf(lessonAt(c, d, p));
    const i = parts.findIndex(g => g.t === tid);
    if (i < 0) continue;
    if (!hit) hit = { cls: c, s: parts[i].s, t: tid, part: i, classes: [c] };
    else hit.classes.push(c);
  }
  if (hit) hit.label = hit.classes.join(' + ');
  return hit;
}
function periodsOnDay(tid, d) { let n = 0; for (let p = 1; p <= PERIODS.length; p++) if (teacherLessonAt(tid, d, p)) n++; return n; }
function weeklyLoad(tid) { let n = 0; for (let d = 0; d < DAYS.length; d++) n += periodsOnDay(tid, d); return n; }
function teachesClass(tid, cls) { return !!(S.tt[cls] && S.tt[cls].some(day => day.some(l => partsOf(l).some(g => g.t === tid)))); }

/* ---------- absences ---------- */
function scopePeriods(scope, periods) {
  if (scope === 'first') return PERIODS.filter(p => p.n <= LUNCH.after).map(p => p.n);
  if (scope === 'second') return PERIODS.filter(p => p.n > LUNCH.after).map(p => p.n);
  if (scope === 'periods') return (periods || []).map(Number);
  return PERIODS.map(p => p.n);
}
const absencesOn = date => S.absences.filter(a => a.date === date);
function isAbsent(tid, date, p) { return S.absences.some(a => a.teacherId === tid && a.date === date && scopePeriods(a.scope, a.periods).includes(p)); }
function absenceLabel(a) {
  if (a.scope === 'full') return t('fullDay');
  if (a.scope === 'first') return t('firstHalf');
  if (a.scope === 'second') return t('secondHalf');
  return 'P' + scopePeriods(a.scope, a.periods).join(', P');
}

/* ---------- the substitution engine ---------- */
/* Every period an absent teacher leaves empty */
function computeGaps(date) {
  const d = dayIdx(date);
  if (d < 0) return [];
  const gaps = [];
  for (const a of absencesOn(date)) {
    for (const p of scopePeriods(a.scope, a.periods)) {
      const l = teacherLessonAt(a.teacherId, d, p);
      if (l) gaps.push({ key: `${l.cls}|${p}` + (l.part ? `|g${l.part}` : ''), cls: l.cls, p, subject: l.s, absentId: a.teacherId });
    }
  }
  // de-duplicate (same teacher marked twice)
  const seen = new Set();
  return gaps.filter(g => (seen.has(g.key) ? false : seen.add(g.key))).sort((a, b) => a.p - b.p || CLASSES.indexOf(a.cls) - CLASSES.indexOf(b.cls));
}

/* Substitutions a teacher already has in the same week, before this date */
function weekSubsBefore(tid, date) {
  const ws = weekStart(date);
  let n = 0;
  for (const [dt, plan] of Object.entries(S.plans)) {
    if (dt >= ws && dt < date) n += Object.values(plan.items).filter(i => i.teacherId === tid).length;
  }
  return n;
}

/* Rank every possible substitute for one gap.
   others = substitutions already placed today (excluding this gap). */
function rankCandidates(date, gap, others) {
  const d = dayIdx(date);
  const w = S.settings;
  const out = [];
  for (const tch of teachers()) {
    if (isAbsent(tch.id, date, gap.p)) continue;
    if (teacherLessonAt(tch.id, d, gap.p)) continue;
    if (others.some(o => o.teacherId === tch.id && o.p === gap.p)) continue;
    const subsToday = others.filter(o => o.teacherId === tch.id).length;
    if (subsToday >= w.dailyCap) continue;
    let score = 0;
    const why = [];
    if (tch.subjects.includes(gap.subject)) { score += w.subject; why.push({ en: `teaches ${SUBJECTS[gap.subject].en}`, hi: `${SUBJECTS[gap.subject].hi} पढ़ाते हैं`, pts: +w.subject }); }
    if (teachesClass(tch.id, gap.cls)) { score += w.classKnown; why.push({ en: `already teaches ${gap.cls}`, hi: `${gap.cls} को पहले से पढ़ाते हैं`, pts: +w.classKnown }); }
    if (S.classTeachers[gap.cls] === tch.id) { score += w.classTeacher; why.push({ en: `class teacher of ${gap.cls}`, hi: `${gap.cls} के कक्षा-शिक्षक`, pts: +w.classTeacher }); }
    const load = periodsOnDay(tch.id, d) + subsToday;
    score -= w.periodLoad * load;
    why.push({ en: `${load} periods today`, hi: `आज ${load} पीरियड`, pts: -w.periodLoad * load });
    const wk = weekSubsBefore(tch.id, date) + subsToday;
    if (wk) { score -= w.weekSubs * wk; why.push({ en: `${wk} substitution${wk > 1 ? 's' : ''} this week`, hi: `इस सप्ताह ${wk} अरेंजमेंट`, pts: -w.weekSubs * wk }); }
    const busy = p => p >= 1 && p <= PERIODS.length && (!!teacherLessonAt(tch.id, d, p) || others.some(o => o.teacherId === tch.id && o.p === p));
    const p = gap.p;
    // lunch breaks the run between P4 and P5
    const run = (a, b) => busy(a) && busy(b) && !((a <= 4 && b >= 5) || (a <= 4 && p >= 5) || (p <= 4 && b >= 5));
    if (run(p - 2, p - 1) || run(p - 1, p + 1) || run(p + 1, p + 2)) {
      score -= w.consecutive; why.push({ en: 'would make 3 periods in a row', hi: 'लगातार 3 पीरियड हो जाएँगे', pts: -w.consecutive });
    }
    out.push({ id: tch.id, score, why });
  }
  out.sort((a, b) => b.score - a.score || nameOf(a.id).localeCompare(nameOf(b.id)));
  return out;
}

/* Build (or refresh) the substitution plan for a date.
   Manual choices that are still valid are kept. */
function generatePlan(date, by) {
  const gaps = computeGaps(date);
  const old = S.plans[date];
  if (!gaps.length) {
    if (old) { delete S.plans[date]; }
    return null;
  }
  const items = {};
  const placed = [];
  for (const g of gaps) {
    const prev = old && old.items[g.key];
    const ranked = rankCandidates(date, g, placed);
    let choice = null;
    if (prev && prev.manual && prev.teacherId && ranked.find(r => r.id === prev.teacherId)) choice = ranked.find(r => r.id === prev.teacherId);
    else if (prev && prev.teacherId && old.status === 'published' && ranked.find(r => r.id === prev.teacherId)) choice = ranked.find(r => r.id === prev.teacherId);
    else choice = ranked[0] || null;
    const item = {
      key: g.key, cls: g.cls, p: g.p, subject: g.subject, absentId: g.absentId,
      teacherId: choice ? choice.id : null, score: choice ? choice.score : null, why: choice ? choice.why : [],
      manual: !!(prev && prev.manual && choice && prev.teacherId === choice.id),
      alternatives: ranked.filter(r => !choice || r.id !== choice.id).slice(0, 2).map(r => ({ id: r.id, score: r.score })),
    };
    items[g.key] = item;
    if (item.teacherId) placed.push({ teacherId: item.teacherId, p: g.p });
  }
  const changed = !old || JSON.stringify(Object.values(old.items).map(i => [i.key, i.teacherId])) !== JSON.stringify(Object.values(items).map(i => [i.key, i.teacherId]));
  const status = old && old.status === 'published' && !changed ? 'published' : 'draft';
  S.plans[date] = {
    date, items, status,
    changedAfterPublish: !!(old && old.status === 'published' && changed) || !!(old && old.changedAfterPublish && status === 'draft'),
    updatedAt: nowStamp(), updatedBy: by || 'system', publishedAt: old ? old.publishedAt : null,
  };
  return S.plans[date];
}

/* Admin overrides one slot */
function setSubstitute(date, key, tid, by) {
  const plan = S.plans[date];
  if (!plan) return;
  const item = plan.items[key];
  const others = Object.values(plan.items).filter(i => i.key !== key && i.teacherId).map(i => ({ teacherId: i.teacherId, p: i.p }));
  const ranked = rankCandidates(date, item, others);
  const r = ranked.find(x => x.id === tid);
  item.teacherId = tid || null;
  item.score = r ? r.score : null;
  item.why = r ? r.why : [];
  item.manual = true;
  item.alternatives = ranked.filter(x => x.id !== tid).slice(0, 2).map(x => ({ id: x.id, score: x.score }));
  if (plan.status === 'published') { plan.status = 'draft'; plan.changedAfterPublish = true; }
  plan.updatedAt = nowStamp(); plan.updatedBy = by;
  logAudit(by, `Changed ${item.cls} P${item.p} on ${date} to ${tid ? nameOf(tid) : 'not covered'}`);
}

function publishPlan(date, by) {
  const plan = S.plans[date];
  if (!plan) return;
  plan.status = 'published';
  plan.changedAfterPublish = false;
  plan.publishedAt = nowStamp();
  const perTeacher = {};
  Object.values(plan.items).forEach(i => { if (i.teacherId) (perTeacher[i.teacherId] = perTeacher[i.teacherId] || []).push(i); });
  Object.entries(perTeacher).forEach(([tid, list]) => {
    const txt = list.map(i => `P${i.p} ${i.cls} ${SUBJECTS[i.subject].en}`).join(', ');
    notify(tid, `Arrangement on ${fmtDate(date)}: ${txt}`, { en: `Arrangement on ${fmtDate(date)}: ${txt}`, hi: `${fmtDate(date)} को अरेंजमेंट: ${txt}` });
  });
  logAudit(by, `Published substitution plan for ${date} (${Object.keys(plan.items).length} periods)`);
}

/* ---------- leave ---------- */
function eachSchoolDay(from, to, fn) { let d = from; let guard = 0; while (d <= to && guard++ < 60) { if (dayIdx(d) >= 0) fn(d); d = addDays(d, 1); } }

function decideLeave(id, approve, remark, by) {
  const lv = S.leaves.find(l => l.id === id);
  if (!lv) return;
  lv.status = approve ? 'approved' : 'rejected';
  lv.remark = remark || '';
  lv.decidedBy = by; lv.decidedAt = nowStamp();
  if (approve) {
    eachSchoolDay(lv.from, lv.to, d => {
      S.absences.push({ id: uid('ab'), teacherId: lv.teacherId, date: d, scope: lv.scope, periods: lv.periods, note: `${lv.type} leave`, source: 'leave', leaveId: lv.id, createdAt: nowStamp() });
      if (d >= todayISO()) generatePlan(d, by);
    });
  }
  notify(lv.teacherId, '', {
    en: `Your leave (${fmtDate(lv.from)}${lv.to !== lv.from ? ' – ' + fmtDate(lv.to) : ''}) was ${approve ? 'approved' : 'rejected'}${remark ? ': ' + remark : ''}`,
    hi: `आपकी छुट्टी (${fmtDate(lv.from)}${lv.to !== lv.from ? ' – ' + fmtDate(lv.to) : ''}) ${approve ? 'स्वीकृत' : 'अस्वीकृत'} हुई${remark ? ': ' + remark : ''}`,
  });
  logAudit(by, `${approve ? 'Approved' : 'Rejected'} leave of ${nameOf(lv.teacherId)} (${lv.from} to ${lv.to})`);
}

function addAbsence(tid, date, scope, periods, note, by) {
  S.absences.push({ id: uid('ab'), teacherId: tid, date, scope, periods, note, source: 'admin', createdAt: nowStamp() });
  generatePlan(date, by);
  logAudit(by, `Marked ${nameOf(tid)} absent on ${date} (${scope})`);
}
function removeAbsence(id, by) {
  const a = S.absences.find(x => x.id === id);
  if (!a) return;
  S.absences = S.absences.filter(x => x.id !== id);
  generatePlan(a.date, by);
  logAudit(by, `Removed absence of ${nameOf(a.teacherId)} on ${a.date}`);
}

/* ---------- notifications & audit ---------- */
function notify(userId, text, both) {
  S.notifications.unshift({ id: uid('nf'), userId, en: (both && both.en) || text, hi: (both && both.hi) || text, at: nowStamp(), read: false });
  if (S.notifications.length > 300) S.notifications.length = 300;
}
function notifyManagers(both) { S.staff.filter(s => isManager(s) && s.active).forEach(s => notify(s.id, '', both)); }
function logAudit(by, text) {
  S.audit.unshift({ id: uid('au'), at: nowStamp(), by, text });
  if (S.audit.length > 500) S.audit.length = 500;
}

/* ---------- reports ---------- */
function monthSubs(tid, ym) {
  let n = 0;
  for (const [dt, plan] of Object.entries(S.plans)) if (dt.startsWith(ym) && plan.status === 'published') n += Object.values(plan.items).filter(i => i.teacherId === tid).length;
  return n;
}
function monthLeaveDays(tid, ym) { return new Set(S.absences.filter(a => a.teacherId === tid && a.date.startsWith(ym)).map(a => a.date)).size; }

/* free teachers in a given day/period (used by the assistant) */
function freeTeachers(d, p, date) {
  return teachers().filter(tc => !teacherLessonAt(tc.id, d, p) && !(date && isAbsent(tc.id, date, p))).map(tc => tc.name);
}

/* "Seen" ticks are stored per teacher so teachers never edit the plan itself */
const ackId = (date, key, tid) => `${date}|${key}|${tid}`;
const isAcked = (date, key, tid) => !!(tid && S.acks[ackId(date, key, tid)]);

/* ===== Live data: Supabase login, loading, saving and live updates ===== */
const TABLES = ['staff', 'timetable', 'settings', 'absences', 'leaves', 'plans', 'requests', 'notices', 'notifications', 'audit', 'acks', 'attendance', 'syllabus', 'exams', 'config'];
const V2_TABLES = new Set(['attendance', 'syllabus', 'exams', 'config']);
const TEACHER_WRITABLE = new Set(['leaves', 'requests', 'notifications', 'audit', 'acks', 'syllabus']);
const NO_DELETE = new Set(['notifications', 'audit']);
let SB = null;                 // Supabase client
const LAST = {};               // what the server has: table -> Map(id -> JSON text)
let flushChain = Promise.resolve();
let renderPending = false, renderTimer = null;
const NET = { online: true, live: false, saving: false, error: '' };

function emptyState() {
  let lang = 'en';
  try { lang = localStorage.getItem('mts-lang') || 'en'; } catch (e) { }
  return {
    lang, session: null, staff: [], tt: {}, classTeachers: {}, absences: [], leaves: [], plans: {}, requests: [],
    notices: [], notifications: [], audit: [], acks: {}, curriculum: {}, customSubjects: {},
    attendance: [], syllabus: [], exams: [], config: {},
    settings: { subject: 30, classKnown: 20, classTeacher: 10, periodLoad: 5, weekSubs: 8, consecutive: 15, dailyCap: 2 },
  };
}
function saveLang() { try { localStorage.setItem('mts-lang', S.lang); } catch (e) { } }

/* ---------- local state <-> table rows ---------- */
function tableToMap(t) {
  switch (t) {
    case 'staff': return new Map(S.staff.map(x => [x.id, x]));
    case 'timetable': return new Map(Object.entries(S.tt));
    case 'settings': {
      const d = { weights: S.settings, classTeachers: S.classTeachers };
      if (Object.keys(S.curriculum).length) d.curriculum = S.curriculum;
      if (Object.keys(S.customSubjects).length) d.subjects = S.customSubjects;
      return new Map([['main', d]]);
    }
    case 'plans': return new Map(Object.entries(S.plans));
    case 'acks': return new Map(Object.entries(S.acks));
    case 'config': return new Map(Object.entries(S.config));
    default: return new Map(S[t].map(x => [x.id, x]));
  }
}
function applyRow(t, id, data) {
  const del = data == null;
  switch (t) {
    case 'staff': { const i = S.staff.findIndex(x => x.id === id); if (del) { if (i >= 0) S.staff.splice(i, 1); } else if (i >= 0) S.staff[i] = data; else S.staff.push(data); sortStaff(); break; }
    case 'timetable': if (del) delete S.tt[id]; else S.tt[id] = data; syncClasses(); break;
    case 'settings': if (!del && id === 'main') { S.settings = { ...S.settings, ...(data.weights || {}) }; S.classTeachers = data.classTeachers || {}; S.curriculum = data.curriculum || {}; S.customSubjects = data.subjects || {}; Object.assign(SUBJECTS, S.customSubjects); } break;
    case 'plans': if (del) delete S.plans[id]; else S.plans[id] = data; break;
    case 'acks': if (del) delete S.acks[id]; else S.acks[id] = data; break;
    case 'config': if (del) delete S.config[id]; else S.config[id] = data; break;
    default: {
      const arr = S[t]; const i = arr.findIndex(x => x.id === id);
      if (del) { if (i >= 0) arr.splice(i, 1); } else if (i >= 0) arr[i] = data; else arr.unshift(data);
    }
  }
}
function sortStaff() {
  const rank = { admin: 0, coordinator: 1, teacher: 2 };
  S.staff.sort((a, b) => (rank[a.role] ?? 3) - (rank[b.role] ?? 3) || a.name.localeCompare(b.name));
}
function syncClasses() {
  const sec = c => { const i = SECTION_ORDER.indexOf(c.replace(/^\d+[\s\-]*/, '').toUpperCase()); return i < 0 ? 99 : i; };
  const keys = Object.keys(S.tt).sort((a, b) => parseInt(a) - parseInt(b) || sec(a) - sec(b) || a.localeCompare(b));
  if (keys.length) { CLASSES.length = 0; keys.forEach(k => CLASSES.push(k)); }
}

/* ---------- load everything this person may see ---------- */
async function loadAll() {
  const results = await Promise.all(TABLES.map(t => {
    let q = SB.from(t).select('id,data');
    if (t === 'attendance') q = q.gte('data->>date', addDays(todayISO(), -70)).limit(5000);
    else if (t === 'notifications') q = q.order('updated_at', { ascending: false }).limit(200);
    else if (t === 'audit') q = q.order('updated_at', { ascending: false }).limit(300);
    else q = q.limit(5000);
    return q;
  }));
  const fresh = emptyState();
  fresh.lang = S.lang; fresh.session = S.session;
  S = fresh;
  S.v2Missing = false;
  results.forEach((res, k) => {
    const t = TABLES[k];
    if (res.error && V2_TABLES.has(t)) { S.v2Missing = true; LAST[t] = new Map(); return; }
    if (res.error) throw res.error;
    LAST[t] = new Map();
    res.data.forEach(r => { LAST[t].set(r.id, JSON.stringify(r.data)); });
    // newest first for lists that come ordered
    const rows = (t === 'notifications' || t === 'audit') ? res.data.slice().reverse() : res.data;
    rows.forEach(r => applyRow(t, r.id, r.data));
  });
  sortStaff(); syncClasses();
}

async function reloadTable(t) {
  let rq = SB.from(t).select('id,data');
  if (t === 'attendance') rq = rq.gte('data->>date', addDays(todayISO(), -70));
  const { data, error } = await rq.limit(5000);
  if (error) return;
  const keep = t === 'notifications' || t === 'audit';
  if (!keep) {
    if (t === 'staff') S.staff = []; else if (t === 'timetable') S.tt = {}; else if (t === 'plans') S.plans = {}; else if (t === 'acks') S.acks = {}; else if (t === 'config') S.config = {}; else if (t !== 'settings') S[t] = [];
  }
  LAST[t] = new Map();
  data.forEach(r => { LAST[t].set(r.id, JSON.stringify(r.data)); applyRow(t, r.id, r.data); });
}

/* ---------- save local changes ---------- */
function queueFlush() { flushChain = flushChain.then(flushNow, flushNow); return flushChain; }
async function flushNow() {
  const u = me();
  if (!u || !SB) return;
  const mgr = isManager(u);
  NET.saving = true; updateNetBadge();
  let failed = '', clashMsg = '';
  for (const t of TABLES) {
    if (!mgr && !TEACHER_WRITABLE.has(t)) continue;
    if (S.v2Missing && V2_TABLES.has(t)) continue;
    if (S.offline) continue;
    const cur = tableToMap(t), last = LAST[t] || (LAST[t] = new Map());
    const inserts = [], updates = [], dels = [];
    for (const [id, data] of cur) {
      const js = JSON.stringify(data);
      if (!last.has(id)) inserts.push({ id, data, js });
      else if (last.get(id) !== js) updates.push({ id, data, js });
    }
    if (!NO_DELETE.has(t)) for (const id of last.keys()) if (!cur.has(id)) dels.push(id);
    try {
      if (inserts.length) {
        const { error } = await SB.from(t).insert(inserts.map(r => ({ id: r.id, data: r.data })));
        if (error) throw error;
        inserts.forEach(r => last.set(r.id, r.js));
      }
      for (const r of updates) {
        const { data, error } = await SB.from(t).update({ data: r.data }).eq('id', r.id).select('id');
        if (error) throw error;
        if (!data || !data.length) throw { code: '42501', message: 'not allowed' };
        last.set(r.id, r.js);
      }
      if (dels.length) {
        const { error } = await SB.from(t).delete().in('id', dels);
        if (error) throw error;
        dels.forEach(id => last.delete(id));
      }
    } catch (e) {
      const clash = e && /^CLASH\|/.test(e.message || '');
      const denied = e && (e.code === '42501' || /row-level security|not allowed|permission/i.test(e.message || ''));
      if (clash) { const parts = e.message.split('|'); clashMsg = L(parts[1] || '', parts[2] || parts[1] || ''); await reloadTable(t); failed = 'clash'; }
      else if (denied) { await reloadTable(t); failed = failed === 'clash' ? failed : 'denied'; }
      else failed = failed || 'network';
    }
  }
  NET.saving = false;
  NET.error = failed;
  updateNetBadge();
  if (failed === 'clash') { toast('⛔ ' + clashMsg + ' ' + L('Not saved.', 'सहेजा नहीं गया।')); render(); }
  else if (failed === 'denied') { toast(L('That change is not allowed for your role — it was undone.', 'आपकी भूमिका में यह बदलाव अनुमत नहीं — वापस कर दिया गया।')); render(); }
  else if (failed === 'network') toast(L('Could not save — check internet. Will retry automatically.', 'सहेज नहीं सका — इंटरनेट जाँचें। अपने-आप फिर कोशिश होगी।'));
}
setInterval(() => { if (NET.error === 'network' && me()) queueFlush(); }, 20000);
window.addEventListener('online', () => { if (me()) queueFlush(); });

/* ---------- live updates from other phones ---------- */
let channel = null;
function subscribeLive() {
  if (channel) SB.removeChannel(channel);
  channel = SB.channel('mts-live')
    .on('postgres_changes', { event: '*', schema: 'public' }, payload => {
      const t = payload.table;
      if (!TABLES.includes(t)) return;
      const last = LAST[t] || (LAST[t] = new Map());
      if (payload.eventType === 'DELETE') {
        const id = payload.old && payload.old.id; if (!id) return;
        last.delete(id); applyRow(t, id, null);
      } else {
        const row = payload.new; if (!row || !row.id) return;
        const js = JSON.stringify(row.data);
        if (last.get(row.id) === js) return; // our own change coming back
        last.set(row.id, js); applyRow(t, row.id, row.data);
      }
      scheduleRender();
    })
    .subscribe(status => { NET.live = status === 'SUBSCRIBED'; updateNetBadge(); });
}

/* re-draw after live changes, but never while someone is typing or in a dialog */
function scheduleRender() {
  clearTimeout(renderTimer);
  renderTimer = setTimeout(() => {
    const a = document.activeElement;
    const typing = a && /INPUT|TEXTAREA|SELECT/.test(a.tagName);
    if (document.getElementById('modal-root').innerHTML || typing) { renderPending = true; setTimeout(scheduleRender, 1500); return; }
    renderPending = false; render();
  }, 200);
}

function updateNetBadge() {
  const el = document.getElementById('net');
  if (!el) return;
  el.className = 'net ' + (NET.error ? 'bad' : NET.saving ? 'busy' : NET.live ? 'ok' : 'busy');
  el.textContent = NET.error ? L('Not saved — offline', 'सहेजा नहीं — ऑफ़लाइन') : NET.saving ? L('Saving…', 'सहेज रहा है…') : NET.live ? L('Live · all changes saved', 'लाइव · सब सहेजा गया') : L('Connecting…', 'जुड़ रहा है…');
}

/* ---------- login ---------- */
async function ensureBrowserSession() {
  const { data: { session } } = await SB.auth.getSession();
  if (session) return true;
  const { error } = await SB.auth.signInAnonymously();
  return !error;
}
const LOGIN_ERRORS = {
  unregistered: ['This number is not registered. Please contact the school office.', 'यह नंबर पंजीकृत नहीं है। कृपया स्कूल ऑफ़िस से संपर्क करें।'],
  inactive: ['This account is deactivated. Please contact the school office.', 'यह अकाउंट निष्क्रिय है। कृपया स्कूल ऑफ़िस से संपर्क करें।'],
  locked: ['Too many wrong tries. Please wait 15 minutes or ask the office to reset your PIN.', 'बहुत बार गलत प्रयास। 15 मिनट रुकें या ऑफ़िस से PIN रीसेट करवाएँ।'],
  bad_pin: ['Wrong PIN. Try again.', 'गलत PIN। फिर कोशिश करें।'],
  bad_code: ['Wrong activation code. Check with the school office.', 'गलत एक्टिवेशन कोड। स्कूल ऑफ़िस से पूछें।'],
  bad_pin_format: ['PIN must be exactly 6 digits.', 'PIN ठीक 6 अंकों का होना चाहिए।'],
  already_active: ['This number is already activated. Log in with your PIN.', 'यह नंबर पहले से सक्रिय है। अपने PIN से लॉगिन करें।'],
  needs_activation: ['Please activate first with the code from the office.', 'पहले ऑफ़िस से मिले कोड से सक्रिय करें।'],
  not_signed_in: ['Could not connect. Check internet and try again.', 'कनेक्ट नहीं हो सका। इंटरनेट जाँचकर फिर कोशिश करें।'],
  network: ['Could not connect. Check internet and try again.', 'कनेक्ट नहीं हो सका। इंटरनेट जाँचकर फिर कोशिश करें।'],
};
const loginErr = k => { const m = LOGIN_ERRORS[k] || LOGIN_ERRORS.network; return L(m[0], m[1]); };

async function enterApp(staffId) {
  S.session = { userId: staffId };
  showLoading(L('Loading school data…', 'स्कूल डेटा लोड हो रहा है…'));
  try { await loadAll(); }
  catch (e) {
    if (loadOfflineCopy()) { UI.date = todayISO(); render(); return; }
    showFatal(L('Could not load data. Check internet and refresh the page.', 'डेटा लोड नहीं हुआ। इंटरनेट जाँचकर पेज रीफ़्रेश करें।')); return;
  }
  if (!me()) { S.session = null; UI.loginStep = 'phone'; render(); return; }
  UI.view = null; UI.date = todayISO();
  subscribeLive();
  render();
  saveOfflineCopy(); registerSW(); notifWatch();
  setTimeout(maybeCheckInPopup, 600);
}

async function doLogout() {
  try { await SB.rpc('logout'); } catch (e) { }
  if (channel) { SB.removeChannel(channel); channel = null; }
  const lang = S.lang;
  S = emptyState(); S.lang = lang;
  try { localStorage.removeItem(CACHE_KEY); } catch (e) { }
  UI.loginStep = 'phone'; UI.loginPhone = ''; UI.loginError = ''; UI.chat = []; UI.view = null;
  render();
}

function showLoading(msg) {
  document.getElementById('app').innerHTML = `<div class="login-wrap"><div class="login-card"><img class="login-logo" src="${LOGO_SRC}" alt="MTS logo"><h1>${SCHOOL.name}</h1><p class="muted">${esc(msg)}</p><div class="spinner"></div></div></div>`;
}
function showFatal(msg) {
  document.getElementById('app').innerHTML = `<div class="login-wrap"><div class="login-card"><img class="login-logo" src="${LOGO_SRC}" alt="MTS logo"><h1>${SCHOOL.name}</h1><div class="error">${esc(msg)}</div><button class="btn primary block" onclick="location.reload()">${L('Try again', 'फिर कोशिश करें')}</button></div></div>`;
}

async function boot() {
  S = emptyState();
  UI.date = todayISO();
  UI.loginStep = 'phone';
  const h = (location.hash || '').replace('#', '');
  showLoading(L('Connecting…', 'जुड़ रहा है…'));
  if (!window.supabase || !APP_CONFIG.url) { showFatal('App is not configured yet.'); return; }
  SB = window.supabase.createClient(APP_CONFIG.url, APP_CONFIG.key, { auth: { persistSession: true, autoRefreshToken: true, storageKey: 'mts-auth' } });
  const timer = setTimeout(() => { if (loadOfflineCopy()) { UI.date = todayISO(); render(); return; } showFatal(L('Could not connect. Check internet and refresh the page.', 'कनेक्ट नहीं हो सका। इंटरनेट जाँचकर पेज रीफ़्रेश करें।')); }, 20000);
  try {
    if (!(await ensureBrowserSession())) throw new Error('auth');
    const { data: sid, error } = await SB.rpc('my_staff_id');
    clearTimeout(timer);
    if (error) throw error;
    if (sid) { await enterApp(sid); if (h) { UI.view = h; render(); } }
    else render();
  } catch (e) {
    clearTimeout(timer);
    if (loadOfflineCopy()) { UI.date = todayISO(); registerSW(); render(); return; }
    showFatal(L('Could not connect. Check internet and refresh the page.', 'कनेक्ट नहीं हो सका। इंटरनेट जाँचकर पेज रीफ़्रेश करें।'));
  }
}

/* ===== Screens and interaction ===== */
const UI = {
  view: null, date: null, menuOpen: false,
  ttMode: 'class', ttClass: '6A', ttTeacher: 't1',
  reqTab: 'all', leaveTab: 'pending', reportMonth: null,
  loginStep: 1, loginPhone: '', loginError: '',
  chat: [], chatBusy: false, loginBusy: false, codes: null,
};

const t = k => (I18N[S.lang] && I18N[S.lang][k]) || I18N.en[k] || k;
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const me = () => S.session && staffById(S.session.userId);
const L = (en, hi) => (S.lang === 'hi' ? hi : en);
const dayName = d => (S.lang === 'hi' ? DAYS_HI[d] : DAYS_LONG[d]);
const statusChip = st => `<span class="chip st-${esc(st)}">${esc(t(st))}</span>`;
const avatar = name => `<span class="avatar">${esc(name.split(' ').map(w => w[0]).slice(0, 2).join(''))}</span>`;

function teacherOptions(selected, { includeEmpty = false, emptyLabel = '—' } = {}) {
  return (includeEmpty ? `<option value="">${esc(emptyLabel)}</option>` : '') +
    teachers().map(x => `<option value="${x.id}" ${x.id === selected ? 'selected' : ''}>${esc(x.name)}</option>`).join('');
}
function classOptions(selected) { return CLASSES.map(c => `<option ${c === selected ? 'selected' : ''}>${c}</option>`).join(''); }
function subjectOptions(selected) { return Object.keys(SUBJECTS).map(s => `<option value="${s}" ${s === selected ? 'selected' : ''}>${esc(subjName(s))}</option>`).join(''); }
function periodTime(p) { const x = PERIODS[p - 1]; return `${x.start}–${x.end}`; }

/* ---------- modal & toast ---------- */
function openModal(title, body, { wide = false } = {}) {
  const root = document.getElementById('modal-root');
  root.innerHTML = `<div class="modal-back" data-act="closeModalBack"><div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
    <div class="modal-head"><h3>${esc(title)}</h3><button class="icon-btn" data-act="closeModal" aria-label="${esc(t('close'))}">✕</button></div>
    <div class="modal-body">${body}</div></div></div>`;
  const first = root.querySelector('input,select,textarea');
  if (first) setTimeout(() => first.focus(), 30);
}
function closeModal() { document.getElementById('modal-root').innerHTML = ''; if (renderPending) { renderPending = false; render(); } }
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove('show'), 2600);
}
function confirmBox(text, onYes, yesLabel) {
  openModal(L('Please confirm', 'कृपया पुष्टि करें'), `<p>${esc(text)}</p><div class="row-end"><button class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn danger" data-act="confirmYes">${esc(yesLabel || 'OK')}</button></div>`);
  confirmBox._fn = onYes;
}
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); toast(L('Copied', 'कॉपी हो गया')); }
  catch (e) { openModal(L('Copy this text', 'यह टेक्स्ट कॉपी करें'), `<textarea class="copybox" rows="12" readonly>${esc(text)}</textarea>`, { wide: true }); }
}

/* ---------- navigation ---------- */
function navItems(u) {
  if (isManager(u)) return [
    ['dashboard', '🏠'], ['attendance', '✅'], ['subs', '🔁'], ['leave', '📝'], ['timetable', '📅'], ['builder', '🛠️'], ['requests', '📄'],
    ['syllabus', '📚'], ['exams', '📝'], ['staff', '👥'], ['reports', '📊'], ['assistant', '✨'], ['notices', '📢'], ['audit', '🧾'], ['settings', '⚙️'],
  ];
  return [['myday', '🏠'], ['attendance', '✅'], ['timetable', '📅'], ['leave', '📝'], ['syllabus', '📚'], ['exams', '🗒️'], ['requests', '📄'], ['assistant', '✨'], ['notices', '📢']];
}
const VIEW_LABEL = { dashboard: 'dashboard', subs: 'substitutions', leave: 'leave', timetable: 'timetable', requests: 'requests', staff: 'staff', reports: 'reports', assistant: 'assistant', notices: 'notices', audit: 'audit', settings: 'settings', myday: 'myDay', builder: 'builder', attendance: 'attendance', syllabus: 'syllabus', exams: 'exams' };

function go(view) { UI.view = view; UI.menuOpen = false; if (view === 'staff') UI.codes = null; try { history.replaceState(null, '', '#' + view); } catch (e) { } render(); window.scrollTo(0, 0); }

/* ---------- render ---------- */
function render() {
  const app = document.getElementById('app');
  document.documentElement.lang = S.lang === 'hi' ? 'hi' : 'en';
  const u = me();
  if (!u) { app.innerHTML = viewLogin(); return; }
  if (needsCheckIn(u)) { app.innerHTML = checkInLockHTML(u); return; }
  const items = navItems(u);
  if (!UI.view || !items.find(i => i[0] === UI.view)) UI.view = items[0][0];
  const unread = S.notifications.filter(n => n.userId === u.id && !n.read).length;
  app.innerHTML = `
  <header class="topbar">
    <button class="icon-btn menu-btn" data-act="toggleMenu" aria-label="Menu">☰</button>
    <img class="logo" src="${LOGO_SRC}" alt="MTS logo">
    <div class="brand"><strong>${SCHOOL.name}</strong><span>${SCHOOL.place}</span></div>
    <div class="top-actions">
      <button class="icon-btn" data-act="cycleTheme" aria-label="${esc(L('Light or dark theme', 'लाइट या डार्क थीम'))}" title="${esc(L('Light or dark theme', 'लाइट या डार्क थीम'))}">${themeIcon()}</button>
      <button class="btn ghost small" data-act="toggleLang">${t('language')}</button>
      <button class="icon-btn bell" data-act="openNotifications" aria-label="${t('notifications')}">🔔${unread ? `<b>${unread}</b>` : ''}</button>
      <div class="me">${avatar(u.name)}<div><strong>${esc(u.name)}</strong><span>${esc(roleLabel(u.role))}</span></div></div>
    </div>
  </header>
  <div class="layout">
    <nav class="sidebar ${UI.menuOpen ? 'open' : ''}">
      ${items.map(([v, ic]) => `<button class="nav ${UI.view === v ? 'active' : ''}" data-act="go" data-view="${v}"><span>${ic}</span>${esc(t(VIEW_LABEL[v]))}</button>`).join('')}
      <button class="nav lang-mobile" data-act="toggleLang"><span>🌐</span>${t('language')}</button>
      <button class="nav logout" data-act="logout"><span>🚪</span>${t('logout')}</button>
      <div id="net" class="net busy"></div>
    </nav>
    ${UI.menuOpen ? '<div class="menu-back" data-act="toggleMenu"></div>' : ''}
    <main class="content">${S.offline ? `<div class="banner warn">📴 ${L('Offline — showing the copy saved on this phone at', 'ऑफ़लाइन — इस फ़ोन पर सहेजी गई कॉपी, समय')} ${fmtTime(S.offline)}. ${L('Changes cannot be saved until you are online.', 'ऑनलाइन होने तक बदलाव सहेजे नहीं जा सकते।')} <button class="btn tiny" data-act="reloadPage">↻ ${L('Retry', 'फिर कोशिश')}</button></div>` : ''}${S.v2Missing && isManager(u) ? `<div class="banner bad">${L('The database update for the new features has not been run yet, so attendance, syllabus and exam duties are off.', 'नई सुविधाओं का डेटाबेस अपडेट अभी नहीं चला है, इसलिए हाज़िरी, पाठ्यक्रम और परीक्षा ड्यूटी बंद हैं।')}</div>` : ''}${renderView(UI.view)}</main>
  </div>
  <nav class="bottomnav">${(isManager(u) ? ['dashboard', 'subs', 'leave', 'assistant'] : ['myday', 'timetable', 'leave', 'assistant']).map(v => { const it = items.find(i => i[0] === v); return `<button class="${UI.view === v ? 'active' : ''}" data-act="go" data-view="${v}"><span>${it[1]}</span>${esc(v === 'assistant' ? L('Ask', 'पूछें') : t(VIEW_LABEL[v]).split(' ')[0])}</button>`; }).join('')}<button data-act="toggleMenu"><span>☰</span>${L('More', 'और')}</button></nav>`;
  if (UI.view === 'assistant') { const log = document.querySelector('.chat-log'); if (log) log.scrollTop = log.scrollHeight; }
  if (UI.view === 'staff' && UI.codes === null && !UI.codesLoading) refreshCodes();
  if (UI.view === 'notices' && !isManager(u)) setTimeout(markNoticesRead, 50);
  updateNetBadge();
  notifWatch();
  clearTimeout(window.__snapT); window.__snapT = setTimeout(saveOfflineCopy, 3000);
}
function roleLabel(r) { return { admin: L('Admin', 'एडमिन'), coordinator: L('Coordinator', 'कोऑर्डिनेटर'), teacher: L('Teacher', 'शिक्षक') }[r] || r; }

function renderView(v) {
  switch (v) {
    case 'dashboard': return viewDashboard();
    case 'subs': return viewSubs();
    case 'leave': return viewLeave();
    case 'timetable': return viewTimetable();
    case 'requests': return viewRequests();
    case 'staff': return viewStaff();
    case 'reports': return viewReports();
    case 'assistant': return viewAssistant();
    case 'notices': return viewNotices();
    case 'audit': return viewAudit();
    case 'settings': return viewSettings();
    case 'myday': return viewMyDay();
    case 'builder': return viewBuilder();
    case 'attendance': return viewAttendance();
    case 'syllabus': return viewSyllabus();
    case 'exams': return viewExams();
  }
  return '';
}

/* ---------- login ---------- */
function viewLogin() {
  const step = UI.loginStep || 'phone';
  const busy = UI.loginBusy ? 'disabled' : '';
  let body = '';
  if (step === 'phone') body = `
    <form data-form="loginPhone" class="stack">
      <label>${t('mobile')}<div class="phone-in"><span>+91</span><input name="phone" inputmode="numeric" maxlength="10" placeholder="98XXXXXXXX" value="${esc(UI.loginPhone)}" required autocomplete="tel-national"></div></label>
      ${UI.loginError ? `<div class="error">${esc(UI.loginError)}</div>` : ''}
      <button class="btn primary block" type="submit" ${busy}>${UI.loginBusy ? L('Checking…', 'जाँच रहा है…') : L('Continue', 'आगे बढ़ें')}</button>
    </form>`;
  else if (step === 'pin') body = `
    <form data-form="loginPin" class="stack">
      <p>${L('Welcome back', 'फिर से स्वागत है')} · <strong>+91 ${esc(UI.loginPhone)}</strong></p>
      <label>${L('Your 6-digit PIN', 'आपका 6 अंकों का PIN')}<input name="pin" type="password" inputmode="numeric" maxlength="6" pattern="[0-9]{6}" required autocomplete="current-password"></label>
      ${UI.loginError ? `<div class="error">${esc(UI.loginError)}</div>` : ''}
      <button class="btn primary block" type="submit" ${busy}>${UI.loginBusy ? L('Logging in…', 'लॉगिन हो रहा है…') : L('Log in', 'लॉगिन करें')}</button>
      <p class="hint">${L('Forgot your PIN? Ask the school office for a new activation code.', 'PIN भूल गए? स्कूल ऑफ़िस से नया एक्टिवेशन कोड लें।')}</p>
      <button class="btn ghost block" type="button" data-act="loginBack">${L('Change number', 'नंबर बदलें')}</button>
    </form>`;
  else body = `
    <form data-form="loginActivate" class="stack">
      <p>${L('First time on this app', 'इस ऐप पर पहली बार')} · <strong>+91 ${esc(UI.loginPhone)}</strong></p>
      <label>${L('Activation code from the school office', 'स्कूल ऑफ़िस से मिला एक्टिवेशन कोड')}<input name="code" inputmode="numeric" maxlength="6" pattern="[0-9]{6}" required autocomplete="one-time-code"></label>
      <label>${L('Choose a 6-digit PIN', '6 अंकों का PIN चुनें')}<input name="pin" type="password" inputmode="numeric" maxlength="6" pattern="[0-9]{6}" required autocomplete="new-password"></label>
      <label>${L('Type the PIN again', 'PIN फिर से लिखें')}<input name="pin2" type="password" inputmode="numeric" maxlength="6" pattern="[0-9]{6}" required autocomplete="new-password"></label>
      ${UI.loginError ? `<div class="error">${esc(UI.loginError)}</div>` : ''}
      <button class="btn primary block" type="submit" ${busy}>${UI.loginBusy ? L('Activating…', 'सक्रिय हो रहा है…') : L('Activate & log in', 'सक्रिय करें और लॉगिन')}</button>
      <button class="btn ghost block" type="button" data-act="loginBack">${L('Change number', 'नंबर बदलें')}</button>
    </form>`;
  return `<div class="login-wrap">
    <div class="login-card">
      <img class="login-logo" src="${LOGO_SRC}" alt="MTS logo">
      <h1>${SCHOOL.name}</h1>
      <p class="muted">${SCHOOL.place} · ${t('loginTitle')}</p>
      ${body}
      <button class="btn ghost small center" data-act="toggleLang">${t('language')}</button>
    </div>
  </div>`;
}

/* ---------- date bar ---------- */
function dateBar(extra = '') {
  return `<div class="datebar">
    <button class="icon-btn" data-act="shiftDate" data-n="-1" aria-label="Previous day">‹</button>
    <input type="date" value="${UI.date}" data-change="setDate">
    <button class="icon-btn" data-act="shiftDate" data-n="1" aria-label="Next day">›</button>
    <button class="btn small ghost" data-act="dateToday">${t('today')}</button>
    <span class="dayname">${dayIdx(UI.date) >= 0 ? dayName(dayIdx(UI.date)) : esc(closedName(UI.date))}</span>
    ${extra}
  </div>`;
}

/* ---------- dashboard (admin / coordinator) ---------- */
function viewDashboard() {
  const date = UI.date;
  const abs = absencesOn(date);
  const gaps = computeGaps(date);
  const plan = S.plans[date];
  const unfilled = plan ? Object.values(plan.items).filter(i => !i.teacherId).length : gaps.length;
  const pendingLv = S.leaves.filter(l => l.status === 'pending');
  const openReq = S.requests.filter(r => ['requested', 'approved', 'in_progress', 'ready'].includes(r.status));
  const newReq = S.requests.filter(r => r.status === 'requested');
  return `
  <div class="page-head"><h2>${t('dashboard')}</h2>${dateBar()}</div>
  ${dayIdx(date) < 0 ? `<div class="banner">${esc(noSchoolMsg(date))}</div>` : ''}
  ${startCardHTML()}
  <form data-form="quickAsk" class="quickask"><span>⚡</span><input name="q" placeholder="${esc(L('Ask anything — e.g. who is free in period 5?', 'कुछ भी पूछें — जैसे पीरियड 5 में कौन खाली है?'))}" autocomplete="off"><button type="button" class="icon-btn mic" data-act="voice" aria-label="${esc(L('Ask by voice', 'बोलकर पूछें'))}">🎤</button><button class="btn primary">${t('ask')}</button></form>
  <div class="cards">
    <div class="stat"><span>${t('absentToday')}</span><b>${new Set(abs.map(a => a.teacherId)).size}</b></div>
    <div class="stat"><span>${t('toCover')}</span><b>${gaps.length}</b></div>
    <div class="stat ${unfilled ? 'warn' : ''}"><span>${t('unfilled')}</span><b>${unfilled}</b></div>
    <div class="stat"><span>${t('pendingLeave')}</span><b>${pendingLv.length}</b></div>
    <div class="stat"><span>${t('openRequests')}</span><b>${openReq.length}</b></div>
  </div>
  ${dashAttendanceHTML(date)}
  <div class="grid2">
    <section class="panel">
      <div class="panel-head"><h3>${L('Absent on', 'अनुपस्थित —')} ${fmtDate(date)}</h3><button class="btn small primary" data-act="markAbsentDialog">+ ${t('markAbsent')}</button></div>
      ${abs.length ? `<ul class="list">${abs.map(a => `<li><div>${avatar(nameOf(a.teacherId))}<div><strong>${esc(nameOf(a.teacherId))}</strong><small>${esc(absenceLabel(a))}${a.note ? ' · ' + esc(a.note) : ''}</small></div></div>
        <button class="btn tiny ghost" data-act="removeAbsence" data-id="${a.id}">${L('Remove', 'हटाएँ')}</button></li>`).join('')}</ul>`
        : `<p class="muted">${L('Everyone is present.', 'सभी उपस्थित हैं।')}</p>`}
    </section>
    <section class="panel">
      <div class="panel-head"><h3>${L('Arrangement plan', 'अरेंजमेंट योजना')}</h3>${plan ? statusChip(plan.status) : ''}</div>
      ${gaps.length ? `<p>${L(`${gaps.length} periods need a teacher. ${unfilled ? unfilled + ' not covered yet.' : 'All have a suggested substitute.'}`, `${gaps.length} पीरियड में शिक्षक चाहिए। ${unfilled ? unfilled + ' अभी खाली हैं।' : 'सभी के लिए शिक्षक सुझाए गए हैं।'}`)}</p>
        ${plan && plan.changedAfterPublish ? `<div class="banner warn">${L('Plan changed after publishing — publish again.', 'प्रकाशन के बाद बदलाव हुआ — फिर से प्रकाशित करें।')}</div>` : ''}
        <button class="btn primary" data-act="go" data-view="subs">${L('Review & publish', 'देखें और प्रकाशित करें')} →</button>`
        : `<p class="muted">${L('No periods to cover.', 'कोई पीरियड खाली नहीं है।')}</p>`}
    </section>
    <section class="panel">
      <div class="panel-head"><h3>${t('pendingLeave')}</h3><button class="btn small ghost" data-act="go" data-view="leave">${L('All', 'सभी')} →</button></div>
      ${pendingLv.length ? `<ul class="list">${pendingLv.slice(0, 4).map(l => `<li><div>${avatar(nameOf(l.teacherId))}<div><strong>${esc(nameOf(l.teacherId))}</strong><small>${fmtDate(l.from)}${l.to !== l.from ? ' – ' + fmtDate(l.to) : ''} · ${esc(l.type)}</small></div></div>
        <div class="btns"><button class="btn tiny ok" data-act="leaveDecide" data-id="${l.id}" data-ok="1">${t('approve')}</button><button class="btn tiny danger-ghost" data-act="leaveDecide" data-id="${l.id}" data-ok="0">${t('reject')}</button></div></li>`).join('')}</ul>`
        : `<p class="muted">${L('Nothing waiting.', 'कुछ लंबित नहीं।')}</p>`}
    </section>
    <section class="panel">
      <div class="panel-head"><h3>${L('New DPP & worksheet requests', 'नए DPP और वर्कशीट अनुरोध')}</h3><button class="btn small ghost" data-act="go" data-view="requests">${L('All', 'सभी')} →</button></div>
      ${newReq.length ? `<ul class="list">${newReq.slice(0, 4).map(r => `<li><div><span class="kind ${r.kind}">${r.kind === 'dpp' ? 'DPP' : t('worksheet')}</span><div><strong>${esc(r.classId)} · ${esc(subjName(r.subject))}</strong><small>${esc(nameOf(r.teacherId))} · ${L('needed by', 'चाहिए')} ${fmtDate(r.neededBy)}</small></div></div></li>`).join('')}</ul>`
        : `<p class="muted">${L('No new requests.', 'कोई नया अनुरोध नहीं।')}</p>`}
    </section>
  </div>`;
}

/* first-time checklist for Admin / Coordinator */
function startCardHTML() {
  let hidden = false; try { hidden = localStorage.getItem('mts-start-hidden') === '1'; } catch (e) { }
  if (hidden) return '';
  const sample = S.staff.some(s => /^90000001\d\d$/.test(s.phone)) || S.staff.some(s => s.phone === '9000000001');
  const steps = [
    [!S.staff.some(s => s.phone === '9000000001'), L('Change the Admin mobile number to your own', 'एडमिन का मोबाइल नंबर अपना करें'), 'staff'],
    [!sample, L('Replace the sample teachers with your real staff', 'नमूना शिक्षकों की जगह अपने असली स्टाफ़ जोड़ें'), 'staff'],
    [Object.keys(S.curriculum).length > 0, L('Set subjects and build your timetable', 'विषय तय करें और अपनी समय-सारणी बनाएँ'), 'builder'],
    [S.staff.filter(s => s.active).length > 1 && !sample, L('Share activation codes with staff (Staff screen → Share)', 'स्टाफ़ को एक्टिवेशन कोड भेजें (स्टाफ़ स्क्रीन → भेजें)'), 'staff'],
  ];
  if (steps.every(s => s[0])) return '';
  return `<section class="panel start"><div class="panel-head"><h3>🚀 ${L('Getting started', 'शुरुआत करें')} · ${steps.filter(s => s[0]).length}/${steps.length}</h3><button class="btn tiny ghost" data-act="hideStart">${L('Hide', 'छिपाएँ')}</button></div>
    <ol class="steps">${steps.map(([done, label, view]) => `<li class="${done ? 'done' : ''}"><span>${done ? '✓' : ''}</span><button class="linkbtn" data-act="go" data-view="${view}">${esc(label)}</button></li>`).join('')}</ol></section>`;
}

/* ---------- substitution plan ---------- */
function whyText(item) {
  if (!item.teacherId) return `<span class="bad">${L('Nobody free — merge classes or use library period', 'कोई खाली नहीं — कक्षाएँ मिलाएँ या पुस्तकालय पीरियड दें')}</span>`;
  return esc(item.why.map(w => (S.lang === 'hi' ? w.hi : w.en) + ` (${w.pts > 0 ? '+' : ''}${w.pts})`).join(' · ')) + ` <b class="score">= ${item.score}</b>`;
}
function viewSubs() {
  const date = UI.date;
  const d = dayIdx(date);
  const abs = absencesOn(date);
  const plan = S.plans[date];
  const gaps = computeGaps(date);
  let body = '';
  if (d < 0) body = `<div class="banner">${esc(noSchoolMsg(date))}</div>`;
  else if (!gaps.length) body = `<div class="empty">✅ ${L('No periods to cover on this day.', 'इस दिन कोई पीरियड खाली नहीं है।')}</div>`;
  else {
    const items = Object.values(plan.items).sort((a, b) => a.p - b.p || CLASSES.indexOf(a.cls) - CLASSES.indexOf(b.cls));
    body = `
    <div class="plan-status">${statusChip(plan.status)}
      <span class="muted">${L('Updated', 'अपडेट')} ${fmtTime(plan.updatedAt)} · ${esc(nameOf(plan.updatedBy))}${plan.publishedAt ? ` · ${L('Published', 'प्रकाशित')} ${fmtTime(plan.publishedAt)}` : ''}</span>
      ${plan.changedAfterPublish ? `<span class="chip st-rejected">${L('Changed — publish again', 'बदला गया — फिर प्रकाशित करें')}</span>` : ''}
    </div>
    <div class="table-wrap"><table class="subs">
      <thead><tr><th>${t('period')}</th><th>${t('class')}</th><th>${t('subject')}</th><th>${L('Absent teacher', 'अनुपस्थित शिक्षक')}</th><th>${L('Substitute', 'अरेंजमेंट शिक्षक')}</th><th>${L('Why this teacher', 'क्यों यह शिक्षक')}</th><th>${t('seen')}</th></tr></thead>
      <tbody>${items.map(i => {
        const others = items.filter(o => o.key !== i.key && o.teacherId).map(o => ({ teacherId: o.teacherId, p: o.p }));
        const ranked = rankCandidates(date, i, others);
        const opts = ranked.map(r => `<option value="${r.id}" ${r.id === i.teacherId ? 'selected' : ''}>${esc(nameOf(r.id))} (${r.score})</option>`).join('');
        return `<tr class="${i.teacherId ? '' : 'row-bad'}">
          <td data-label="${esc(t('period'))}"><b>P${i.p}</b><small>${periodTime(i.p)}</small></td>
          <td data-label="${esc(t('class'))}">${esc(i.cls)}</td><td data-label="${esc(t('subject'))}">${esc(subjName(i.subject))}</td><td data-label="${esc(L('Absent', 'अनुपस्थित'))}">${esc(nameOf(i.absentId))}</td>
          <td data-label="${esc(L('Substitute', 'अरेंजमेंट'))}"><select data-change="setSub" data-key="${esc(i.key)}" aria-label="Substitute for ${esc(i.cls)} period ${i.p}"><option value="">— ${L('Not covered', 'खाली')} —</option>${opts}</select>${i.manual ? `<small class="muted">${L('changed by hand', 'हाथ से बदला')}</small>` : ''}</td>
          <td class="why" data-label="${esc(L('Why', 'क्यों'))}">${whyText(i)}</td>
          <td data-label="${esc(t('seen'))}">${plan.status === 'published' && i.teacherId ? (isAcked(date, i.key, i.teacherId) ? '<span class="ok-text">✓</span>' : `<span class="muted">${L('not yet', 'अभी नहीं')}</span>`) : '—'}</td></tr>`;
      }).join('')}</tbody></table></div>
    ${waPanelHTML(date, plan)}
    <div class="row-end">
      <button class="btn ghost" data-act="copySheet">📋 ${t('copySheet')}</button>
      <button class="btn ghost" data-act="printSheet">📄 PDF</button>
      <button class="btn" data-act="replan">↻ ${t('regenerate')}</button>
      <button class="btn primary" data-act="publishPlan">${plan.status === 'published' ? '✓ ' + t('published') : t('publish')}</button>
    </div>
    <details class="howto"><summary>${L('How the app picks a substitute', 'ऐप शिक्षक कैसे चुनता है')}</summary>
      <p>${L('Only teachers who are present, free in that period and under the daily limit are considered. Each gets points:', 'केवल वही शिक्षक जो उपस्थित हैं, उस पीरियड में खाली हैं और दैनिक सीमा से कम हैं। अंक:')}</p>
      <ul><li>${L('Same subject', 'वही विषय')} +${S.settings.subject}</li><li>${L('Already teaches the class', 'उस कक्षा को पढ़ाते हैं')} +${S.settings.classKnown}</li><li>${L('Class teacher', 'कक्षा-शिक्षक')} +${S.settings.classTeacher}</li>
      <li>${L('Each period already today', 'आज के हर पीरियड पर')} −${S.settings.periodLoad}</li><li>${L('Each substitution this week', 'इस सप्ताह के हर अरेंजमेंट पर')} −${S.settings.weekSubs}</li><li>${L('3 periods in a row', 'लगातार 3 पीरियड')} −${S.settings.consecutive}</li>
      <li>${L('Daily limit', 'दैनिक सीमा')}: ${S.settings.dailyCap} ${L('substitutions', 'अरेंजमेंट')}</li></ul></details>`;
  }
  return `
  <div class="page-head"><h2>${t('substitutions')}</h2>${dateBar(`<button class="btn small primary" data-act="markAbsentDialog">+ ${t('markAbsent')}</button>`)}</div>
  ${abs.length ? `<div class="absent-chips">${abs.map(a => `<span class="achip">${esc(nameOf(a.teacherId))} · ${esc(absenceLabel(a))}<button data-act="removeAbsence" data-id="${a.id}" aria-label="Remove">✕</button></span>`).join('')}</div>` : ''}
  ${body}`;
}

function sheetText(date) {
  const plan = S.plans[date];
  if (!plan) return '';
  const rows = Object.values(plan.items).sort((a, b) => a.p - b.p);
  return `${SCHOOL.name}, ${SCHOOL.place}\nArrangement (substitution) sheet — ${fmtDate(date)}\n\n` +
    rows.map(i => `P${i.p} (${periodTime(i.p)})  ${i.cls}  ${SUBJECTS[i.subject].en}  —  ${i.teacherId ? nameOf(i.teacherId) : 'NOT COVERED'}  (for ${nameOf(i.absentId)})`).join('\n');
}

/* ---------- teacher: my day ---------- */
function viewMyDay() {
  const u = me();
  const date = UI.date;
  const d = dayIdx(date);
  const plan = S.plans[date];
  const subs = plan && plan.status === 'published' ? Object.values(plan.items).filter(i => i.teacherId === u.id) : [];
  const myAbs = S.absences.filter(a => a.teacherId === u.id && a.date === date);
  let rows = '';
  if (d >= 0) {
    PERIODS.forEach(pp => {
      const p = pp.n;
      const l = teacherLessonAt(u.id, d, p);
      const sub = subs.find(i => i.p === p);
      const absent = isAbsent(u.id, date, p);
      let cell;
      if (absent) cell = `<div class="slot off">${l ? `<s>${esc(l.label)} · ${esc(subjName(l.s))}</s> · ` : ''}${t('onLeave')}</div>`;
      else if (sub) cell = `<div class="slot sub"><b>${t('substitution')}:</b> ${esc(sub.cls)} · ${esc(subjName(sub.subject))} <small>(${t('forTeacher')} ${esc(nameOf(sub.absentId))})</small>
        ${isAcked(date, sub.key, u.id) ? `<span class="ok-text">✓ ${t('seen')}</span>` : `<button class="btn tiny primary" data-act="ackSub" data-key="${esc(sub.key)}">${t('markSeen')}</button>`}</div>`;
      else if (l) cell = `<div class="slot"><b>${esc(l.label)}</b> · ${esc(subjName(l.s))}</div>`;
      else cell = `<div class="slot free">${t('free')}</div>`;
      rows += `<li class="${date === todayISO() && currentPeriod() === p ? 'now' : ''}"><div class="ptime"><b>P${p}</b><small>${periodTime(p)}</small>${date === todayISO() && currentPeriod() === p ? `<em>${L('NOW', 'अभी')}</em>` : ''}</div>${cell}</li>`;
      if (p === LUNCH.after) rows += `<li class="lunch"><div class="ptime"><small>${LUNCH.start}–${LUNCH.end}</small></div><div class="slot">🍱 ${t('lunch')}</div></li>`;
    });
  }
  const pendingSubs = subs.filter(s => !isAcked(date, s.key, u.id)).length;
  const myOpen = S.requests.filter(r => r.teacherId === u.id && !['delivered', 'rejected'].includes(r.status)).length;
  const myLeave = S.leaves.filter(l => l.teacherId === u.id && l.status === 'pending').length;
  return `
  <div class="page-head"><h2>${L('Namaste', 'नमस्ते')}, ${esc(u.name.split(' ')[0])} 🙏</h2>${dateBar()}</div>
  ${myAbs.length ? `<div class="banner">${t('onLeave')} — ${esc(myAbs.map(absenceLabel).join(', '))}</div>` : ''}
  ${pendingSubs ? `<div class="banner warn">${L(`You have ${pendingSubs} arrangement period(s). Tap "Mark as seen" so the office knows.`, `आपके ${pendingSubs} अरेंजमेंट पीरियड हैं। "देख लिया" दबाएँ ताकि ऑफ़िस को पता चले।`)}</div>` : ''}
  ${nowNextHTML()}
  <div class="grid2">${checkCardHTML() ? `<div>${checkCardHTML()}</div>` : ''}${myDayExtrasHTML(date)}</div>
  <div class="grid2">
    <section class="panel"><div class="panel-head"><h3>${t('myDay')} · ${fmtDate(date)}</h3></div>
      ${d < 0 ? `<p class="muted">${esc(noSchoolMsg(date))}</p>` : `<ul class="day">${rows}</ul>`}
    </section>
    <section class="panel">
      <div class="panel-head"><h3>${L('Quick actions', 'त्वरित कार्य')}</h3></div>
      <div class="quick">
        <button class="qa" data-act="leaveForm">📝<span>${t('applyLeave')}</span></button>
        <button class="qa" data-act="newRequest" data-kind="dpp">🧮<span>${t('raiseDpp')}</span></button>
        <button class="qa" data-act="newRequest" data-kind="worksheet">📄<span>${t('raiseWs')}</span></button>
        <button class="qa" data-act="go" data-view="timetable">📅<span>${L('Class timetables', 'कक्षा समय-सारणी')}</span></button>
      </div>
      <ul class="list compact">
        <li><span>${L('Periods this week', 'इस सप्ताह पीरियड')}</span><b>${weeklyLoad(u.id)}</b></li>
        <li><span>${L('My open requests', 'मेरे खुले अनुरोध')}</span><b>${myOpen}</b></li>
        <li><span>${L('Leave waiting for approval', 'स्वीकृति हेतु छुट्टी')}</span><b>${myLeave}</b></li>
        ${S.classTeachers && Object.entries(S.classTeachers).find(([, v]) => v === u.id) ? `<li><span>${L('Class teacher of', 'कक्षा-शिक्षक')}</span><b>${Object.entries(S.classTeachers).filter(([, v]) => v === u.id).map(([k]) => k).join(', ')}</b></li>` : ''}
      </ul>
    </section>
  </div>`;
}

/* ---------- leave ---------- */
function leaveCard(l, manager) {
  const u = me();
  return `<div class="card">
    <div class="card-top"><div>${avatar(nameOf(l.teacherId))}<div><strong>${esc(nameOf(l.teacherId))}</strong>
      <small>${fmtDate(l.from)}${l.to !== l.from ? ' – ' + fmtDate(l.to) : ''} · ${esc(absenceLabel(l))} · ${esc(l.type)}</small></div></div>${statusChip(l.status)}</div>
    <p class="desc">${esc(l.description)}</p>
    ${l.remark ? `<p class="remark"><b>${t('remark')}:</b> ${esc(l.remark)} <small>— ${esc(nameOf(l.decidedBy))}</small></p>` : ''}
    <div class="row-end">
      ${manager && l.status === 'pending' ? `<button class="btn small danger-ghost" data-act="leaveDecide" data-id="${l.id}" data-ok="0">${t('reject')}</button><button class="btn small ok" data-act="leaveDecide" data-id="${l.id}" data-ok="1">${t('approve')}</button>` : ''}
      ${!manager && l.teacherId === u.id && l.status === 'pending' ? `<button class="btn small ghost" data-act="cancelLeave" data-id="${l.id}">${L('Withdraw', 'वापस लें')}</button>` : ''}
    </div></div>`;
}
function viewLeave() {
  const u = me();
  if (isManager(u)) {
    const tab = UI.leaveTab;
    const list = S.leaves.filter(l => tab === 'all' || l.status === tab).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    const extraTabs = `<button class="tab ${tab === 'calendar' ? 'active' : ''}" data-act="leaveTab" data-tab="calendar">📅 ${L('Calendar', 'कैलेंडर')}</button><button class="tab ${tab === 'balances' ? 'active' : ''}" data-act="leaveTab" data-tab="balances">⚖️ ${L('Leave left', 'शेष छुट्टी')}</button>`;
    const head = `<div class="page-head"><h2>${t('leave')}</h2><button class="btn primary" data-act="markAbsentDialog">+ ${t('markAbsent')}</button></div>
      <div class="tabs">${['pending', 'approved', 'rejected', 'all'].map(x => `<button class="tab ${tab === x ? 'active' : ''}" data-act="leaveTab" data-tab="${x}">${t(x)} (${x === 'all' ? S.leaves.length : S.leaves.filter(l => l.status === x).length})</button>`).join('')}${extraTabs}</div>`;
    if (tab === 'calendar') return head + leaveCalendarHTML();
    if (tab === 'balances') return head + leaveBalancesTableHTML();
    return `${head}
      ${list.length ? `<div class="cards-list">${list.map(l => leaveCard(l, true)).join('')}</div>` : `<div class="empty">${L('No leave requests here.', 'यहाँ कोई आवेदन नहीं।')}</div>`}`;
  }
  const mine = S.leaves.filter(l => l.teacherId === u.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return `<div class="page-head"><h2>${t('leave')}</h2><button class="btn primary" data-act="leaveForm">+ ${t('applyLeave')}</button></div>
    <section class="panel"><div class="panel-head"><h3>${L('Leave left this year', 'इस वर्ष शेष छुट्टी')} (${leaveYear().label})</h3></div>${balanceHTML(u.id) || `<p class="muted">—</p>`}</section>
    ${mine.length ? `<div class="cards-list">${mine.map(l => leaveCard(l, false)).join('')}</div>` : `<div class="empty">${L('You have not applied for leave yet.', 'आपने अभी तक छुट्टी के लिए आवेदन नहीं किया।')}</div>`}`;
}
function leaveFormHTML() {
  const nd = (() => { let d = addDays(todayISO(), 1); while (dayIdx(d) < 0) d = addDays(d, 1); return d; })();
  return `<form data-form="leave" class="stack">
    <div class="two"><label>${t('from')}<input type="date" name="from" value="${nd}" required></label><label>${t('to')}<input type="date" name="to" value="${nd}" required></label></div>
    <label>${t('duration')}<select name="scope" data-change="scopeToggle"><option value="full">${t('fullDay')}</option><option value="first">${t('firstHalf')}</option><option value="second">${t('secondHalf')}</option><option value="periods">${t('specific')}</option></select></label>
    <div class="periods-pick hidden">${PERIODS.map(p => `<label class="pp"><input type="checkbox" name="periods" value="${p.n}">P${p.n}</label>`).join('')}</div>
    <label>${t('type')}<select name="type">${(() => { const b = leaveBalance(me().id); return LEAVE_TYPES.map(tp => { const x = b.find(z => z.type === tp); return `<option value="${tp}">${esc(leaveTypeName(tp))}${x ? ` — ${x.left} ${L('left', 'शेष')}` : ''}</option>`; }).join(''); })()}</select></label>
    <label>${t('description')} *<textarea name="description" rows="4" required placeholder="${esc(L('Reason, and any handover notes for the substitute (e.g. "Chapter 5 test for 9A, papers in staff-room cupboard")', 'कारण, और अरेंजमेंट शिक्षक के लिए नोट (जैसे "9A का अध्याय 5 टेस्ट, पेपर स्टाफ़-रूम अलमारी में")'))}"></textarea></label>
    <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn primary" type="submit">${t('apply')}</button></div></form>`;
}
function markAbsentHTML() {
  return `<form data-form="absent" class="stack">
    <label>${t('teacher')}<select name="tid" required>${teacherOptions('', { includeEmpty: true, emptyLabel: L('Choose teacher', 'शिक्षक चुनें') })}</select></label>
    <label>${t('date')}<input type="date" name="date" value="${UI.date}" required></label>
    <label>${t('duration')}<select name="scope" data-change="scopeToggle"><option value="full">${t('fullDay')}</option><option value="first">${t('firstHalf')}</option><option value="second">${t('secondHalf')}</option><option value="periods">${t('specific')}</option></select></label>
    <div class="periods-pick hidden">${PERIODS.map(p => `<label class="pp"><input type="checkbox" name="periods" value="${p.n}">P${p.n}</label>`).join('')}</div>
    <label>${L('Note', 'नोट')}<input name="note" placeholder="${esc(L('e.g. Called in sick at 7:15', 'जैसे 7:15 बजे बीमार होने की सूचना'))}"></label>
    <p class="hint">${L('The app will immediately draft substitutes for this teacher\'s periods.', 'ऐप तुरंत इस शिक्षक के पीरियड के लिए अरेंजमेंट बनाएगा।')}</p>
    <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn primary" type="submit">${t('markAbsent')}</button></div></form>`;
}

/* ---------- timetable ---------- */
function viewTimetable() {
  const u = me();
  const manager = isManager(u);
  if (!manager && UI.ttMode === 'teacher' && !UI._ttInit) { UI.ttTeacher = u.id; }
  UI._ttInit = true;
  if (!CLASSES.includes(UI.ttClass)) UI.ttClass = CLASSES[0];
  if (!staffById(UI.ttTeacher)) UI.ttTeacher = (teachers()[0] || {}).id;
  const today = dayIdx(todayISO());
  const mode = UI.ttMode;
  let head = `<tr><th>${t('period')}</th>${DAYS.map((d, i) => `<th class="${i === today ? 'today' : ''}">${S.lang === 'hi' ? DAYS_HI[i].slice(0, 3) : d}</th>`).join('')}</tr>`;
  let rows = '';
  PERIODS.forEach(pp => {
    const p = pp.n;
    rows += `<tr><th><b>P${p}</b><small>${periodTime(p)}</small></th>` + DAYS.map((_, d) => {
      if (mode === 'class') {
        const l = lessonAt(UI.ttClass, d, p);
        const swapOn = manager && V2.swapFrom;
        const picked = swapOn && V2.swapFrom !== 'on' && V2.swapFrom.d === d && V2.swapFrom.p === p;
        const edit = manager ? `data-act="${swapOn ? 'swapPick' : 'editCell'}" data-d="${d}" data-p="${p}"${picked ? ' data-picked="1"' : ''}` : '';
        if (!l) return `<td class="${d === today ? 'today' : ''} freecell ${manager ? 'editable' : ''}" ${edit}>—</td>`;
        return `<td class="${d === today ? 'today' : ''} subj-${l.s} ${manager ? 'editable' : ''}" ${edit}><b>${esc(cellSubj(l))}</b><small>${esc(cellTeachers(l))}${l.j ? ' · ' + L('combined', 'संयुक्त') : ''}</small></td>`;
      }
      const l = teacherLessonAt(UI.ttTeacher, d, p);
      return l ? `<td class="${d === today ? 'today' : ''} subj-${l.s}"><b>${esc(l.label)}</b><small>${esc(subjName(l.s))}</small></td>` : `<td class="${d === today ? 'today' : ''} freecell">${t('free')}</td>`;
    }).join('') + '</tr>';
    if (p === LUNCH.after) rows += `<tr class="lunchrow"><th><small>${LUNCH.start}–${LUNCH.end}</small></th><td colspan="${DAYS.length}">🍱 ${t('lunch')}</td></tr>`;
  });
  const ct = mode === 'class' ? S.classTeachers[UI.ttClass] : null;
  return `<div class="page-head"><h2>${t('timetable')}</h2>
    <div class="tt-controls">
      <div class="seg"><button class="${mode === 'class' ? 'active' : ''}" data-act="ttMode" data-mode="class">${t('class')}</button><button class="${mode === 'teacher' ? 'active' : ''}" data-act="ttMode" data-mode="teacher">${t('teacher')}</button></div>
      ${mode === 'class' ? `<select data-change="ttClass" aria-label="Class">${classOptions(UI.ttClass)}</select>` : `<select data-change="ttTeacher" aria-label="Teacher">${teacherOptions(UI.ttTeacher)}</select>`}
      <button class="btn ghost" data-act="pdfTimetable">📄 PDF</button>
      <button class="btn ghost" data-act="pdfTimetableAll">📄 ${mode === 'class' ? L('All classes', 'सभी कक्षाएँ') : L('All teachers', 'सभी शिक्षक')}</button>
      ${manager && mode === 'class' ? `<button class="btn ${V2.swapFrom ? 'primary' : 'ghost'}" data-act="swapMode">⇄ ${V2.swapFrom ? L('Done swapping', 'बदलना पूरा') : L('Swap periods', 'पीरियड बदलें')}</button>` : ''}
    </div></div>
    ${V2.swapFrom ? `<div class="banner">${V2.swapFrom === 'on' ? L('Tap the first period to move.', 'पहला पीरियड चुनें।') : L(`Now tap where ${dayName(V2.swapFrom.d)} P${V2.swapFrom.p} should go. The two periods change places if no teacher clashes.`, `अब वह जगह चुनें जहाँ ${dayName(V2.swapFrom.d)} P${V2.swapFrom.p} जाए। टकराव न हो तो दोनों पीरियड जगह बदल लेंगे।`)}</div>` : ''}
    <p class="muted">${mode === 'class' ? `${L('Class teacher', 'कक्षा-शिक्षक')}: <b>${esc(nameOf(ct))}</b>` : `${L('Periods per week', 'प्रति सप्ताह पीरियड')}: <b>${weeklyLoad(UI.ttTeacher)}</b>`}
    ${manager && mode === 'class' ? ` · ${L('Tap any period to change it. Clashes are blocked.', 'बदलने के लिए किसी पीरियड पर टैप करें। टकराव रोका जाता है।')}` : ''}</p>
    <div class="table-wrap"><table class="tt">${head}${rows}</table></div>`;
}
function editCellHTML(d, p) {
  const l = lessonAt(UI.ttClass, d, p) || { s: '', t: '' };
  const g2 = (l.x && l.x[0]) || { s: '', t: '' };
  return `<form data-form="cell" class="stack" data-d="${d}" data-p="${p}">
    <p><b>${esc(UI.ttClass)}</b> · ${dayName(d)} · P${p} (${periodTime(p)})</p>
    <label>${t('subject')}<select name="s"><option value="">— ${L('No class (free period)', 'कोई कक्षा नहीं (खाली पीरियड)')} —</option>${subjectOptions(l.s)}</select></label>
    <label>${t('teacher')}<select name="t">${teacherOptions(l.t, { includeEmpty: true })}</select></label>
    <details class="howto" ${g2.s || l.j ? 'open' : ''}><summary>${L('Two groups or combined class', 'दो समूह या संयुक्त कक्षा')}</summary>
      <label>${L('Second group: subject', 'दूसरा समूह: विषय')}<select name="s2"><option value="">— ${L('No second group', 'दूसरा समूह नहीं')} —</option>${subjectOptions(g2.s)}</select></label>
      <label>${L('Second group: teacher', 'दूसरा समूह: शिक्षक')}<select name="t2">${teacherOptions(g2.t, { includeEmpty: true })}</select></label>
      <label class="inline"><input type="checkbox" name="j" ${l.j ? 'checked' : ''}> ${L('Combined with another class (the same teacher takes both together)', 'दूसरी कक्षा के साथ संयुक्त (एक ही शिक्षक दोनों को साथ पढ़ाते हैं)')}</label>
    </details>
    <div class="error hidden" id="cellErr"></div>
    <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn primary" type="submit">${t('save')}</button></div></form>`;
}

/* ---------- DPP & worksheet requests ---------- */
function reqCard(r) {
  const u = me();
  const manager = isManager(u);
  const owner = r.teacherId === u.id;
  const title = r.kind === 'dpp' ? `${esc(r.chapter)}${r.topic ? ' — ' + esc(r.topic) : ''}` : `${esc(r.wsType)} ${L('worksheet', 'वर्कशीट')}`;
  const facts = r.kind === 'dpp'
    ? [`${r.numQ} ${L('questions', 'प्रश्न')}`, r.difficulty, r.qtypes, `${r.copies} ${L('copies', 'प्रतियाँ')}`]
    : [r.pageSize, r.color, `${r.copies} ${L('copies', 'प्रतियाँ')}`];
  let actions = '';
  if (manager) {
    if (r.status === 'requested') actions += `<button class="btn small danger-ghost" data-act="reqReject" data-id="${r.id}">${t('reject')}</button><button class="btn small ok" data-act="reqApprove" data-id="${r.id}">${t('approve')}</button>`;
    if (r.status === 'approved') actions += `<button class="btn small" data-act="reqStatus" data-id="${r.id}" data-st="in_progress">${L('Start work', 'काम शुरू')}</button>`;
    if (r.status === 'in_progress') actions += `<button class="btn small" data-act="reqStatus" data-id="${r.id}" data-st="ready">${L('Mark ready', 'तैयार')}</button>`;
    if (r.status === 'ready') actions += `<button class="btn small ok" data-act="reqStatus" data-id="${r.id}" data-st="delivered">${L('Mark delivered', 'पहुँचा दिया')}</button>`;
  }
  if (owner && r.status === 'requested') actions += `<button class="btn small ghost" data-act="reqCancel" data-id="${r.id}">${L('Withdraw', 'वापस लें')}</button>`;
  if ((manager || owner) && r.status !== 'rejected') actions += `<button class="btn small ai" data-act="aiDraft" data-id="${r.id}">📄 ${r.draft ? L('View draft', 'ड्राफ़्ट देखें') : t('aiDraft')}</button>`;
  const late = r.neededBy < todayISO() && !['delivered', 'rejected'].includes(r.status);
  return `<div class="card">
    <div class="card-top"><div><span class="kind ${r.kind}">${r.kind === 'dpp' ? 'DPP' : t('worksheet')}</span><div><strong>${esc(r.classId)} · ${esc(subjName(r.subject))}</strong><small>${title}</small></div></div>${statusChip(r.status)}</div>
    <p class="desc">${esc(r.description || '')}</p>
    <div class="facts">${facts.filter(Boolean).map(f => `<span>${esc(f)}</span>`).join('')}<span class="${late ? 'bad' : ''}">${L('Needed by', 'चाहिए')} ${fmtDate(r.neededBy)}${late ? ' · ' + L('overdue', 'देर') : ''}</span></div>
    <div class="meta">${L('By', 'द्वारा')} ${esc(nameOf(r.teacherId))}${r.assignee ? ` · ${L('Assigned to', 'ज़िम्मेदार')} ${esc(nameOf(r.assignee))}` : ''}</div>
    ${r.remark ? `<p class="remark"><b>${t('remark')}:</b> ${esc(r.remark)}</p>` : ''}
    <details class="hist"><summary>${L('History', 'इतिहास')} (${r.history.length})</summary><ul>${r.history.map(h => `<li>${fmtTime(h.at)} — ${esc(nameOf(h.by))}: ${esc(h.text)}</li>`).join('')}</ul></details>
    ${actions ? `<div class="row-end">${actions}</div>` : ''}</div>`;
}
function viewRequests() {
  const u = me();
  const manager = isManager(u);
  const tab = UI.reqTab;
  let list = S.requests.filter(r => manager || r.teacherId === u.id);
  if (tab === 'dpp' || tab === 'worksheet') list = list.filter(r => r.kind === tab);
  list = list.slice().sort((a, b) => (a.status === 'delivered') - (b.status === 'delivered') || a.neededBy.localeCompare(b.neededBy));
  return `<div class="page-head"><h2>${t('requests')}</h2>
    <div class="btns"><button class="btn primary" data-act="newRequest" data-kind="dpp">+ DPP</button><button class="btn primary" data-act="newRequest" data-kind="worksheet">+ ${t('worksheet')}</button></div></div>
    <div class="tabs">${[['all', t('all')], ['dpp', 'DPP'], ['worksheet', t('worksheet')]].map(([k, lb]) => `<button class="tab ${tab === k ? 'active' : ''}" data-act="reqTab" data-tab="${k}">${esc(lb)}</button>`).join('')}</div>
    ${list.length ? `<div class="cards-list">${list.map(reqCard).join('')}</div>` : `<div class="empty">${L('No requests yet.', 'अभी कोई अनुरोध नहीं।')}</div>`}`;
}
function requestFormHTML(kind) {
  const u = me();
  const nd = addDays(todayISO(), 2);
  const myClasses = [...new Set(CLASSES.filter(c => teachesClass(u.id, c)))];
  const defClass = myClasses[0] || '6A';
  const defSubj = u.subjects[0] || 'ENG';
  const common = `<div class="two"><label>${t('class')}<select name="classId">${classOptions(defClass)}</select></label><label>${t('subject')}<select name="subject">${subjectOptions(defSubj)}</select></label></div>`;
  if (kind === 'dpp') return `<form data-form="request" data-kind="dpp" class="stack">${common}
    <label>${L('Chapter', 'अध्याय')} *<input name="chapter" required placeholder="${esc(L('e.g. Chapter 3 — Pair of Linear Equations', 'जैसे अध्याय 3 — रैखिक समीकरण युग्म'))}"></label>
    <label>${L('Topic', 'टॉपिक')}<input name="topic" placeholder="${esc(L('e.g. Elimination method', 'जैसे विलोपन विधि'))}"></label>
    <div class="three"><label>${L('Questions', 'प्रश्न')}<input type="number" name="numQ" min="1" max="100" value="15"></label>
      <label>${L('Difficulty', 'कठिनाई')}<select name="difficulty"><option>Easy</option><option selected>Mixed</option><option>Medium</option><option>Hard</option></select></label>
      <label>${L('Copies', 'प्रतियाँ')}<input type="number" name="copies" min="1" value="40"></label></div>
    <label>${L('Question types', 'प्रश्न प्रकार')}<input name="qtypes" value="MCQ, Short answer"></label>
    <label>${L('Needed by', 'कब तक चाहिए')}<input type="date" name="neededBy" value="${nd}" required></label>
    <label>${L('Notes', 'नोट')}<textarea name="description" rows="3" placeholder="${esc(L('e.g. focus on last test\'s weak areas', 'जैसे पिछले टेस्ट की कमज़ोरियों पर ध्यान'))}"></textarea></label>
    <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn primary" type="submit">${L('Raise request', 'अनुरोध भेजें')}</button></div></form>`;
  return `<form data-form="request" data-kind="worksheet" class="stack">${common}
    <label>${L('Worksheet type', 'वर्कशीट प्रकार')}<select name="wsType"><option>Classwork</option><option>Homework</option><option>Revision</option><option>Activity</option><option>Holiday homework</option><option>Remedial</option></select></label>
    <label>${t('description')} *<textarea name="description" rows="5" required placeholder="${esc(L('What should the worksheet contain and why? e.g. "Class 4 EVS, 10 picture-based questions on water sources, for slow learners, single A4 page"', 'वर्कशीट में क्या होना चाहिए और क्यों? जैसे "कक्षा 4 EVS, जल स्रोतों पर 10 चित्र-आधारित प्रश्न, धीमे सीखने वालों के लिए, एक A4 पेज"'))}"></textarea></label>
    <div class="three"><label>${L('Copies', 'प्रतियाँ')}<input type="number" name="copies" min="1" value="40"></label>
      <label>${L('Page size', 'पेज साइज़')}<select name="pageSize"><option>A4</option><option>A5</option><option>Legal</option></select></label>
      <label>${L('Print', 'प्रिंट')}<select name="color"><option>Black & white</option><option>Colour</option></select></label></div>
    <label>${L('Needed by', 'कब तक चाहिए')}<input type="date" name="neededBy" value="${nd}" required></label>
    <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn primary" type="submit">${L('Raise request', 'अनुरोध भेजें')}</button></div></form>`;
}

/* ---------- staff ---------- */
function viewStaff() {
  const rows = S.staff.map(s => {
    const ctOf = Object.entries(S.classTeachers).filter(([, v]) => v === s.id).map(([k]) => k).join(', ');
    return `<tr class="${s.active ? '' : 'inactive'}"><td>${avatar(s.name)} <b>${esc(s.name)}</b></td><td>${esc(roleLabel(s.role))}</td>
      <td>${esc(s.subjects.map(subjName).join(', ') || '—')}</td><td>${s.phone ? '+91 ' + esc(s.phone) : `<span class="muted">${L('Not added', 'दर्ज नहीं')}</span>`}</td><td>${esc(ctOf || '—')}</td>
      <td>${s.role === 'teacher' ? weeklyLoad(s.id) : '—'}</td><td>${loginCell(s)}</td><td>${s.active ? `<span class="chip st-approved">${L('Active', 'सक्रिय')}</span>` : `<span class="chip st-rejected">${L('Inactive', 'निष्क्रिय')}</span>`}</td>
      <td><button class="btn tiny ghost" data-act="editStaff" data-id="${s.id}">${L('Edit', 'बदलें')}</button></td></tr>`;
  }).join('');
  return `<div class="page-head"><h2>${t('staff')}</h2><button class="btn primary" data-act="editStaff" data-id="">+ ${L('Add staff', 'स्टाफ़ जोड़ें')}</button></div>
    <p class="muted">${L('Only numbers listed here can log in. Give each person their activation code once; they then set their own PIN. Deactivate someone to remove access immediately.', 'केवल यहाँ दर्ज नंबर ही लॉगिन कर सकते हैं। हर व्यक्ति को एक बार एक्टिवेशन कोड दें; फिर वे अपना PIN बनाएँगे। निष्क्रिय करते ही पहुँच बंद हो जाती है।')}</p>
    <div class="table-wrap"><table class="data"><thead><tr><th>${L('Name', 'नाम')}</th><th>${L('Role', 'भूमिका')}</th><th>${L('Subjects', 'विषय')}</th><th>${t('mobile')}</th><th>${L('Class teacher', 'कक्षा-शिक्षक')}</th><th>${L('Periods/week', 'पीरियड/सप्ताह')}</th><th>${L('App login', 'ऐप लॉगिन')}</th><th>${t('status')}</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function loginCell(s) {
  if (!s.phone) return `<span class="muted">${L('Add mobile number', 'मोबाइल नंबर जोड़ें')}</span>`;
  if (UI.codes === null) return `<span class="muted">…</span>`;
  const c = UI.codes[s.id];
  if (!c) return '—';
  const reset = `<button class="btn tiny ghost" data-act="resetPin" data-id="${s.id}">${L('New code', 'नया कोड')}</button>`;
  if (c.activated) return `<span class="ok-text">✓ ${L('Activated', 'सक्रिय')}</span> ${s.id === me().id ? '' : reset}`;
  return `<span class="code">${esc(c.code || '—')}</span> <button class="btn tiny ghost" data-act="shareCode" data-id="${s.id}">${L('Share', 'भेजें')}</button>`;
}
async function refreshCodes() {
  UI.codesLoading = true;
  const { data, error } = await SB.rpc('staff_codes');
  UI.codesLoading = false;
  if (error) { UI.codes = {}; return; }
  UI.codes = {};
  (data || []).forEach(r => (UI.codes[r.staff_id] = { code: r.code, activated: r.activated }));
  if (UI.view === 'staff' && !document.getElementById('modal-root').innerHTML) render();
}
function staffFormHTML(id) {
  const s = id ? staffById(id) : { name: '', phone: '', role: 'teacher', subjects: [], active: true };
  return `<form data-form="staff" data-id="${esc(id || '')}" class="stack">
    <label>${L('Full name', 'पूरा नाम')} *<input name="name" required value="${esc(s.name)}"></label>
    <label>${t('mobile')} <small class="muted">(${L('needed for app login', 'ऐप लॉगिन के लिए ज़रूरी')})</small><div class="phone-in"><span>+91</span><input name="phone" inputmode="numeric" maxlength="10" pattern="[6-9][0-9]{9}" value="${esc(s.phone || '')}"></div></label>
    <label>${L('Role', 'भूमिका')}<select name="role">${['teacher', 'coordinator', 'admin'].map(r => `<option value="${r}" ${s.role === r ? 'selected' : ''}>${esc(roleLabel(r))}</option>`).join('')}</select></label>
    <fieldset><legend>${L('Subjects', 'विषय')}</legend><div class="checks">${Object.keys(SUBJECTS).map(k => `<label class="pp"><input type="checkbox" name="subjects" value="${k}" ${s.subjects.includes(k) ? 'checked' : ''}>${esc(subjName(k))}</label>`).join('')}</div></fieldset>
    <label class="inline"><input type="checkbox" name="active" ${s.active ? 'checked' : ''}> ${L('Active (can log in)', 'सक्रिय (लॉगिन कर सकते हैं)')}</label>
    <div class="error hidden" id="staffErr"></div>
    <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn primary" type="submit">${t('save')}</button></div></form>`;
}

/* ---------- reports ---------- */
function viewReports() {
  const ym = UI.reportMonth || todayISO().slice(0, 7);
  const data = teachers().map(tc => ({ id: tc.id, name: tc.name, load: weeklyLoad(tc.id), subs: monthSubs(tc.id, ym), leave: monthLeaveDays(tc.id, ym) }));
  const maxSubs = Math.max(1, ...data.map(d => d.subs));
  const maxLoad = Math.max(1, ...data.map(d => d.load));
  const subsVals = data.map(d => d.subs);
  const spread = Math.max(...subsVals) - Math.min(...subsVals);
  const req = { dpp: S.requests.filter(r => r.kind === 'dpp'), worksheet: S.requests.filter(r => r.kind === 'worksheet') };
  const sts = ['requested', 'approved', 'in_progress', 'ready', 'delivered', 'rejected'];
  return `<div class="page-head"><h2>${t('reports')}</h2><div class="btns"><input type="month" value="${ym}" data-change="reportMonth" aria-label="Month"><button class="btn primary" data-act="exportAll">⬇️ ${L('Download Excel', 'Excel डाउनलोड')}</button><button class="btn ghost" data-act="printReport">📄 PDF</button><button class="btn ghost" data-act="copyReport">📋 CSV</button></div></div>
    ${reportAttendanceHTML(ym)}
    ${salaryPanelHTML(ym)}
    <div class="cards">
      <div class="stat"><span>${L('Substitutions published', 'प्रकाशित अरेंजमेंट')}</span><b>${subsVals.reduce((a, b) => a + b, 0)}</b></div>
      <div class="stat ${spread > 3 ? 'warn' : ''}"><span>${L('Fairness gap (most − least)', 'असमानता (अधिकतम − न्यूनतम)')}</span><b>${spread}</b></div>
      <div class="stat"><span>${L('Leave days taken', 'छुट्टी के दिन')}</span><b>${data.reduce((a, b) => a + b.leave, 0)}</b></div>
    </div>
    <section class="panel"><h3>${L('Teacher workload and substitutions', 'शिक्षक कार्यभार और अरेंजमेंट')}</h3>
      <div class="table-wrap"><table class="data bars"><thead><tr><th>${t('teacher')}</th><th>${L('Periods / week', 'पीरियड / सप्ताह')}</th><th>${L('Substitutions this month', 'इस माह अरेंजमेंट')}</th><th>${L('Leave days', 'छुट्टी दिन')}</th></tr></thead>
      <tbody>${data.sort((a, b) => b.subs - a.subs || b.load - a.load).map(d => `<tr><td>${esc(d.name)}</td>
        <td><div class="bar"><i style="width:${(d.load / maxLoad) * 100}%"></i><span>${d.load}</span></div></td>
        <td><div class="bar sub"><i style="width:${(d.subs / maxSubs) * 100}%"></i><span>${d.subs}</span></div></td>
        <td>${d.leave}</td></tr>`).join('')}</tbody></table></div>
      <p class="muted">${L('Fairness target: keep the gap between the most- and least-loaded teacher within 3 substitutions a month.', 'लक्ष्य: सबसे ज़्यादा और सबसे कम अरेंजमेंट वाले शिक्षक का अंतर महीने में 3 से कम रहे।')}</p>
    </section>
    <section class="panel"><h3>${L('DPP and worksheet requests', 'DPP और वर्कशीट अनुरोध')}</h3>
      <div class="table-wrap"><table class="data"><thead><tr><th></th>${sts.map(s => `<th>${t(s)}</th>`).join('')}<th>${L('Total', 'कुल')}</th></tr></thead>
      <tbody>${['dpp', 'worksheet'].map(k => `<tr><td><b>${k === 'dpp' ? 'DPP' : t('worksheet')}</b></td>${sts.map(s => `<td>${req[k].filter(r => r.status === s).length}</td>`).join('')}<td><b>${req[k].length}</b></td></tr>`).join('')}</tbody></table></div>
    </section>`;
}

/* ---------- AI assistant ---------- */
/* ---------- notices, audit, settings ---------- */
function viewNotices() {
  const u = me();
  return `<div class="page-head"><h2>${t('notices')}</h2>${isManager(u) ? `<button class="btn primary" data-act="newNotice">+ ${L('Post notice', 'सूचना जारी करें')}</button>` : ''}</div>
    ${S.notices.length ? `<div class="cards-list">${S.notices.map(n => `<div class="card"><div class="card-top"><div><strong>${esc(n.title)}</strong></div><small class="muted">${fmtTime(n.at)} · ${esc(nameOf(n.by))}</small></div><p class="desc">${esc(n.body)}</p>
      ${isManager(u) ? `<div class="row-end"><button class="btn tiny ghost" data-act="noticeReaders" data-id="${n.id}">👁 ${L('Read by', 'पढ़ा')} ${readersOf(n.id).filter(x => x.read).length}/${readersOf(n.id).length}</button><button class="btn tiny ghost" data-act="delNotice" data-id="${n.id}">${L('Remove', 'हटाएँ')}</button></div>` : `<div class="row-end"><small class="muted">${noticeRead(n.id, u.id) ? '✓ ' + L('Read', 'पढ़ा') : ''}</small></div>`}</div>`).join('')}</div>` : `<div class="empty">${L('No notices.', 'कोई सूचना नहीं।')}</div>`}`;
}
function viewAudit() {
  return `<div class="page-head"><h2>${t('audit')}</h2></div>
    <p class="muted">${L('Every change: who did what, and when.', 'हर बदलाव: किसने क्या किया, और कब।')}</p>
    <section class="panel"><ul class="audit">${S.audit.slice(0, 200).map(a => `<li><small>${fmtTime(a.at)}</small><b>${esc(nameOf(a.by))}</b><span>${esc(a.text)}</span></li>`).join('')}</ul></section>`;
}
function viewSettings() {
  const w = S.settings;
  const f = (k, label) => `<label>${esc(label)}<input type="number" name="${k}" value="${w[k]}" min="0" max="100"></label>`;
  return `<div class="page-head"><h2>${t('settings')}</h2></div>
    <section class="panel"><h3>${L('Substitution rules', 'अरेंजमेंट नियम')}</h3>
      <form data-form="settings" class="stack">
        <div class="three">${f('subject', L('Same subject (+)', 'वही विषय (+)'))}${f('classKnown', L('Already teaches class (+)', 'कक्षा को पढ़ाते हैं (+)'))}${f('classTeacher', L('Class teacher (+)', 'कक्षा-शिक्षक (+)'))}</div>
        <div class="three">${f('periodLoad', L('Per period today (−)', 'आज प्रति पीरियड (−)'))}${f('weekSubs', L('Per substitution this week (−)', 'इस सप्ताह प्रति अरेंजमेंट (−)'))}${f('consecutive', L('3 in a row (−)', 'लगातार 3 (−)'))}</div>
        <div class="three">${f('dailyCap', L('Max substitutions per teacher per day', 'प्रति शिक्षक प्रति दिन अधिकतम अरेंजमेंट'))}</div>
        <div class="row-end"><button class="btn primary">${t('save')}</button></div>
      </form></section>
    ${settingsV2HTML()}
    <section class="panel"><h3>🎨 ${L('This phone', 'यह फ़ोन')}</h3>
      <div class="row-end left"><button class="btn" data-act="cycleTheme">${themeIcon()} ${L('Light / dark theme', 'लाइट / डार्क थीम')}</button>${notifSupported() ? `<button class="btn" data-act="enableNotif">🔔 ${Notification.permission === 'granted' ? L('Notifications on', 'सूचनाएँ चालू') : L('Turn on notifications', 'सूचनाएँ चालू करें')}</button>` : ''}</div></section>
    <section class="panel"><h3>${L('About', 'जानकारी')}</h3>
      <p>${SCHOOL.name}, ${SCHOOL.place} — ${L('Staff App, version 2 (test copy).', 'स्टाफ़ ऐप, संस्करण 2 (परीक्षण प्रति)।')}</p>
      <p class="muted">${L('Data is stored securely online and shared live between all staff phones.', 'डेटा सुरक्षित रूप से ऑनलाइन रखा जाता है और सभी स्टाफ़ फ़ोन पर लाइव दिखता है।')}</p></section>`;
}

/* ===== Buttons, forms, AI and start-up ===== */
function commit() { render(); queueFlush(); }

const ACTIONS = {
  go: el => go(el.dataset.view),
  toggleMenu: () => { UI.menuOpen = !UI.menuOpen; render(); },
  toggleLang: () => { S.lang = S.lang === 'en' ? 'hi' : 'en'; saveLang(); render(); },
  logout: () => confirmBox(L('Log out of the app on this phone?', 'इस फ़ोन पर ऐप से लॉग आउट करें?'), () => doLogout(), t('logout')),
  closeModal: () => closeModal(),
  closeModalBack: (el, ev) => { if (ev.target === el) closeModal(); },
  confirmYes: () => { const fn = confirmBox._fn; closeModal(); if (fn) fn(); },

  loginBack: () => { UI.loginStep = 'phone'; UI.loginError = ''; render(); },

  shiftDate: el => { UI.date = addDays(UI.date, Number(el.dataset.n)); render(); },
  dateToday: () => { UI.date = todayISO(); render(); },

  markAbsentDialog: () => openModal(t('markAbsent'), markAbsentHTML()),
  removeAbsence: el => {
    const a = S.absences.find(x => x.id === el.dataset.id);
    if (!a) return;
    confirmBox(L(`Remove absence of ${nameOf(a.teacherId)} on ${fmtDate(a.date)}? Their periods will go back to them.`, `${fmtDate(a.date)} को ${nameOf(a.teacherId)} की अनुपस्थिति हटाएँ?`),
      () => { removeAbsence(a.id, me().id); commit(); toast(L('Absence removed, plan updated', 'अनुपस्थिति हटाई, योजना अपडेट')); }, L('Remove', 'हटाएँ'));
  },
  replan: () => { generatePlan(UI.date, me().id); logAudit(me().id, `Re-planned substitutions for ${UI.date}`); commit(); toast(L('Plan refreshed', 'योजना फिर से बनी')); },
  publishPlan: () => {
    const plan = S.plans[UI.date];
    if (!plan) return;
    const unfilled = Object.values(plan.items).filter(i => !i.teacherId).length;
    const doIt = () => { publishPlan(UI.date, me().id); commit(); toast(L('Published — substitutes notified', 'प्रकाशित — शिक्षकों को सूचना भेजी गई')); };
    if (unfilled) confirmBox(L(`${unfilled} period(s) are still not covered. Publish anyway?`, `${unfilled} पीरियड अभी खाली हैं। फिर भी प्रकाशित करें?`), doIt, t('publish'));
    else doIt();
  },
  copySheet: () => copyText(sheetText(UI.date)),
  printSheet: () => {
    const w = document.getElementById('print-root');
    w.innerHTML = `<pre>${esc(sheetText(UI.date))}</pre>`;
    try { window.print(); } catch (e) { toast(L('Printing is not available here — use Copy sheet', 'यहाँ प्रिंट उपलब्ध नहीं — शीट कॉपी करें')); }
  },

  leaveForm: () => openModal(t('applyLeave'), leaveFormHTML()),
  leaveTab: el => { UI.leaveTab = el.dataset.tab; render(); },
  cancelLeave: el => {
    confirmBox(L('Withdraw this leave request?', 'यह आवेदन वापस लें?'), () => {
      S.leaves = S.leaves.filter(l => l.id !== el.dataset.id); logAudit(me().id, 'Withdrew a leave request'); commit();
    }, L('Withdraw', 'वापस लें'));
  },
  leaveDecide: el => {
    const id = el.dataset.id, ok = el.dataset.ok === '1';
    const lv = S.leaves.find(l => l.id === id);
    openModal(ok ? t('approve') : t('reject'), `<form data-form="leaveDecision" data-id="${id}" data-ok="${ok ? 1 : 0}" class="stack">
      <p><b>${esc(nameOf(lv.teacherId))}</b> · ${fmtDate(lv.from)}${lv.to !== lv.from ? ' – ' + fmtDate(lv.to) : ''} · ${esc(absenceLabel(lv))}</p>
      <p class="desc">${esc(lv.description)}</p>
      <label>${t('remark')} ${ok ? `(${L('optional', 'वैकल्पिक')})` : '*'}<textarea name="remark" rows="2" ${ok ? '' : 'required'}></textarea></label>
      ${ok ? `<p class="hint">${L('On approval the app drafts substitutes for every affected period.', 'स्वीकृति पर ऐप हर प्रभावित पीरियड के लिए अरेंजमेंट बनाएगा।')}</p>` : ''}
      <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn ${ok ? 'ok' : 'danger'}" type="submit">${ok ? t('approve') : t('reject')}</button></div></form>`);
  },

  ackSub: el => {
    const plan = S.plans[UI.date];
    if (!plan || !plan.items[el.dataset.key]) return;
    S.acks[ackId(UI.date, el.dataset.key, me().id)] = { teacherId: me().id, date: UI.date, key: el.dataset.key, at: nowStamp() };
    logAudit(me().id, `Saw arrangement ${el.dataset.key.replace('|', ' P')} on ${UI.date}`);
    commit(); toast(L('Thank you — office informed', 'धन्यवाद — ऑफ़िस को सूचना मिल गई'));
  },

  ttMode: el => { UI.ttMode = el.dataset.mode; if (UI.ttMode === 'teacher' && !isManager(me())) UI.ttTeacher = me().id; render(); },
  editCell: el => openModal(L('Change period', 'पीरियड बदलें'), editCellHTML(Number(el.dataset.d), Number(el.dataset.p))),

  reqTab: el => { UI.reqTab = el.dataset.tab; render(); },
  newRequest: el => openModal(el.dataset.kind === 'dpp' ? t('raiseDpp') : t('raiseWs'), requestFormHTML(el.dataset.kind), { wide: true }),
  reqApprove: el => {
    const r = S.requests.find(x => x.id === el.dataset.id);
    openModal(t('approve'), `<form data-form="reqApprove" data-id="${r.id}" class="stack">
      <p><b>${r.kind === 'dpp' ? 'DPP' : t('worksheet')}</b> · ${esc(r.classId)} · ${esc(subjName(r.subject))} · ${esc(nameOf(r.teacherId))}</p>
      <label>${L('Assign to (who prepares it)', 'किसे सौंपें (कौन तैयार करेगा)')}<select name="assignee">${teacherOptions(r.teacherId)}${S.staff.filter(s => isManager(s)).map(s => `<option value="${s.id}">${esc(s.name)} (${esc(roleLabel(s.role))})</option>`).join('')}</select></label>
      <label>${t('remark')}<input name="remark" placeholder="${esc(L('e.g. Print from office by Thursday', 'जैसे गुरुवार तक ऑफ़िस से प्रिंट'))}"></label>
      <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn ok" type="submit">${t('approve')}</button></div></form>`);
  },
  reqReject: el => {
    openModal(t('reject'), `<form data-form="reqReject" data-id="${el.dataset.id}" class="stack">
      <label>${L('Reason', 'कारण')} *<textarea name="remark" rows="2" required></textarea></label>
      <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn danger" type="submit">${t('reject')}</button></div></form>`);
  },
  reqStatus: el => {
    const r = S.requests.find(x => x.id === el.dataset.id);
    r.status = el.dataset.st;
    r.history.push({ at: nowStamp(), by: me().id, text: `Status → ${I18N.en[r.status]}` });
    notify(r.teacherId, '', { en: `Your ${r.kind === 'dpp' ? 'DPP' : 'worksheet'} request (${r.classId} ${SUBJECTS[r.subject].en}) is now: ${I18N.en[r.status]}`, hi: `आपका ${r.kind === 'dpp' ? 'DPP' : 'वर्कशीट'} अनुरोध (${r.classId}) अब: ${I18N.hi[r.status]}` });
    logAudit(me().id, `${r.kind.toUpperCase()} request ${r.classId} ${r.subject} → ${r.status}`);
    commit();
  },
  reqCancel: el => {
    confirmBox(L('Withdraw this request?', 'यह अनुरोध वापस लें?'), () => { S.requests = S.requests.filter(r => r.id !== el.dataset.id); logAudit(me().id, 'Withdrew a request'); commit(); }, L('Withdraw', 'वापस लें'));
  },
  aiDraft: el => openDraft(el.dataset.id),
  aiGenerate: el => generateDraft(el.dataset.id),
  copyDraft: el => { const ta = document.getElementById('draftText'); copyText(ta ? ta.value : ''); },
  saveDraft: el => {
    const r = S.requests.find(x => x.id === el.dataset.id); const ta = document.getElementById('draftText');
    if (r && ta) { r.draft = ta.value; r.history.push({ at: nowStamp(), by: me().id, text: 'Draft saved' }); toast(L('Draft saved', 'ड्राफ़्ट सहेजा')); closeModal(); commit(); }
  },

  editStaff: el => openModal(el.dataset.id ? L('Edit staff', 'स्टाफ़ बदलें') : L('Add staff', 'स्टाफ़ जोड़ें'), staffFormHTML(el.dataset.id)),
  copyReport: () => {
    const ym = UI.reportMonth || todayISO().slice(0, 7);
    const lines = ['Teacher,Periods per week,Substitutions this month,Leave days'];
    teachers().forEach(tc => lines.push(`"${tc.name}",${weeklyLoad(tc.id)},${monthSubs(tc.id, ym)},${monthLeaveDays(tc.id, ym)}`));
    copyText(lines.join('\n'));
  },

  askSuggest: el => askAssistant(el.dataset.q),
  newChat: () => newChat(),
  hideStart: () => { try { localStorage.setItem('mts-start-hidden', '1'); } catch (e) { } render(); },
  newNotice: () => openModal(L('Post notice', 'सूचना जारी करें'), `<form data-form="notice" class="stack"><label>${L('Title', 'शीर्षक')} *<input name="title" required></label><label>${L('Message', 'संदेश')} *<textarea name="body" rows="4" required></textarea></label>
    <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn primary">${L('Post', 'जारी करें')}</button></div></form>`),
  delNotice: el => { S.notices = S.notices.filter(n => n.id !== el.dataset.id); commit(); },
  resetPin: el => {
    const s = staffById(el.dataset.id);
    confirmBox(L(`Give ${s.name} a new activation code? Their current PIN stops working and they are logged out.`, `${s.name} को नया एक्टिवेशन कोड दें? उनका मौजूदा PIN बंद हो जाएगा।`), async () => {
      const { data, error } = await SB.rpc('reset_pin', { p_staff_id: s.id });
      if (error) { toast(L('Could not reset — check internet', 'रीसेट नहीं हुआ — इंटरनेट जाँचें')); return; }
      logAudit(me().id, `Issued new activation code for ${s.name}`); queueFlush();
      await refreshCodes();
      showCode(s, data);
    }, L('New code', 'नया कोड'));
  },
  shareCode: el => { const s = staffById(el.dataset.id); const c = UI.codes && UI.codes[s.id]; if (c && c.code) showCode(s, c.code); },
  copyCodeMsg: el => copyText(el.dataset.msg),

  openNotifications: () => {
    const u = me();
    const mine = S.notifications.filter(n => n.userId === u.id).slice(0, 40);
    openModal(t('notifications'), mine.length ? `<ul class="notif">${mine.map(n => `<li class="${n.read ? '' : 'unread'}"><span>${esc(S.lang === 'hi' ? n.hi : n.en)}</span><small>${fmtTime(n.at)}</small></li>`).join('')}</ul>
      <p class="hint">${L('In the live app these also arrive as WhatsApp messages.', 'असली ऐप में ये WhatsApp पर भी आएँगी।')}</p>` : `<p class="muted">${L('No notifications.', 'कोई सूचना नहीं।')}</p>`);
    mine.forEach(n => (n.read = true));
    queueFlush();
    const b = document.querySelector('.bell b'); if (b) b.remove();
  },
};

const CHANGES = {
  setDate: el => { if (el.value) { UI.date = el.value; render(); } },
  setSub: el => { setSubstitute(UI.date, el.dataset.key, el.value || null, me().id); commit(); },
  scopeToggle: el => { const pick = el.closest('form').querySelector('.periods-pick'); if (pick) pick.classList.toggle('hidden', el.value !== 'periods'); },
  ttClass: el => { UI.ttClass = el.value; if (V2.swapFrom && V2.swapFrom !== 'on') V2.swapFrom = 'on'; render(); },
  ttTeacher: el => { UI.ttTeacher = el.value; render(); },
  reportMonth: el => { UI.reportMonth = el.value; render(); },
};

const FORMS = {
  loginPhone: async (fd) => {
    const phone = String(fd.get('phone') || '').replace(/\D/g, '').slice(-10);
    UI.loginPhone = phone; UI.loginError = '';
    if (!/^[6-9]\d{9}$/.test(phone)) { UI.loginError = L('Enter a valid 10-digit mobile number.', '10 अंकों का सही मोबाइल नंबर डालें।'); render(); return; }
    UI.loginBusy = true; render();
    try {
      await ensureBrowserSession();
      const { data, error } = await SB.rpc('staff_status', { p_phone: phone });
      if (error) throw error;
      if (data === 'ready') UI.loginStep = 'pin';
      else if (data === 'needs_activation') UI.loginStep = 'activate';
      else UI.loginError = loginErr(data);
    } catch (e) { UI.loginError = loginErr('network'); }
    UI.loginBusy = false; render();
  },
  loginPin: async (fd) => {
    UI.loginBusy = true; UI.loginError = ''; render();
    try {
      await ensureBrowserSession();
      const { data, error } = await SB.rpc('login', { p_phone: UI.loginPhone, p_pin: String(fd.get('pin')) });
      if (error) throw error;
      if (String(data).startsWith('ERR:')) { UI.loginError = loginErr(String(data).slice(4)); UI.loginBusy = false; render(); return; }
      UI.loginBusy = false;
      await enterApp(data);
      logAudit(data, 'Logged in'); queueFlush();
    } catch (e) { UI.loginBusy = false; UI.loginError = loginErr('network'); render(); }
  },
  loginActivate: async (fd) => {
    const pin = String(fd.get('pin')), pin2 = String(fd.get('pin2'));
    if (pin !== pin2) { UI.loginError = L('The two PINs do not match.', 'दोनों PIN मेल नहीं खाते।'); render(); return; }
    if (/^(\d)\1{5}$/.test(pin) || pin === '123456' || pin === '654321') { UI.loginError = L('Choose a PIN that is harder to guess.', 'ऐसा PIN चुनें जिसे अंदाज़ा लगाना मुश्किल हो।'); render(); return; }
    UI.loginBusy = true; UI.loginError = ''; render();
    try {
      await ensureBrowserSession();
      const { data, error } = await SB.rpc('activate', { p_phone: UI.loginPhone, p_code: String(fd.get('code')).trim(), p_pin: pin });
      if (error) throw error;
      if (String(data).startsWith('ERR:')) { UI.loginError = loginErr(String(data).slice(4)); UI.loginBusy = false; render(); return; }
      UI.loginBusy = false;
      await enterApp(data);
      logAudit(data, 'Activated app login'); queueFlush();
      toast(L('Welcome! Remember your PIN.', 'स्वागत है! अपना PIN याद रखें।'));
    } catch (e) { UI.loginBusy = false; UI.loginError = loginErr('network'); render(); }
  },
  leave: (fd) => {
    const u = me();
    const from = fd.get('from'), to = fd.get('to');
    if (to < from) { toast(L('"To" date is before "From" date', '"तक" तारीख़ "से" से पहले है')); return; }
    const scope = fd.get('scope');
    const periods = fd.getAll('periods').map(Number);
    if (scope === 'periods' && !periods.length) { toast(L('Choose at least one period', 'कम से कम एक पीरियड चुनें')); return; }
    const lv = { id: uid('lv'), teacherId: u.id, from, to, scope, periods, type: fd.get('type'), description: String(fd.get('description')).trim(), status: 'pending', remark: '', createdAt: nowStamp() };
    S.leaves.push(lv);
    notifyManagers({ en: `${u.name} applied for ${lv.type.toLowerCase()} leave (${fmtDate(from)}${to !== from ? ' – ' + fmtDate(to) : ''})`, hi: `${u.name} ने छुट्टी के लिए आवेदन किया (${fmtDate(from)}${to !== from ? ' – ' + fmtDate(to) : ''})` });
    logAudit(u.id, `Applied for leave ${from} to ${to}`);
    closeModal(); commit(); toast(L('Leave request sent', 'छुट्टी आवेदन भेजा गया'));
  },
  leaveDecision: (fd, form) => {
    decideLeave(form.dataset.id, form.dataset.ok === '1', String(fd.get('remark') || '').trim(), me().id);
    closeModal(); commit();
    toast(form.dataset.ok === '1' ? L('Approved — substitutes drafted', 'स्वीकृत — अरेंजमेंट तैयार') : L('Rejected — teacher informed', 'अस्वीकृत — शिक्षक को सूचना'));
  },
  absent: (fd) => {
    const tid = fd.get('tid'); const date = fd.get('date'); const scope = fd.get('scope'); const periods = fd.getAll('periods').map(Number);
    if (!tid) { toast(L('Choose a teacher', 'शिक्षक चुनें')); return; }
    if (dayIdx(date) < 0) { toast(L('That date is a Sunday or a school holiday', 'वह तारीख़ रविवार या अवकाश है')); return; }
    if (scope === 'periods' && !periods.length) { toast(L('Choose at least one period', 'कम से कम एक पीरियड चुनें')); return; }
    addAbsence(tid, date, scope, periods, String(fd.get('note') || ''), me().id);
    UI.date = date; closeModal(); UI.view = 'subs'; commit();
    toast(L('Marked absent — substitutes drafted', 'अनुपस्थित दर्ज — अरेंजमेंट तैयार'));
  },
  cell: (fd, form) => {
    const d = Number(form.dataset.d), p = Number(form.dataset.p);
    const s = fd.get('s'), tid = s ? fd.get('t') : '';
    const s2 = s ? fd.get('s2') : '', t2 = s2 ? fd.get('t2') : '', joint = !!s && fd.get('j') === 'on';
    const fail = msg => { const e = document.getElementById('cellErr'); e.textContent = msg; e.classList.remove('hidden'); };
    if (s && !tid) return fail(L('Choose a teacher.', 'शिक्षक चुनें।'));
    if (s2 && !t2) return fail(L('Choose a teacher for the second group.', 'दूसरे समूह के लिए शिक्षक चुनें।'));
    if (t2 && t2 === tid) return fail(L('Choose two different teachers.', 'दो अलग शिक्षक चुनें।'));
    for (const x of [tid, t2].filter(Boolean)) {
      const clash = CLASSES.find(c => { if (c === UI.ttClass) return false; const o = lessonAt(c, d, p); return partsOf(o).some(g => g.t === x) && !(joint && o.j); });
      if (clash) return fail(L(`${nameOf(x)} already teaches ${clash} in this period.`, `${nameOf(x)} इस पीरियड में पहले से ${clash} में हैं।`));
    }
    const oldCell = lessonAt(UI.ttClass, d, p);
    const cell = s ? { s, t: tid } : null;
    if (cell && s2) cell.x = [{ s: s2, t: t2 }];
    if (cell && joint) cell.j = true;
    if (!S.tt[UI.ttClass][d]) S.tt[UI.ttClass][d] = PERIODS.map(() => null);
    S.tt[UI.ttClass][d][p - 1] = cell;
    const say = c => (c ? `${partsOf(c).map(g => g.s).join('+')}/${cellTeachers(c)}` : 'free/-');
    const now = cell ? `${cellSubj(cell)} with ${cellTeachers(cell)}` : 'a free period';
    logAudit(me().id, `Timetable ${UI.ttClass} ${DAYS[d]} P${p}: ${say(oldCell)} → ${say(cell)}`);
    const before = partsOf(oldCell).map(g => g.t), after = partsOf(cell).map(g => g.t);
    [...new Set(before.concat(after))].filter(x => x && before.includes(x) !== after.includes(x)).forEach(x => notify(x, '', { en: `Timetable changed: ${UI.ttClass} ${DAYS[d]} P${p} is now ${now}`, hi: `समय-सारणी बदली: ${UI.ttClass} ${DAYS_HI[d]} P${p} — ${cell ? cellSubj(cell) + ', ' + cellTeachers(cell) : 'खाली पीरियड'}` }));
    // refresh any upcoming plans for this weekday
    Object.keys(S.plans).forEach(dt => { if (dt >= todayISO() && dayIdx(dt) === d) generatePlan(dt, me().id); });
    closeModal(); commit(); toast(L('Saved', 'सहेजा गया'));
  },
  request: (fd, form) => {
    const u = me();
    const kind = form.dataset.kind;
    const r = { id: uid('rq'), kind, teacherId: u.id, classId: fd.get('classId'), subject: fd.get('subject'), copies: Number(fd.get('copies') || 0),
      neededBy: fd.get('neededBy'), description: String(fd.get('description') || '').trim(), status: 'requested', assignee: '', remark: '', draft: '',
      createdAt: nowStamp(), history: [{ at: nowStamp(), by: u.id, text: 'Request raised' }] };
    if (kind === 'dpp') Object.assign(r, { chapter: String(fd.get('chapter')).trim(), topic: String(fd.get('topic') || '').trim(), numQ: Number(fd.get('numQ') || 10), difficulty: fd.get('difficulty'), qtypes: fd.get('qtypes') });
    else Object.assign(r, { wsType: fd.get('wsType'), pageSize: fd.get('pageSize'), color: fd.get('color') });
    if (kind === 'worksheet' && r.description.length < 10) { toast(L('Please describe the worksheet in a little more detail', 'कृपया वर्कशीट का थोड़ा और विवरण दें')); return; }
    S.requests.push(r);
    notifyManagers({ en: `New ${kind === 'dpp' ? 'DPP' : 'worksheet'} request from ${u.name}: ${r.classId} ${SUBJECTS[r.subject].en}`, hi: `${u.name} का नया ${kind === 'dpp' ? 'DPP' : 'वर्कशीट'} अनुरोध: ${r.classId} ${SUBJECTS[r.subject].hi}` });
    logAudit(u.id, `Raised ${kind} request for ${r.classId} ${r.subject}`);
    closeModal(); UI.view = 'requests'; commit(); toast(L('Request sent for approval', 'अनुरोध स्वीकृति हेतु भेजा गया'));
  },
  reqApprove: (fd, form) => {
    const r = S.requests.find(x => x.id === form.dataset.id);
    r.status = 'approved'; r.assignee = fd.get('assignee'); r.remark = String(fd.get('remark') || '').trim();
    r.history.push({ at: nowStamp(), by: me().id, text: `Approved, assigned to ${nameOf(r.assignee)}${r.remark ? ' — ' + r.remark : ''}` });
    notify(r.teacherId, '', { en: `Your ${r.kind === 'dpp' ? 'DPP' : 'worksheet'} request (${r.classId}) was approved`, hi: `आपका ${r.kind === 'dpp' ? 'DPP' : 'वर्कशीट'} अनुरोध (${r.classId}) स्वीकृत हुआ` });
    if (r.assignee !== r.teacherId) notify(r.assignee, '', { en: `You have been assigned a ${r.kind === 'dpp' ? 'DPP' : 'worksheet'}: ${r.classId} ${SUBJECTS[r.subject].en}, needed by ${fmtDate(r.neededBy)}`, hi: `आपको ${r.kind === 'dpp' ? 'DPP' : 'वर्कशीट'} सौंपी गई: ${r.classId}, ${fmtDate(r.neededBy)} तक` });
    logAudit(me().id, `Approved ${r.kind} request ${r.classId} ${r.subject}`);
    closeModal(); commit();
  },
  reqReject: (fd, form) => {
    const r = S.requests.find(x => x.id === form.dataset.id);
    r.status = 'rejected'; r.remark = String(fd.get('remark')).trim();
    r.history.push({ at: nowStamp(), by: me().id, text: `Rejected — ${r.remark}` });
    notify(r.teacherId, '', { en: `Your ${r.kind === 'dpp' ? 'DPP' : 'worksheet'} request (${r.classId}) was rejected: ${r.remark}`, hi: `आपका अनुरोध (${r.classId}) अस्वीकृत: ${r.remark}` });
    logAudit(me().id, `Rejected ${r.kind} request ${r.classId} ${r.subject}`);
    closeModal(); commit();
  },
  staff: (fd, form) => {
    const id = form.dataset.id;
    const phone = String(fd.get('phone') || '').replace(/\D/g, '');
    const dup = phone && S.staff.find(s => s.phone === phone && s.id !== id);
    const err = document.getElementById('staffErr');
    if (dup) { err.textContent = L(`This number already belongs to ${dup.name}.`, `यह नंबर पहले से ${dup.name} का है।`); err.classList.remove('hidden'); return; }
    const data = { name: String(fd.get('name')).trim(), phone, role: fd.get('role'), subjects: fd.getAll('subjects'), active: fd.get('active') === 'on' };
    if (id) {
      const s = staffById(id);
      if (s.id === me().id && (!data.active || !isManager(data))) { err.textContent = L('You cannot remove your own admin access.', 'आप अपनी एडमिन पहुँच नहीं हटा सकते।'); err.classList.remove('hidden'); return; }
      Object.assign(s, data); logAudit(me().id, `Updated staff ${s.name}`);
    } else {
      const s = { id: uid('t'), ...data }; S.staff.push(s); sortStaff(); logAudit(me().id, `Added staff ${s.name}`);
      closeModal(); commit();
      queueFlush().then(async () => { await refreshCodes(); const c = UI.codes && UI.codes[s.id]; if (s.phone && c && c.code) showCode(s, c.code); });
      return;
    }
    closeModal(); commit(); toast(L('Saved', 'सहेजा गया'));
  },
  settings: (fd) => {
    Object.keys(S.settings).forEach(k => { const v = Number(fd.get(k)); if (!Number.isNaN(v)) S.settings[k] = Math.max(0, Math.min(100, v)); });
    if (S.settings.dailyCap < 1) S.settings.dailyCap = 1;
    logAudit(me().id, 'Changed substitution rules');
    Object.keys(S.plans).forEach(dt => { if (dt >= todayISO() && S.plans[dt].status !== 'published') generatePlan(dt, me().id); });
    commit(); toast(L('Rules saved — draft plans updated', 'नियम सहेजे — ड्राफ़्ट योजनाएँ अपडेट'));
  },
  notice: (fd) => {
    S.notices.unshift({ id: uid('nt'), by: me().id, at: nowStamp(), title: String(fd.get('title')).trim(), body: String(fd.get('body')).trim() });
    S.staff.filter(s => s.active && s.id !== me().id).forEach(s => notify(s.id, '', { en: `New notice: ${fd.get('title')}`, hi: `नई सूचना: ${fd.get('title')}` }));
    logAudit(me().id, `Posted notice "${fd.get('title')}"`);
    closeModal(); commit();
  },
  chat: (fd, form) => { const q = String(fd.get('q') || '').trim(); if (q) askAssistant(q); },
  quickAsk: (fd) => { const q = String(fd.get('q') || '').trim(); if (!q) return; UI.view = 'assistant'; askAssistant(q); window.scrollTo(0, 0); },
};

/* ---------- DPP / worksheet drafting ---------- */
function openDraft(id) {
  const r = S.requests.find(x => x.id === id);
  openModal(L('Draft', 'ड्राफ़्ट') + ` — ${r.kind === 'dpp' ? 'DPP' : t('worksheet')} ${r.classId} ${subjName(r.subject)}`, `
    <p class="hint">${L('Makes a ready-to-fill sheet in MTS format from the request. Type the questions in, then save or copy for printing.', 'अनुरोध से MTS प्रारूप में भरने योग्य शीट बनती है। प्रश्न लिखें, फिर प्रिंट के लिए सहेजें या कॉपी करें।')}</p>
    <textarea id="draftText" class="draft" rows="16">${esc(r.draft || '')}</textarea>
    <div class="row-end"><button class="btn ai" data-act="aiGenerate" data-id="${r.id}" id="genBtn">📄 ${r.draft ? L('Start again from template', 'टेम्पलेट से फिर शुरू') : t('aiDraft')}</button>
      <button class="btn ghost" data-act="copyDraft">📋 ${L('Copy', 'कॉपी')}</button><button class="btn primary" data-act="saveDraft" data-id="${r.id}">${t('save')}</button></div>`, { wide: true });
}
function templateDraft(r) {
  const top = `${SCHOOL.name}, ${SCHOOL.place}\n${r.kind === 'dpp' ? 'DAILY PRACTICE PROBLEMS (DPP)' : (r.wsType || '').toUpperCase() + ' WORKSHEET'}\nClass: ${r.classId}    Subject: ${SUBJECTS[r.subject].en}    Date: ________\nName: ______________________    Roll No: ______\n`;
  if (r.kind === 'dpp') {
    let s = `${top}Chapter: ${r.chapter}${r.topic ? '  |  Topic: ' + r.topic : ''}\nDifficulty: ${r.difficulty}   |   Types: ${r.qtypes}\n\n`;
    for (let i = 1; i <= Math.min(r.numQ, 50); i++) s += `Q${i}. ______________________________________________\n${/MCQ/i.test(r.qtypes) && i <= Math.ceil(r.numQ / 2) ? '   (a) ________   (b) ________   (c) ________   (d) ________\n' : ''}\n`;
    return s + `\nAnswer key\n${Array.from({ length: Math.min(r.numQ, 50) }, (_, i) => `Q${i + 1}: ____`).join('   ')}\n`;
  }
  return `${top}\nTeacher's brief: ${r.description}\n\nSection A — ______________________\n1. ____________________________\n2. ____________________________\n3. ____________________________\n\nSection B — ______________________\n4. ____________________________\n5. ____________________________\n\n[Picture: ______________________]\n\nTeacher's answer key: ______________________\n`;
}
/* ===================================================================
   Version 2 features: staff attendance (one-tap check-in, server time), leave
   balances and calendar, syllabus tracker, exam duties, notice read
   receipts, Excel / PDF reports, reminders, dark mode, offline copy,
   voice for the Smart Assistant, timetable period swap.
   =================================================================== */

/* ---------- small shared helpers ---------- */
const V2 = { checkBusy: false, checkMsg: null, swapFrom: null, attTab: 'today', attDate: null, leaveCal: null, syTab: null, examId: null, attempts: null, attemptsBusy: false, voiceOn: false, listening: false, reminded: {} };
const DEFAULT_ATT = { open: '07:00', late: '09:00', close: '12:00', outFrom: '13:30' };
const DEFAULT_LEAVE_POLICY = { yearStart: 4, Casual: 12, Sick: 10, Personal: 5, Emergency: 3, 'Official duty': 0 };
const LEAVE_TYPES = ['Casual', 'Sick', 'Personal', 'Official duty', 'Emergency'];
const campusCfg = () => ({ ...DEFAULT_ATT, ...((S.config && S.config.attendance) || {}) });
const leavePolicy = () => ({ ...DEFAULT_LEAVE_POLICY, ...((S.config && S.config.leavePolicy) || {}) });
const hmToMin = hm => { const [h, m] = String(hm || '0:0').split(':').map(Number); return h * 60 + m; };
const minToHM = m => pad(Math.floor(m / 60)) + ':' + pad(m % 60);
const fmtClock = isoLocal => (isoLocal ? String(isoLocal).slice(11, 16) : '');
const workDaysBetween = (from, to) => { const out = []; let d = from; let guard = 0; while (d <= to && guard++ < 400) { if (dayIdx(d) >= 0) out.push(d); d = addDays(d, 1); } return out; };
function deviceId() {
  try {
    let id = localStorage.getItem('mts-device');
    if (!id) { id = 'dv_' + Array.from(crypto.getRandomValues(new Uint8Array(12))).map(b => b.toString(16).padStart(2, '0')).join(''); localStorage.setItem('mts-device', id); }
    return id;
  } catch (e) { return 'dv_nostore_' + (navigator.userAgent || '').length + '_' + screen.width; }
}
/* =================================================================
   1. STAFF ATTENDANCE
   ================================================================= */
const attId = (tid, date) => `at_${tid}_${date}`;
const attOf = (tid, date) => S.attendance.find(a => a.teacherId === tid && a.date === date) || null;

/* what a person's day looks like: present / late / review / absent / leave / not_in / holiday */
/* attendance counts only from the day it was started (no "absent" for days before the feature existed) */
function attSince() {
  const c = (S.config && S.config.attendance) || {};
  if (c.since) return c.since;
  const first = S.attendance.reduce((m, a) => (!m || a.date < m ? a.date : m), null);
  return first || todayISO();
}
function attStatus(tid, date) {
  if (dayIdx(date) < 0) return 'holiday';
  if (date < attSince()) return 'untracked';
  const a = attOf(tid, date);
  if (a && a.status) return a.status;
  const fullLeave = S.absences.some(x => x.teacherId === tid && x.date === date && x.scope === 'full');
  if (fullLeave) return 'leave';
  const cfg = campusCfg();
  if (date < todayISO() || (date === todayISO() && nowHM() > cfg.close)) return 'absent';
  return 'not_in';
}
const ATT_LABEL = {
  present: ['Present', 'उपस्थित'], late: ['Late', 'देर से'], review: ['Needs approval', 'स्वीकृति बाकी'], absent: ['Absent', 'अनुपस्थित'],
  leave: ['On leave', 'छुट्टी पर'], not_in: ['Not checked in', 'चेक-इन नहीं'], holiday: ['Holiday', 'छुट्टी का दिन'], rejected: ['Refused', 'अस्वीकार'], untracked: ['Before attendance started', 'हाज़िरी शुरू होने से पहले'],
};
const attLabel = st => L(...(ATT_LABEL[st] || [st, st]));
const attChip = st => `<span class="chip att-${esc(st)}">${esc(attLabel(st))}</span>`;
const FLAG_LABEL = {
  new_device: ['New phone', 'नया फ़ोन'], phone_timezone: ['Phone time zone not India', 'फ़ोन का समय-क्षेत्र भारत नहीं'],
};
const flagText = f => L(...(FLAG_LABEL[f] || [f, f]));
const CHECK_ERRORS = {
  device_used: ['This phone has already been used today by another teacher. Each teacher must use their own phone.', 'इस फ़ोन से आज किसी दूसरे शिक्षक ने हाज़िरी लगाई है। हर शिक्षक अपने ही फ़ोन से लगाएँ।'],
  already_in: ['You have already checked in today.', 'आप आज पहले ही चेक-इन कर चुके हैं।'],
  already_out: ['You have already checked out today.', 'आप आज पहले ही चेक-आउट कर चुके हैं।'],
  not_in: ['Check in first.', 'पहले चेक-इन करें।'],
  too_early: ['Check-in is not open yet.', 'चेक-इन अभी शुरू नहीं हुआ।'],
  too_late: ['Check-in time is over for today. Please contact the office.', 'आज चेक-इन का समय खत्म हो गया। ऑफ़िस से संपर्क करें।'],
  too_early_out: ['Check-out is not open yet.', 'चेक-आउट अभी शुरू नहीं हुआ।'],
  no_school: ['No school today.', 'आज स्कूल बंद है।'],
  holiday: ['Today is a school holiday — no check-in needed.', 'आज विद्यालय अवकाश है — चेक-इन की ज़रूरत नहीं।'],
  too_many: ['Too many attempts today. Please contact the office.', 'आज बहुत ज़्यादा कोशिशें हुईं। ऑफ़िस से संपर्क करें।'],
  not_signed_in: ['Please log in again.', 'फिर से लॉग इन करें।'],
  bad_device: ['This browser cannot keep a device id. Turn off private browsing.', 'यह ब्राउज़र डिवाइस आईडी नहीं रख सकता। प्राइवेट ब्राउज़िंग बंद करें।'],
  offline: ['No internet connection.', 'इंटरनेट कनेक्शन नहीं है।'],
  setup: ['Attendance is not switched on in the database yet (the office must run the update).', 'डेटाबेस में हाज़िरी अभी चालू नहीं है (ऑफ़िस को अपडेट चलाना होगा)।'],
};
const checkErr = code => L(...(CHECK_ERRORS[code] || [`Could not mark attendance (${code}).`, `हाज़िरी नहीं लगी (${code})।`]));

async function doCheck(kind) {
  if (V2.checkBusy) return;
  if (!navigator.onLine) { V2.checkMsg = { kind: 'bad', text: checkErr('offline') }; render(); return; }
  V2.checkBusy = true; V2.checkMsg = { kind: 'busy', text: L('Marking…', 'दर्ज हो रहा है…') }; render();
  const meta = { tz: new Date().getTimezoneOffset(), ua: (navigator.userAgent || '').slice(0, 160), standalone: matchMedia('(display-mode: standalone)').matches };
  try {
    const { data, error } = await SB.rpc('check_in', { p_kind: kind, p_device: deviceId(), p_meta: meta });
    if (error) throw error;
    V2.checkBusy = false;
    if (data && data.ok) {
      const rec = data.record;
      const i = S.attendance.findIndex(a => a.id === rec.id);
      if (i >= 0) S.attendance[i] = rec; else S.attendance.unshift(rec);
      LAST.attendance = LAST.attendance || new Map(); LAST.attendance.set(rec.id, JSON.stringify(rec));
      V2.checkMsg = { kind: 'ok', text: kind === 'in' ? L(`Checked in at ${fmtClock(rec.in.at)} — ${attLabel(rec.status)}.`, `${fmtClock(rec.in.at)} बजे चेक-इन — ${attLabel(rec.status)}।`)
        : L(`Checked out at ${fmtClock(rec.out.at)}.`, `${fmtClock(rec.out.at)} बजे चेक-आउट।`) };
      logAudit(me().id, `Checked ${kind}`);
      queueFlush();
    } else V2.checkMsg = { kind: 'bad', text: checkErr((data && data.error) || 'unknown') };
  } catch (e) {
    V2.checkBusy = false;
    const missing = /check_in|function|does not exist|schema cache/i.test((e && e.message) || '');
    V2.checkMsg = { kind: 'bad', text: checkErr(missing ? 'setup' : 'offline') };
  }
  render();
}

/* the check-in card on My Day (also shown to the office for their own attendance) */
function checkCardHTML() {
  const u = me();
  const date = todayISO();
  if (UI.date !== date) return '';
  const cfg = campusCfg();
  const a = attOf(u.id, date);
  const st = attStatus(u.id, date);
  const m = V2.checkMsg;
  let body = '';
  if (dayIdx(date) < 0) body = `<p class="muted">${esc(noSchoolMsg(date))}</p>`;
  else if (st === 'leave') body = `<p>${attChip('leave')}</p>`;
  else {
    const inDone = a && a.in, outDone = a && a.out;
    body = `<div class="att-row">
      <div class="att-step ${inDone ? 'done' : ''}"><b>${L('Check in', 'चेक-इन')}</b><span>${inDone ? fmtClock(a.in.at) : `${cfg.open}–${cfg.close}`}</span></div>
      <div class="att-step ${outDone ? 'done' : ''}"><b>${L('Check out', 'चेक-आउट')}</b><span>${outDone ? fmtClock(a.out.at) : L('from', 'से') + ' ' + cfg.outFrom}</span></div>
      </div>
      ${!inDone ? `<button class="btn primary big" data-act="checkIn" ${V2.checkBusy ? 'disabled' : ''}>✅ ${L('Mark my attendance', 'मेरी हाज़िरी लगाएँ')}</button>`
        : !outDone && a.status !== 'review' && a.status !== 'rejected' ? `<button class="btn big" data-act="checkOut" ${V2.checkBusy ? 'disabled' : ''}>🏁 ${L('Check out', 'चेक-आउट')}</button>` : ''}
`;
  }
  const msg = m ? `<div id="checkMsg" class="banner ${m.kind === 'ok' ? 'ok' : m.kind === 'bad' ? 'bad' : ''}">${esc(m.text)}</div>` : '';
  return `<section class="panel att-card"><div class="panel-head"><h3>✅ ${L('My attendance', 'मेरी हाज़िरी')} · ${fmtDate(date)}</h3>${dayIdx(date) >= 0 && st ? attChip(st) : ''}</div>${body}${msg}
    <p class="hint">${L(`The time is taken from the school server, not your phone. Late after ${cfg.late}. Use your own phone: one phone can mark only one teacher a day.`, `समय स्कूल सर्वर से लिया जाता है, फ़ोन से नहीं। ${cfg.late} के बाद देर। अपना फ़ोन उपयोग करें: एक फ़ोन से दिन में एक ही शिक्षक की हाज़िरी लगती है।`)}</p></section>`;
}

/* the office: attendance board */
function viewAttendance() {
  const u = me();
  if (!isManager(u)) return viewMyAttendance();
  if (S.v2Missing) return `<div class="page-head"><h2>${L('Staff attendance', 'स्टाफ़ हाज़िरी')}</h2></div><div class="banner bad">${checkErr('setup')}</div>`;
  const date = V2.attDate || todayISO();
  const tab = V2.attTab;
  const people = S.staff.filter(s => s.active && s.id !== u.id || (s.active && s.id === u.id && s.role !== 'admin'));
  const rows = people.map(p => ({ p, a: attOf(p.id, date), st: attStatus(p.id, date) }));
  const count = st => rows.filter(r => r.st === st).length;
  const reviews = S.attendance.filter(a => a.status === 'review').sort((a, b) => b.date.localeCompare(a.date));
  const cfg = campusCfg();
  const tabs = [['today', L('Day board', 'दिन का बोर्ड')], ...(reviews.length ? [['review', L('Approvals', 'स्वीकृति') + ` (${reviews.length})`]] : []), ['month', L('Month register', 'मासिक रजिस्टर')], ['attempts', L('Check-in log', 'चेक-इन लॉग')]];
  let body = '';
  if (tab === 'today') {
    const order = { review: 0, not_in: 1, absent: 2, late: 3, present: 4, leave: 5, rejected: 2, holiday: 6 };
    body = `<div class="cards">
      <div class="stat ok"><span>${attLabel('present')}</span><b>${count('present')}</b></div>
      <div class="stat ${count('late') ? 'warn' : ''}"><span>${attLabel('late')}</span><b>${count('late')}</b></div>
      <div class="stat ${count('not_in') + count('absent') ? 'warn' : ''}"><span>${date === todayISO() && nowHM() <= cfg.close ? attLabel('not_in') : attLabel('absent')}</span><b>${count('not_in') + count('absent')}</b></div>
      <div class="stat"><span>${attLabel('leave')}</span><b>${count('leave')}</b></div>
    </div>
    <section class="panel"><div class="table-wrap"><table class="data att">
      <thead><tr><th>${L('Staff', 'स्टाफ़')}</th><th>${t('status')}</th><th>${L('In', 'आए')}</th><th>${L('Out', 'गए')}</th><th>${L('Warnings', 'चेतावनी')}</th><th></th></tr></thead>
      <tbody>${rows.sort((a, b) => (order[a.st] ?? 9) - (order[b.st] ?? 9) || a.p.name.localeCompare(b.p.name)).map(({ p, a, st }) => `<tr>
        <td data-label="${esc(L('Staff', 'स्टाफ़'))}"><b>${esc(p.name)}</b>${p.role !== 'teacher' ? `<small class="muted"> · ${esc(roleLabel(p.role))}</small>` : ''}</td>
        <td data-label="${esc(t('status'))}">${attChip(st)}${a && a.source === 'office' ? `<small class="muted"> ${L('by office', 'ऑफ़िस द्वारा')}</small>` : ''}</td>
        <td data-label="${esc(L('In', 'आए'))}">${a && a.in && a.in.at ? fmtClock(a.in.at) : '—'}</td>
        <td data-label="${esc(L('Out', 'गए'))}">${a && a.out ? fmtClock(a.out.at) : '—'}</td>
        <td data-label="${esc(L('Warnings', 'चेतावनी'))}">${a && a.flags && a.flags.length ? a.flags.map(f => `<span class="chip st-rejected small">${esc(flagText(f))}</span>`).join(' ') : ''}${a && a.note ? `<small class="muted"> “${esc(a.note)}”</small>` : ''}</td>
        <td class="btns">${st === 'review' ? `<button class="btn tiny ok" data-act="attApprove" data-id="${a.id}">${t('approve')}</button><button class="btn tiny danger-ghost" data-act="attReject" data-id="${a.id}">${t('reject')}</button>`
          : st === 'not_in' || st === 'absent' || st === 'rejected' ? `<button class="btn tiny ghost" data-act="attOffice" data-tid="${p.id}" data-st="present">${L('Mark present', 'उपस्थित करें')}</button>${p.role === 'teacher' && !isAbsent(p.id, date, 1) ? `<button class="btn tiny danger-ghost" data-act="attAbsent" data-tid="${p.id}">${L('Absent + arrange', 'अनुपस्थित + अरेंजमेंट')}</button>` : ''}`
          : a && a.source === 'office' ? `<button class="btn tiny ghost" data-act="attClear" data-id="${a.id}">${L('Undo', 'वापस')}</button>` : ''}</td></tr>`).join('')}</tbody></table></div></section>`;
  } else if (tab === 'review') {
    body = reviews.length ? `<div class="cards-list">${reviews.map(a => `<div class="card"><div class="card-top"><div>${avatar(nameOf(a.teacherId))}<div><strong>${esc(nameOf(a.teacherId))}</strong><small>${fmtDate(a.date)} · ${fmtClock(a.in && a.in.at)}</small></div></div>${attChip('review')}</div>
      <p>${(a.flags || []).map(f => `<span class="chip st-rejected small">${esc(flagText(f))}</span>`).join(' ')}</p>${a.note ? `<p class="desc">“${esc(a.note)}”</p>` : ''}
      <div class="row-end"><button class="btn small danger-ghost" data-act="attReject" data-id="${a.id}">${t('reject')}</button><button class="btn small ok" data-act="attApprove" data-id="${a.id}">${t('approve')}</button></div></div>`).join('')}</div>`
      : `<div class="empty">✅ ${L('Nothing waiting for approval.', 'स्वीकृति हेतु कुछ नहीं।')}</div>`;
  } else if (tab === 'month') {
    body = monthRegisterHTML(UI.reportMonth || todayISO().slice(0, 7));
  } else {
    body = attemptsHTML();
  }
  return `<div class="page-head"><h2>${L('Staff attendance', 'स्टाफ़ हाज़िरी')}</h2>${tab === 'today' ? `<div class="datebar"><button class="btn small ghost" data-act="attShift" data-n="-1">‹</button><input type="date" value="${date}" data-change="attDate"><button class="btn small ghost" data-act="attShift" data-n="1">›</button></div>` : tab === 'month' ? `<input type="month" value="${UI.reportMonth || todayISO().slice(0, 7)}" data-change="reportMonth">` : ''}</div>
    <div class="tabs">${tabs.map(([k, label]) => `<button class="tab ${tab === k ? 'active' : ''}" data-act="attTab" data-tab="${k}">${esc(label)}</button>`).join('')}</div>
    ${tab === 'today' && u.role !== 'admin' ? checkCardHTML() : ''}${body}`;
}

function monthStats(tid, ym) {
  const [y, m] = ym.split('-').map(Number);
  const last = new Date(y, m, 0).getDate();
  const out = { present: 0, late: 0, absent: 0, leave: 0, review: 0, days: 0 };
  for (let d = 1; d <= last; d++) {
    const iso = `${ym}-${pad(d)}`;
    if (iso > todayISO() || dayIdx(iso) < 0) continue;
    const st = attStatus(tid, iso);
    if (st === 'not_in' || st === 'untracked') continue;
    out.days++;
    if (st === 'rejected') out.absent++; else if (out[st] != null) out[st]++;
  }
  return out;
}
function monthRegisterHTML(ym) {
  const [y, m] = ym.split('-').map(Number);
  const last = new Date(y, m, 0).getDate();
  const days = Array.from({ length: last }, (_, i) => `${ym}-${pad(i + 1)}`);
  const people = S.staff.filter(s => s.active && s.role !== 'admin');
  const sym = { present: 'P', late: 'L', absent: 'A', leave: 'LV', review: '?', holiday: '', not_in: '', rejected: 'A' };
  const missingOld = ym < addDays(todayISO(), -70).slice(0, 7);
  return `${missingOld && !V2.loadedMonths?.[ym] ? `<div class="banner">${L('Loading older records…', 'पुराने रिकॉर्ड लोड हो रहे हैं…')}</div>` : ''}
    <section class="panel"><div class="table-wrap"><table class="data register"><thead><tr><th>${L('Staff', 'स्टाफ़')}</th>${days.map(d => `<th class="${dayIdx(d) < 0 ? 'sun' : ''}" title="${esc(holidayName(d) || '')}">${Number(d.slice(8))}${holidayName(d) ? '🎉' : ''}</th>`).join('')}<th>P</th><th>L</th><th>A</th><th>LV</th></tr></thead>
    <tbody>${people.map(p => { const s = monthStats(p.id, ym); return `<tr><td><b>${esc(p.name)}</b></td>${days.map(d => { const st = d > todayISO() ? '' : attStatus(p.id, d); return `<td class="r-${st}">${sym[st] || ''}</td>`; }).join('')}<td>${s.present}</td><td>${s.late}</td><td>${s.absent}</td><td>${s.leave}</td></tr>`; }).join('')}</tbody></table></div>
    <p class="hint">P = ${attLabel('present')} · L = ${attLabel('late')} · A = ${attLabel('absent')} · LV = ${attLabel('leave')} · ? = ${attLabel('review')}</p>
    <div class="row-end"><button class="btn primary" data-act="exportSalary">💼 ${L('Salary sheet', 'वेतन शीट')}</button><button class="btn ghost" data-act="exportAttendance">⬇️ ${L('Download Excel', 'Excel डाउनलोड')}</button><button class="btn ghost" data-act="printAttendance">📄 PDF</button></div></section>`;
}
function attemptsHTML() {
  if (V2.attempts === null && !V2.attemptsBusy) { loadAttempts(); return `<div class="empty">${L('Loading…', 'लोड हो रहा है…')}</div>`; }
  if (V2.attemptsBusy) return `<div class="empty">${L('Loading…', 'लोड हो रहा है…')}</div>`;
  const list = V2.attempts || [];
  return `<section class="panel"><div class="panel-head"><h3>${L('Every check-in attempt, last 7 days', 'पिछले 7 दिन की हर चेक-इन कोशिश')}</h3><button class="btn small ghost" data-act="attemptsReload">↻</button></div>
    <p class="hint">${L('Refused attempts show, for example, one phone being used for another teacher, or check-ins after closing time.', 'अस्वीकृत कोशिशें दिखाती हैं, जैसे एक फ़ोन से दूसरे शिक्षक की हाज़िरी, या बंद होने के बाद चेक-इन।')}</p>
    ${list.length ? `<div class="table-wrap"><table class="data"><thead><tr><th>${L('When', 'कब')}</th><th>${L('Staff', 'स्टाफ़')}</th><th>${L('Result', 'परिणाम')}</th></tr></thead>
    <tbody>${list.map(r => { const ok = /^ok:/.test(r.result), rv = /^review:/.test(r.result); const code = r.result.replace(/^(ok|review):/, ''); return `<tr class="${ok ? '' : rv ? '' : 'row-bad'}"><td>${fmtTime(r.at)}</td><td>${esc(nameOf(r.staff_id))}</td><td>${ok ? `<span class="ok-text">✓ ${code === 'in' ? L('Checked in', 'चेक-इन') : L('Checked out', 'चेक-आउट')}</span>` : `✕ ${esc(checkErr(code))}`}</td></tr>`; }).join('')}</tbody></table></div>` : `<div class="empty">${L('No attempts yet.', 'अभी कोई कोशिश नहीं।')}</div>`}</section>`;
}
async function loadAttempts() {
  V2.attemptsBusy = true;
  try { const { data, error } = await SB.rpc('attendance_attempts', { p_days: 7 }); V2.attempts = error ? [] : data || []; }
  catch (e) { V2.attempts = []; }
  V2.attemptsBusy = false; render();
}
async function ensureMonthLoaded(ym) {
  V2.loadedMonths = V2.loadedMonths || {};
  if (V2.loadedMonths[ym] || ym >= addDays(todayISO(), -70).slice(0, 7)) return;
  V2.loadedMonths[ym] = 'loading';
  try {
    const { data } = await SB.from('attendance').select('id,data').gte('data->>date', ym + '-01').lte('data->>date', ym + '-31').limit(5000);
    (data || []).forEach(r => { if (!S.attendance.some(a => a.id === r.id)) { S.attendance.push(r.data); (LAST.attendance = LAST.attendance || new Map()).set(r.id, JSON.stringify(r.data)); } });
  } catch (e) { }
  V2.loadedMonths[ym] = true; render();
}

/* teacher: my attendance history */
function viewMyAttendance() {
  const u = me();
  const ym = UI.reportMonth || todayISO().slice(0, 7);
  const s = monthStats(u.id, ym);
  const mine = S.attendance.filter(a => a.teacherId === u.id && a.date.startsWith(ym)).sort((a, b) => b.date.localeCompare(a.date));
  return `<div class="page-head"><h2>${L('My attendance', 'मेरी हाज़िरी')}</h2><input type="month" value="${ym}" data-change="reportMonth"></div>
    ${checkCardHTML()}
    <div class="cards"><div class="stat ok"><span>${attLabel('present')}</span><b>${s.present}</b></div><div class="stat ${s.late ? 'warn' : ''}"><span>${attLabel('late')}</span><b>${s.late}</b></div>
      <div class="stat ${s.absent ? 'warn' : ''}"><span>${attLabel('absent')}</span><b>${s.absent}</b></div><div class="stat"><span>${attLabel('leave')}</span><b>${s.leave}</b></div></div>
    <section class="panel">${mine.length ? `<ul class="list">${mine.map(a => `<li><div><div><strong>${fmtDate(a.date)}</strong><small>${a.in && a.in.at ? L('In', 'आए') + ' ' + fmtClock(a.in.at) : ''}${a.out ? ' · ' + L('Out', 'गए') + ' ' + fmtClock(a.out.at) : ''}${a.source === 'office' ? ' · ' + L('marked by office', 'ऑफ़िस द्वारा') : ''}</small></div></div>${attChip(a.status)}</li>`).join('')}</ul>` : `<p class="muted">${L('No records this month.', 'इस माह कोई रिकॉर्ड नहीं।')}</p>`}</section>`;
}

/* =================================================================
   2. LEAVE: balances and calendar
   ================================================================= */
const leaveUnits = l => { const days = workDaysBetween(l.from, l.to).length; return l.scope === 'full' ? days : days * 0.5; };
function leaveYear(iso = todayISO()) {
  const ys = Number(leavePolicy().yearStart) || 4;
  const [y, m] = iso.split('-').map(Number);
  const startY = m >= ys ? y : y - 1;
  return { from: `${startY}-${pad(ys)}-01`, to: addDays(`${startY + 1}-${pad(ys)}-01`, -1), label: `${startY}–${String(startY + 1).slice(2)}` };
}
function leaveBalance(tid) {
  const pol = leavePolicy(), yr = leaveYear();
  return LEAVE_TYPES.filter(tp => Number(pol[tp]) > 0).map(tp => {
    const used = S.leaves.filter(l => l.teacherId === tid && l.type === tp && l.status === 'approved' && l.from >= yr.from && l.from <= yr.to).reduce((a, l) => a + leaveUnits(l), 0);
    const pending = S.leaves.filter(l => l.teacherId === tid && l.type === tp && l.status === 'pending' && l.from >= yr.from && l.from <= yr.to).reduce((a, l) => a + leaveUnits(l), 0);
    return { type: tp, allowed: Number(pol[tp]), used, pending, left: Number(pol[tp]) - used };
  });
}
function balanceHTML(tid, compact) {
  const b = leaveBalance(tid);
  if (!b.length) return '';
  return `<div class="balances ${compact ? 'compact' : ''}">${b.map(x => `<div class="bal ${x.left <= 0 ? 'none' : x.left <= 2 ? 'low' : ''}"><span>${esc(leaveTypeName(x.type))}</span><b>${x.left}</b><small>${L('of', 'में से')} ${x.allowed}${x.pending ? ` · ${x.pending} ${L('pending', 'लंबित')}` : ''}</small><i style="width:${Math.max(0, Math.min(100, (x.used / Math.max(1, x.allowed)) * 100))}%"></i></div>`).join('')}</div>`;
}
const leaveTypeName = tp => ({ Casual: L('Casual', 'आकस्मिक'), Sick: L('Sick', 'बीमारी'), Personal: L('Personal', 'निजी'), 'Official duty': L('Official duty', 'सरकारी/विद्यालय कार्य'), Emergency: L('Emergency', 'आपातकालीन') }[tp] || tp);

function leaveCalendarHTML() {
  const ym = V2.leaveCal || todayISO().slice(0, 7);
  const [y, m] = ym.split('-').map(Number);
  const first = new Date(y, m - 1, 1), last = new Date(y, m, 0).getDate();
  const lead = (first.getDay() + 6) % 7; // Monday first
  const cells = [];
  for (let i = 0; i < lead; i++) cells.push('<div class="cal-cell blank"></div>');
  for (let d = 1; d <= last; d++) {
    const iso = `${ym}-${pad(d)}`;
    const on = S.leaves.filter(l => l.status !== 'rejected' && l.from <= iso && l.to >= iso && dayIdx(iso) >= 0);
    const abs = S.absences.filter(a => a.date === iso && !on.some(l => l.teacherId === a.teacherId));
    cells.push(`<div class="cal-cell ${dayIdx(iso) < 0 ? 'sun' : ''} ${iso === todayISO() ? 'today' : ''}"><b>${d}</b>${holidayName(iso) ? `<span class="cal-ev hol" title="${esc(holidayName(iso))}">🎉 ${esc(holidayName(iso))}</span>` : ''}
      ${on.map(l => `<span class="cal-ev ${l.status}" title="${esc(nameOf(l.teacherId) + ' · ' + l.type)}">${esc(nameOf(l.teacherId).split(' ')[0])}</span>`).join('')}
      ${abs.map(a => `<span class="cal-ev abs" title="${esc(nameOf(a.teacherId))}">${esc(nameOf(a.teacherId).split(' ')[0])}</span>`).join('')}</div>`);
  }
  const prev = (() => { const d = new Date(y, m - 2, 1); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; })();
  const next = (() => { const d = new Date(y, m, 1); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`; })();
  return `<section class="panel"><div class="panel-head"><h3>${first.toLocaleDateString(S.lang === 'hi' ? 'hi-IN' : 'en-IN', { month: 'long', year: 'numeric' })}</h3>
    <div class="btns"><button class="btn small ghost" data-act="leaveCal" data-ym="${prev}">‹</button><button class="btn small ghost" data-act="leaveCal" data-ym="${todayISO().slice(0, 7)}">${L('This month', 'यह माह')}</button><button class="btn small ghost" data-act="leaveCal" data-ym="${next}">›</button></div></div>
    <div class="cal">${(S.lang === 'hi' ? ['सोम', 'मंगल', 'बुध', 'गुरु', 'शुक्र', 'शनि', 'रवि'] : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']).map(d => `<div class="cal-h">${d}</div>`).join('')}${cells.join('')}</div>
    <p class="hint"><span class="cal-ev approved">${t('approved')}</span> <span class="cal-ev pending">${t('pending')}</span> <span class="cal-ev abs">${L('Marked absent', 'अनुपस्थित चिह्नित')}</span> <span class="cal-ev hol">🎉 ${L('School holiday', 'विद्यालय अवकाश')}</span></p></section>`;
}
function leaveBalancesTableHTML() {
  const pol = leavePolicy(); const yr = leaveYear();
  const types = LEAVE_TYPES.filter(tp => Number(pol[tp]) > 0);
  return `<section class="panel"><div class="panel-head"><h3>${L('Leave left this year', 'इस वर्ष शेष छुट्टी')} (${yr.label})</h3><button class="btn small ghost" data-act="go" data-view="settings">${L('Change allowance', 'सीमा बदलें')}</button></div>
    <div class="table-wrap"><table class="data"><thead><tr><th>${t('teacher')}</th>${types.map(tp => `<th>${esc(leaveTypeName(tp))} (${pol[tp]})</th>`).join('')}</tr></thead>
    <tbody>${teachers().map(tc => { const b = leaveBalance(tc.id); return `<tr><td>${esc(tc.name)}</td>${types.map(tp => { const x = b.find(z => z.type === tp); return `<td class="${x.left <= 0 ? 'bad' : x.left <= 2 ? 'warn-text' : ''}">${x.left}${x.pending ? ` <small class="muted">(${x.pending} ${L('pending', 'लंबित')})</small>` : ''}</td>`; }).join('')}</tr>`; }).join('')}</tbody></table></div></section>`;
}

/* =================================================================
   3. SYLLABUS TRACKER
   ================================================================= */
const syId = (cls, subj) => `sy_${cls.replace(/\s+/g, '_')}_${subj}`;
const syRow = (cls, subj) => S.syllabus.find(x => x.id === syId(cls, subj)) || null;
const syPct = r => (r && r.chapters.length ? Math.round((r.chapters.filter(c => c.done).length / r.chapters.length) * 100) : 0);
/* class + subject pairs a teacher teaches (from the timetable) */
function myPairs(tid) {
  const out = new Map();
  CLASSES.forEach(c => (S.tt[c] || []).forEach(day => day.forEach(l => partsOf(l).forEach(g => { if (g.t === tid) out.set(`${c}|${g.s}`, { cls: c, subject: g.s }); }))));
  return [...out.values()].sort((a, b) => CLASSES.indexOf(a.cls) - CLASSES.indexOf(b.cls) || a.subject.localeCompare(b.subject));
}
function allPairs() {
  const out = new Map();
  CLASSES.forEach(c => (S.tt[c] || []).forEach(day => day.forEach(l => partsOf(l).forEach(g => { const k = `${c}|${g.s}`; if (!out.has(k)) out.set(k, { cls: c, subject: g.s, teachers: new Set() }); out.get(k).teachers.add(g.t); }))));
  return [...out.values()];
}
function viewSyllabus() {
  const u = me(), mgr = isManager(u);
  if (S.v2Missing) return `<div class="page-head"><h2>${L('Syllabus', 'पाठ्यक्रम')}</h2></div><div class="banner bad">${checkErr('setup')}</div>`;
  if (mgr && V2.syTab !== 'edit') {
    const pairs = allPairs();
    const subjects = [...new Set(pairs.map(p => p.subject))].sort();
    return `<div class="page-head"><h2>${L('Syllabus progress', 'पाठ्यक्रम प्रगति')}</h2><button class="btn ghost" data-act="exportSyllabus">⬇️ ${L('Download Excel', 'Excel डाउनलोड')}</button></div>
      <p class="muted">${L('Each subject teacher lists the chapters and ticks them off as they finish. Tap a cell to see or edit.', 'हर विषय शिक्षक अध्याय लिखते हैं और पूरा होने पर टिक करते हैं। देखने या बदलने के लिए किसी खाने पर टैप करें।')}</p>
      <section class="panel"><div class="table-wrap"><table class="data sy-matrix"><thead><tr><th>${t('class')}</th>${subjects.map(s => `<th>${esc(subjName(s))}</th>`).join('')}</tr></thead>
      <tbody>${CLASSES.map(c => `<tr><td><b>${esc(c)}</b></td>${subjects.map(s => { const p = pairs.find(x => x.cls === c && x.subject === s); if (!p) return '<td class="na">—</td>'; const r = syRow(c, s); const pc = syPct(r); return `<td><button class="sy-cell ${!r || !r.chapters.length ? 'empty' : pc >= 75 ? 'good' : pc >= 40 ? 'mid' : 'low'}" data-act="syOpen" data-cls="${esc(c)}" data-subj="${s}">${r && r.chapters.length ? pc + '%' : L('not set', 'तय नहीं')}<small>${r ? r.chapters.filter(x => x.done).length + '/' + r.chapters.length : ''}</small></button></td>`; }).join('')}</tr>`).join('')}</tbody></table></div></section>`;
  }
  const pairs = mgr ? allPairs() : myPairs(u.id);
  return `<div class="page-head"><h2>${L('My syllabus', 'मेरा पाठ्यक्रम')}</h2>${mgr ? `<button class="btn ghost" data-act="syTab" data-tab="">← ${L('All classes', 'सभी कक्षाएँ')}</button>` : ''}</div>
    <p class="muted">${L('Add the chapters for each class you teach, then tick each one when it is finished. The office sees your progress.', 'जो कक्षाएँ पढ़ाते हैं उनके अध्याय जोड़ें, और पूरा होने पर टिक करें। ऑफ़िस आपकी प्रगति देखता है।')}</p>
    ${pairs.length ? `<div class="sy-grid">${pairs.map(p => { const r = syRow(p.cls, p.subject); const pc = syPct(r); return `<button class="card sy-card" data-act="syOpen" data-cls="${esc(p.cls)}" data-subj="${p.subject}">
      <div class="card-top"><div><strong>${esc(p.cls)} · ${esc(subjName(p.subject))}</strong></div><b>${r && r.chapters.length ? pc + '%' : ''}</b></div>
      <div class="bar"><i style="width:${pc}%"></i></div><small class="muted">${r && r.chapters.length ? `${r.chapters.filter(c => c.done).length} ${L('of', 'में से')} ${r.chapters.length} ${L('chapters done', 'अध्याय पूरे')}` : L('Tap to add chapters', 'अध्याय जोड़ने के लिए टैप करें')}</small></button>`; }).join('')}</div>`
      : `<div class="empty">${L('You have no classes in the timetable.', 'समय-सारणी में आपकी कोई कक्षा नहीं है।')}</div>`}`;
}
function syEditorHTML(cls, subj) {
  const r = syRow(cls, subj);
  const ch = r ? r.chapters : [];
  const owner = r ? r.teacherId : (allPairs().find(p => p.cls === cls && p.subject === subj) || { teachers: new Set([me().id]) }).teachers.values().next().value;
  const canEdit = isManager(me()) || owner === me().id || (!r && myPairs(me().id).some(p => p.cls === cls && p.subject === subj));
  return `<div class="stack" data-sy="${esc(cls)}|${subj}">
    <p class="muted">${L('Teacher', 'शिक्षक')}: <b>${esc(nameOf(owner))}</b>${r && r.updatedAt ? ' · ' + L('updated', 'अपडेट') + ' ' + fmtTime(r.updatedAt) : ''}</p>
    ${ch.length ? `<ol class="sy-list">${ch.map(c => `<li class="${c.done ? 'done' : ''}"><label><input type="checkbox" ${c.done ? 'checked' : ''} ${canEdit ? '' : 'disabled'} data-change="syTick" data-cls="${esc(cls)}" data-subj="${subj}" data-ch="${c.id}"> <span>${esc(c.name)}</span></label>${c.done && c.doneOn ? `<small class="muted">${fmtDate(c.doneOn)}</small>` : ''}${canEdit ? `<button class="btn tiny ghost" data-act="syDel" data-cls="${esc(cls)}" data-subj="${subj}" data-ch="${c.id}" aria-label="Remove">✕</button>` : ''}</li>`).join('')}</ol>` : `<p class="muted">${L('No chapters yet.', 'अभी कोई अध्याय नहीं।')}</p>`}
    ${canEdit ? `<form data-form="syAdd" data-cls="${esc(cls)}" data-subj="${subj}" class="stack"><label>${L('Add chapters (one per line)', 'अध्याय जोड़ें (हर पंक्ति में एक)')}<textarea name="names" rows="4" placeholder="${esc(L('1. Number System\n2. Algebra', '1. संख्या पद्धति\n2. बीजगणित'))}"></textarea></label>
      <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('close')}</button><button class="btn primary">${L('Add', 'जोड़ें')}</button></div></form>` : `<div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('close')}</button></div>`}</div>`;
}
function syUpsert(cls, subj, fn) {
  let r = syRow(cls, subj);
  if (!r) {
    const p = allPairs().find(x => x.cls === cls && x.subject === subj);
    const tid = p && p.teachers.has(me().id) ? me().id : p ? [...p.teachers][0] : me().id;
    r = { id: syId(cls, subj), teacherId: tid, cls, subject: subj, chapters: [], updatedAt: nowStamp() };
    S.syllabus.push(r);
  }
  fn(r); r.updatedAt = nowStamp();
}

/* =================================================================
   4. EXAM DUTIES (invigilation chart)
   ================================================================= */
const examById = id => S.exams.find(e => e.id === id);
const dutyKey = (date, sess, room) => `${date}|${sess}|${room}`;
function myDuties(tid, date) {
  const out = [];
  S.exams.filter(e => e.published).forEach(e => Object.entries(e.duties || {}).forEach(([k, ids]) => {
    if (!ids.includes(tid)) return;
    const [d, sess, room] = k.split('|');
    if (date && d !== date) return;
    const se = (e.sessions || []).find(s => s.id === sess) || { label: sess, time: '' };
    out.push({ exam: e.name, date: d, session: se.label, time: se.time, room });
  }));
  return out.sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time));
}
function autoAssign(e) {
  const load = {}; teachers().forEach(tc => { load[tc.id] = 0; });
  S.exams.filter(x => x.id !== e.id).forEach(x => Object.values(x.duties || {}).forEach(ids => ids.forEach(id => { if (load[id] != null) load[id] += 0.5; })));
  e.duties = {};
  (e.days || []).forEach(date => (e.sessions || []).forEach(se => {
    const busy = new Set();
    const avail = () => teachers().filter(tc => !busy.has(tc.id) && !S.absences.some(a => a.teacherId === tc.id && a.date === date && a.scope === 'full') && !S.leaves.some(l => l.teacherId === tc.id && l.status === 'approved' && l.from <= date && l.to >= date));
    (e.rooms || []).forEach(room => {
      const pick = [];
      for (let i = 0; i < (Number(e.perRoom) || 1); i++) {
        const list = avail().filter(tc => !pick.includes(tc.id)).sort((a, b) => load[a.id] - load[b.id] || ((a.id + date + room).length % 3) - ((b.id + date + room).length % 3) || a.name.localeCompare(b.name));
        // do not put a class's own class-teacher in that room
        const best = list.find(tc => S.classTeachers[room] !== tc.id) || list[0];
        if (!best) break;
        pick.push(best.id); busy.add(best.id); load[best.id]++;
      }
      e.duties[dutyKey(date, se.id, room)] = pick;
    });
  }));
}
function viewExams() {
  const u = me(), mgr = isManager(u);
  if (S.v2Missing) return `<div class="page-head"><h2>${L('Exam duties', 'परीक्षा ड्यूटी')}</h2></div><div class="banner bad">${checkErr('setup')}</div>`;
  if (!mgr) {
    const list = myDuties(u.id).filter(d => d.date >= addDays(todayISO(), -7));
    return `<div class="page-head"><h2>${L('My exam duties', 'मेरी परीक्षा ड्यूटी')}</h2></div>
      ${list.length ? `<section class="panel"><ul class="list">${list.map(d => `<li class="${d.date === todayISO() ? 'now' : ''}"><div><div><strong>${fmtDate(d.date)} · ${esc(d.session)} ${esc(d.time)}</strong><small>${esc(d.exam)} · ${L('Room', 'कक्ष')}: ${esc(d.room)}</small></div></div>${d.date === todayISO() ? `<span class="chip st-approved">${L('Today', 'आज')}</span>` : ''}</li>`).join('')}</ul></section>`
        : `<div class="empty">${L('No exam duties for you.', 'आपकी कोई परीक्षा ड्यूटी नहीं।')}</div>`}`;
  }
  const e = V2.examId && examById(V2.examId);
  if (!e) {
    return `<div class="page-head"><h2>${L('Exam duties', 'परीक्षा ड्यूटी')}</h2><button class="btn primary" data-act="examNew">+ ${L('New exam', 'नई परीक्षा')}</button></div>
      ${S.exams.length ? `<div class="cards-list">${S.exams.slice().sort((a, b) => (b.days[0] || '').localeCompare(a.days[0] || '')).map(x => `<div class="card"><div class="card-top"><div><strong>${esc(x.name)}</strong><small>${x.days.length ? fmtDate(x.days[0]) + (x.days.length > 1 ? ' – ' + fmtDate(x.days[x.days.length - 1]) : '') : ''} · ${x.days.length} ${L('days', 'दिन')} · ${x.rooms.length} ${L('rooms', 'कक्ष')}</small></div></div>${x.published ? statusChip('published') : statusChip('draft')}</div>
        <div class="row-end"><button class="btn small ghost" data-act="examDel" data-id="${x.id}">${L('Delete', 'हटाएँ')}</button><button class="btn small primary" data-act="examOpen" data-id="${x.id}">${L('Open chart', 'चार्ट खोलें')} →</button></div></div>`).join('')}</div>`
        : `<div class="empty">${L('No exams yet. Create one (e.g. Unit Test 1) and the app will share invigilation duties fairly.', 'अभी कोई परीक्षा नहीं। एक बनाएँ (जैसे यूनिट टेस्ट 1) और ऐप निरीक्षण ड्यूटी बराबर बाँटेगा।')}</div>`}`;
  }
  const count = {}; Object.values(e.duties || {}).forEach(ids => ids.forEach(id => { count[id] = (count[id] || 0) + 1; }));
  return `<div class="page-head"><h2>${esc(e.name)}</h2><div class="btns"><button class="btn ghost" data-act="examBack">← ${L('All exams', 'सभी परीक्षाएँ')}</button></div></div>
    <div class="row-end left">${e.published ? statusChip('published') : statusChip('draft')}
      <button class="btn" data-act="examAuto" data-id="${e.id}">⚖️ ${L('Share duties fairly', 'ड्यूटी बराबर बाँटें')}</button>
      <button class="btn ghost" data-act="examPrint" data-id="${e.id}">📄 PDF</button>
      <button class="btn ghost" data-act="examExport" data-id="${e.id}">⬇️ Excel</button>
      <button class="btn primary" data-act="examPublish" data-id="${e.id}">${e.published ? L('Publish again', 'फिर प्रकाशित करें') : t('publish')}</button></div>
    ${e.days.map(date => `<section class="panel"><h3>${fmtDate(date)}</h3><div class="table-wrap"><table class="data"><thead><tr><th>${L('Room', 'कक्ष')}</th>${e.sessions.map(se => `<th>${esc(se.label)} <small>${esc(se.time)}</small></th>`).join('')}</tr></thead>
      <tbody>${e.rooms.map(room => `<tr><td><b>${esc(room)}</b></td>${e.sessions.map(se => { const ids = (e.duties || {})[dutyKey(date, se.id, room)] || []; return `<td>${Array.from({ length: Number(e.perRoom) || 1 }, (_, i) => `<select data-change="examSet" data-id="${e.id}" data-key="${esc(dutyKey(date, se.id, room))}" data-i="${i}">${teacherOptions(ids[i] || '', { includeEmpty: true, emptyLabel: '—' })}</select>`).join('')}</td>`; }).join('')}</tr>`).join('')}</tbody></table></div></section>`).join('')}
    <section class="panel"><h3>${L('Duties per teacher', 'प्रति शिक्षक ड्यूटी')}</h3><p>${teachers().map(tc => `<span class="chip">${esc(tc.name)}: ${count[tc.id] || 0}</span>`).join(' ')}</p></section>`;
}
function examFormHTML() {
  const start = (() => { let d = addDays(todayISO(), 7); while (dayIdx(d) < 0) d = addDays(d, 1); return d; })();
  return `<form data-form="exam" class="stack">
    <label>${L('Exam name', 'परीक्षा का नाम')} *<input name="name" required placeholder="${esc(L('e.g. Unit Test 1', 'जैसे यूनिट टेस्ट 1'))}" list="examNames"><datalist id="examNames"><option>Unit Test 1</option><option>Terminal 1</option><option>Unit Test 2</option><option>Terminal 2</option></datalist></label>
    <div class="two"><label>${t('from')}<input type="date" name="from" value="${start}" required></label><label>${t('to')}<input type="date" name="to" value="${addDays(start, 5)}" required></label></div>
    <label>${L('Sessions (one per line: name, time)', 'सत्र (हर पंक्ति में: नाम, समय)')}<textarea name="sessions" rows="2">${L('Morning', 'प्रातः')}, 09:00–12:00</textarea></label>
    <label>${L('Rooms', 'कक्ष')}</label><div class="pick-grid">${CLASSES.map(c => `<label class="pp"><input type="checkbox" name="rooms" value="${esc(c)}" checked>${esc(c)}</label>`).join('')}</div>
    <label>${L('Invigilators per room', 'प्रति कक्ष निरीक्षक')}<input type="number" name="perRoom" value="1" min="1" max="3"></label>
    <p class="hint">${L('Sundays are skipped. The app shares duties so everyone gets about the same number, and skips teachers on leave.', 'रविवार छोड़ दिए जाते हैं। ऐप ड्यूटी बराबर बाँटता है और छुट्टी वाले शिक्षकों को छोड़ता है।')}</p>
    <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn primary">${L('Create', 'बनाएँ')}</button></div></form>`;
}

/* =================================================================
   5. NOTICE READ RECEIPTS (stored as "acks" with date = notice)
   ================================================================= */
const noticeRead = (nid, tid) => isAcked('notice', nid, tid);
function markNoticesRead() {
  const u = me(); if (!u || isManager(u)) return;
  let n = 0;
  S.notices.forEach(no => { if (!noticeRead(no.id, u.id)) { S.acks[ackId('notice', no.id, u.id)] = { teacherId: u.id, date: 'notice', key: no.id, at: nowStamp() }; n++; } });
  if (n) queueFlush();
}
function readersOf(nid) { return S.staff.filter(s => s.active && s.role === 'teacher').map(s => ({ s, read: noticeRead(nid, s.id) })); }

/* =================================================================
   6. NOW / NEXT and reminders
   ================================================================= */
function nowNextHTML() {
  const u = me(); const date = todayISO();
  if (UI.date !== date || dayIdx(date) < 0) return '';
  const hm = nowHM(); const d = dayIdx(date);
  const plan = S.plans[date];
  const subs = plan && plan.status === 'published' ? Object.values(plan.items).filter(i => i.teacherId === u.id) : [];
  const duty = p => { const sub = subs.find(i => i.p === p); if (sub) return { text: `${sub.cls} · ${subjName(sub.subject)}`, sub: true }; if (isAbsent(u.id, date, p)) return null; const l = teacherLessonAt(u.id, d, p); return l ? { text: `${l.label} · ${subjName(l.s)}` } : null; };
  const cur = PERIODS.find(p => hm >= p.start && hm < p.end);
  const nextP = PERIODS.find(p => p.start > hm && duty(p.n));
  if (!cur && !nextP) return '';
  const c = cur && duty(cur.n);
  const inLunch = !cur && hm >= LUNCH.start && hm < LUNCH.end;
  return `<section class="panel nownext"><div><small>${L('Now', 'अभी')}</small><b>${cur ? (c ? esc(c.text) : t('free')) : inLunch ? '🍱 ' + t('lunch') : '—'}</b><span>${cur ? `P${cur.n} · ${L('till', 'तक')} ${cur.end}` : ''}${c && c.sub ? ' · ' + t('substitution') : ''}</span></div>
    <div><small>${L('Next', 'अगला')}</small><b>${nextP ? esc(duty(nextP.n).text) : L('Nothing more today', 'आज और कुछ नहीं')}</b><span>${nextP ? `P${nextP.n} · ${nextP.start}` : ''}</span></div></section>`;
}
function notifSupported() { return 'Notification' in window; }
async function sysNotify(title, body, tag) {
  if (!notifSupported() || Notification.permission !== 'granted') return;
  try {
    const reg = navigator.serviceWorker && (await navigator.serviceWorker.getRegistration());
    if (reg) reg.showNotification(title, { body, tag, icon: '../icon-192.png', badge: '../icon-192.png' });
    else new Notification(title, { body, tag, icon: '../icon-192.png' });
  } catch (e) { }
}
function reminderTick() {
  const u = me(); if (!u || isManager(u)) return;
  const date = todayISO(); const d = dayIdx(date); if (d < 0) return;
  const now = new Date(); const nowMin = now.getHours() * 60 + now.getMinutes();
  const plan = S.plans[date];
  const subs = plan && plan.status === 'published' ? Object.values(plan.items).filter(i => i.teacherId === u.id) : [];
  PERIODS.forEach(p => {
    const diff = hmToMin(p.start) - nowMin;
    if (diff < 0 || diff > 5) return;
    const key = date + '|' + p.n; if (V2.reminded[key]) return;
    const sub = subs.find(i => i.p === p.n);
    const l = sub ? null : (!isAbsent(u.id, date, p.n) && teacherLessonAt(u.id, d, p.n));
    if (!sub && !l) return;
    V2.reminded[key] = 1;
    const text = sub ? `${t('substitution')}: ${sub.cls} · ${subjName(sub.subject)}` : `${l.label} · ${subjName(l.s)}`;
    toast(`⏰ P${p.n} ${L('at', '')} ${p.start} — ${text}`);
    sysNotify(`P${p.n} ${L('at', '')} ${p.start}`, text, 'period-' + key);
  });
  // check-in reminder at opening time
  const cfg = campusCfg();
  if (!attOf(u.id, date) && !isAbsent(u.id, date, 1)) {
    const k = date + '|checkin';
    if (!V2.reminded[k] && nowMin >= hmToMin(cfg.late) - 20 && nowMin <= hmToMin(cfg.late)) { V2.reminded[k] = 1; sysNotify(L('Mark your attendance', 'हाज़िरी लगाएँ'), L(`Check in before ${cfg.late}.`, `${cfg.late} से पहले चेक-इन करें।`), 'checkin-' + date); }
  }
}
let lastNotifIds = null;
function notifWatch() {
  const u = me(); if (!u) return;
  const mine = S.notifications.filter(n => n.userId === u.id && !n.read);
  const ids = new Set(mine.map(n => n.id));
  if (lastNotifIds) mine.filter(n => !lastNotifIds.has(n.id)).slice(0, 3).forEach(n => sysNotify(SCHOOL.short + ' · ' + L('New', 'नया'), S.lang === 'hi' ? n.hi : n.en, n.id));
  lastNotifIds = ids;
}

/* =================================================================
   7. EXCEL (.xlsx) WRITER — no outside library
   ================================================================= */
const CRC_TABLE = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(bytes) { let c = 0xFFFFFFFF; for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
function zipStore(files) {
  const enc = new TextEncoder(); const parts = []; const central = []; let offset = 0;
  const u16 = n => [n & 255, (n >>> 8) & 255], u32 = n => [n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255];
  files.forEach(f => {
    const name = enc.encode(f.name), data = typeof f.data === 'string' ? enc.encode(f.data) : f.data, crc = crc32(data);
    const head = [0x50, 0x4b, 3, 4, ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0)];
    parts.push(new Uint8Array(head), name, data);
    central.push(new Uint8Array([0x50, 0x4b, 1, 2, ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(name.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset)]), name);
    offset += head.length + name.length + data.length;
  });
  const cSize = central.reduce((a, b) => a + b.length, 0);
  const end = new Uint8Array([0x50, 0x4b, 5, 6, ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length), ...u32(cSize), ...u32(offset), ...u16(0)]);
  return new Blob([...parts, ...central, end], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}
const xmlEsc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '');
const colName = i => { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
/* sheets: [{ name, rows: [[...], ...], widths?: [] }] — first row is bold */
function makeXlsx(sheets) {
  const safe = n => xmlEsc(String(n).replace(/[\\\/?*\[\]:]/g, ' ').slice(0, 31));
  const sheetXml = sh => `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>`
    + `<cols>${(sh.rows[0] || []).map((_, i) => `<col min="${i + 1}" max="${i + 1}" width="${(sh.widths && sh.widths[i]) || (i === 0 ? 24 : 12)}" customWidth="1"/>`).join('')}</cols><sheetData>`
    + sh.rows.map((r, ri) => `<row r="${ri + 1}">${r.map((v, ci) => { const ref = colName(ci) + (ri + 1); const st = ri === 0 ? ' s="1"' : ''; return typeof v === 'number' && isFinite(v) ? `<c r="${ref}"${st}><v>${v}</v></c>` : v == null || v === '' ? '' : `<c r="${ref}" t="inlineStr"${st}><is><t xml:space="preserve">${xmlEsc(v)}</t></is></c>`; }).join('')}</row>`).join('')
    + `</sheetData></worksheet>`;
  const files = [
    { name: '[Content_Types].xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>` },
    { name: '_rels/.rels', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
    { name: 'xl/workbook.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.map((s, i) => `<sheet name="${safe(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>` },
    { name: 'xl/_rels/workbook.xml.rels', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
    { name: 'xl/styles.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFECEDFB"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="2"><xf/><xf fontId="1" fillId="2" applyFont="1" applyFill="1"/></cellXfs></styleSheet>` },
    ...sheets.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: sheetXml(s) })),
  ];
  return zipStore(files);
}
async function deliverFile(blob, filename, title) {
  const file = new File([blob], filename, { type: blob.type });
  if (navigator.canShare && /Android|iPhone|iPad/i.test(navigator.userAgent) && navigator.canShare({ files: [file] })) {
    try { await navigator.share({ files: [file], title }); return; } catch (e) { if (e && e.name === 'AbortError') return; }
  }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
  toast(L('Downloaded', 'डाउनलोड हो गया') + ': ' + filename);
}
function printHTML(title, html) {
  const w = document.getElementById('print-root');
  w.innerHTML = `<div class="print-doc"><h2>${esc(SCHOOL.name)}, ${esc(SCHOOL.place)}</h2><h3>${esc(title)}</h3>${html}<p class="print-foot">${esc(L('Printed', 'मुद्रित'))}: ${fmtTime(nowStamp())}</p></div>`;
  try { window.print(); } catch (e) { toast(L('Printing is not available here', 'यहाँ प्रिंट उपलब्ध नहीं')); }
}
const rowsToTable = rows => `<table class="print-table"><thead><tr>${rows[0].map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead><tbody>${rows.slice(1).map(r => `<tr>${r.map(v => `<td>${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;

function attendanceSheets(ym) {
  const [y, m] = ym.split('-').map(Number);
  const last = new Date(y, m, 0).getDate();
  const days = Array.from({ length: last }, (_, i) => `${ym}-${pad(i + 1)}`);
  const people = S.staff.filter(s => s.active && s.role !== 'admin');
  const sym = { present: 'P', late: 'L', absent: 'A', leave: 'LV', review: '?', rejected: 'A' };
  const summary = [[L('Staff', 'स्टाफ़'), L('Working days', 'कार्य दिवस'), attLabel('present'), attLabel('late'), attLabel('absent'), attLabel('leave'), L('Attendance %', 'हाज़िरी %')]];
  people.forEach(p => { const s = monthStats(p.id, ym); summary.push([p.name, s.days, s.present, s.late, s.absent, s.leave, s.days ? Math.round(((s.present + s.late) / Math.max(1, s.days - s.leave)) * 100) : '']); });
  const grid = [[L('Staff', 'स्टाफ़'), ...days.map(d => Number(d.slice(8)))]];
  people.forEach(p => grid.push([p.name, ...days.map(d => (d > todayISO() || dayIdx(d) < 0 ? (dayIdx(d) < 0 ? 'Sun' : '') : sym[attStatus(p.id, d)] || ''))]));
  const times = [[L('Date', 'तारीख़'), L('Staff', 'स्टाफ़'), t('status'), L('In', 'आए'), L('Out', 'गए'), L('Warnings', 'चेतावनी'), L('Marked by', 'किसने')]];
  S.attendance.filter(a => a.date.startsWith(ym)).sort((a, b) => a.date.localeCompare(b.date) || nameOf(a.teacherId).localeCompare(nameOf(b.teacherId)))
    .forEach(a => times.push([a.date, nameOf(a.teacherId), attLabel(a.status), a.in && a.in.at ? fmtClock(a.in.at) : '', a.out ? fmtClock(a.out.at) : '', (a.flags || []).map(flagText).join(', '), a.source === 'office' ? L('Office', 'ऑफ़िस') + (a.by ? ' (' + nameOf(a.by) + ')' : '') : L('Self (app)', 'स्वयं (ऐप)')]));
  return [{ name: L('Summary', 'सारांश'), rows: summary, widths: [26, 12, 10, 10, 10, 10, 13] }, { name: L('Register', 'रजिस्टर'), rows: grid, widths: [26, ...days.map(() => 4)] }, { name: L('Check-in times', 'चेक-इन समय'), rows: times, widths: [12, 26, 14, 8, 8, 30, 18] }];
}
function workloadSheet(ym) {
  const rows = [[t('teacher'), L('Periods / week', 'पीरियड / सप्ताह'), L('Substitutions this month', 'इस माह अरेंजमेंट'), L('Leave days', 'छुट्टी दिन')]];
  teachers().forEach(tc => rows.push([tc.name, weeklyLoad(tc.id), monthSubs(tc.id, ym), monthLeaveDays(tc.id, ym)]));
  return { name: L('Workload', 'कार्यभार'), rows, widths: [26, 16, 22, 12] };
}
function leaveSheets() {
  const pol = leavePolicy(); const types = LEAVE_TYPES.filter(tp => Number(pol[tp]) > 0); const yr = leaveYear();
  const bal = [[t('teacher'), ...types.map(tp => `${tp} (${pol[tp]})`)]];
  teachers().forEach(tc => { const b = leaveBalance(tc.id); bal.push([tc.name, ...types.map(tp => b.find(x => x.type === tp).left)]); });
  const reg = [[t('teacher'), t('from'), t('to'), t('type'), t('duration'), L('Days', 'दिन'), t('status'), t('description'), t('remark')]];
  S.leaves.filter(l => l.from >= yr.from && l.from <= yr.to).sort((a, b) => a.from.localeCompare(b.from)).forEach(l => reg.push([nameOf(l.teacherId), l.from, l.to, l.type, absenceLabel(l), leaveUnits(l), t(l.status), l.description || '', l.remark || '']));
  return [{ name: L('Leave balance', 'शेष छुट्टी'), rows: bal, widths: [26, ...types.map(() => 14)] }, { name: L('Leave register', 'छुट्टी रजिस्टर'), rows: reg, widths: [24, 11, 11, 12, 14, 6, 10, 40, 30] }];
}
function syllabusSheet() {
  const rows = [[t('class'), t('subject'), t('teacher'), L('Chapters', 'अध्याय'), L('Done', 'पूरे'), '%', L('Last finished', 'अंतिम पूरा')]];
  allPairs().sort((a, b) => CLASSES.indexOf(a.cls) - CLASSES.indexOf(b.cls) || a.subject.localeCompare(b.subject)).forEach(p => {
    const r = syRow(p.cls, p.subject); const done = r ? r.chapters.filter(c => c.done) : [];
    rows.push([p.cls, subjName(p.subject), nameOf(r ? r.teacherId : [...p.teachers][0]), r ? r.chapters.length : 0, done.length, syPct(r), done.length ? done[done.length - 1].name : '']);
  });
  return { name: L('Syllabus', 'पाठ्यक्रम'), rows, widths: [14, 18, 24, 10, 8, 6, 30] };
}
function examSheet(e) {
  const rows = [[t('date'), L('Session', 'सत्र'), L('Time', 'समय'), L('Room', 'कक्ष'), L('Invigilator(s)', 'निरीक्षक')]];
  e.days.forEach(d => e.sessions.forEach(se => e.rooms.forEach(room => rows.push([d, se.label, se.time, room, ((e.duties || {})[dutyKey(d, se.id, room)] || []).map(nameOf).join(', ')]))));
  return { name: e.name, rows, widths: [12, 12, 14, 14, 36] };
}

/* =================================================================
   8. DARK MODE, OFFLINE COPY, SERVICE WORKER, VOICE
   ================================================================= */
function applyTheme() {
  let pref = 'auto'; try { pref = localStorage.getItem('mts-theme') || 'auto'; } catch (e) { }
  const dark = pref === 'dark' || (pref === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const meta = document.querySelector('meta[name="theme-color"]'); if (meta) meta.content = dark ? '#14152b' : '#2f3192';
}
function cycleTheme() {
  let pref = 'auto'; try { pref = localStorage.getItem('mts-theme') || 'auto'; } catch (e) { }
  const next = { auto: 'dark', dark: 'light', light: 'auto' }[pref];
  try { localStorage.setItem('mts-theme', next); } catch (e) { }
  applyTheme(); render();
  toast({ auto: L('Theme: follows phone', 'थीम: फ़ोन के अनुसार'), dark: L('Theme: dark', 'थीम: डार्क'), light: L('Theme: light', 'थीम: लाइट') }[next]);
}
const themeIcon = () => { let p = 'auto'; try { p = localStorage.getItem('mts-theme') || 'auto'; } catch (e) { } return { auto: '🌓', dark: '🌙', light: '☀️' }[p]; };
try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme); } catch (e) { }
applyTheme();

const CACHE_KEY = 'mts-offline-v2';
function saveOfflineCopy() {
  try {
    const u = me(); if (!u) return;
    const snap = { at: nowStamp(), userId: u.id, staff: S.staff, tt: S.tt, classTeachers: S.classTeachers, absences: S.absences.filter(a => a.date >= addDays(todayISO(), -7)), leaves: S.leaves.filter(l => l.teacherId === u.id || isManager(u)), plans: Object.fromEntries(Object.entries(S.plans).filter(([d]) => d >= addDays(todayISO(), -2))), notices: S.notices.slice(0, 30), acks: S.acks, customSubjects: S.customSubjects, config: S.config, exams: S.exams, syllabus: S.syllabus, attendance: S.attendance.filter(a => a.teacherId === u.id || isManager(u)).filter(a => a.date >= addDays(todayISO(), -35)) };
    localStorage.setItem(CACHE_KEY, JSON.stringify(snap));
  } catch (e) { }
}
function loadOfflineCopy() {
  try {
    const snap = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null');
    if (!snap || !snap.userId) return false;
    const fresh = emptyState(); fresh.lang = S.lang; S = fresh;
    Object.assign(S, { staff: snap.staff || [], tt: snap.tt || {}, classTeachers: snap.classTeachers || {}, absences: snap.absences || [], leaves: snap.leaves || [], plans: snap.plans || {}, notices: snap.notices || [], acks: snap.acks || {}, customSubjects: snap.customSubjects || {}, config: snap.config || {}, exams: snap.exams || [], syllabus: snap.syllabus || [], attendance: snap.attendance || [] });
    Object.assign(SUBJECTS, S.customSubjects);
    sortStaff(); syncClasses();
    S.session = { userId: snap.userId }; S.offline = snap.at;
    return !!me();
  } catch (e) { return false; }
}
function registerSW() {
  if (!('serviceWorker' in navigator) || location.protocol !== 'https:') return;
  navigator.serviceWorker.register('sw.js').catch(() => { });
}

/* voice: speak a question, hear the answer (Chrome on Android supports Hindi and English) */
const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
function startVoice() {
  if (!SpeechRec) { toast(L('Voice input is not supported in this browser. Use Chrome.', 'इस ब्राउज़र में आवाज़ से पूछना उपलब्ध नहीं। Chrome उपयोग करें।')); return; }
  if (V2.listening) { try { V2.rec && V2.rec.stop(); } catch (e) { } return; }
  const rec = new SpeechRec(); V2.rec = rec;
  rec.lang = S.lang === 'hi' ? 'hi-IN' : 'en-IN'; rec.interimResults = true; rec.maxAlternatives = 1;
  const input = document.querySelector('.chat-in input, .quickask input');
  rec.onresult = ev => { const txt = Array.from(ev.results).map(r => r[0].transcript).join(' '); if (input) input.value = txt; if (ev.results[ev.results.length - 1].isFinal && txt.trim()) { V2.voiceAsked = true; rec.stop(); if (UI.view !== 'assistant') { go('assistant'); } askAssistant(txt.trim()); } };
  rec.onend = () => { V2.listening = false; const b = document.querySelector('.mic'); if (b) b.classList.remove('on'); };
  rec.onerror = ev => { V2.listening = false; if (ev.error === 'not-allowed') toast(L('Microphone permission refused', 'माइक्रोफ़ोन की अनुमति नहीं मिली')); };
  V2.listening = true; const b = document.querySelector('.mic'); if (b) b.classList.add('on');
  try { rec.start(); } catch (e) { V2.listening = false; }
}
function speak(text) {
  if (!V2.voiceOn || !('speechSynthesis' in window)) return;
  const plain = String(text).replace(/\|[-|: ]+\|/g, ' ').replace(/[*#|_`>]/g, ' ').replace(/\s+/g, ' ').slice(0, 600);
  try { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(plain); u.lang = S.lang === 'hi' ? 'hi-IN' : 'en-IN'; u.rate = 1; speechSynthesis.speak(u); } catch (e) { }
}

/* =================================================================
   9. TIMETABLE: swap two periods
   ================================================================= */
function swapCheck(cls, a, b) {
  // a, b: {d, p}. After swapping, every teacher of A must be free at B (outside this class) and vice versa.
  const la = lessonAt(cls, a.d, a.p), lb = lessonAt(cls, b.d, b.p);
  const busyElsewhere = (tid, d, p) => CLASSES.find(c => c !== cls && partsOf(lessonAt(c, d, p)).some(g => g.t === tid));
  for (const g of partsOf(la)) { const c = busyElsewhere(g.t, b.d, b.p); if (c && !(la.j && (lessonAt(c, b.d, b.p) || {}).j)) return L(`${nameOf(g.t)} is busy in ${c} at ${dayName(b.d)} P${b.p}.`, `${nameOf(g.t)} ${dayName(b.d)} P${b.p} में ${c} में व्यस्त हैं।`); }
  for (const g of partsOf(lb)) { const c = busyElsewhere(g.t, a.d, a.p); if (c && !(lb.j && (lessonAt(c, a.d, a.p) || {}).j)) return L(`${nameOf(g.t)} is busy in ${c} at ${dayName(a.d)} P${a.p}.`, `${nameOf(g.t)} ${dayName(a.d)} P${a.p} में ${c} में व्यस्त हैं।`); }
  return null;
}

/* =================================================================
   10. SETTINGS PANELS (attendance timings, leave policy)
   ================================================================= */
function settingsV2HTML() {
  const c = campusCfg(), pol = leavePolicy();
  return holidaysPanelHTML() + `<section class="panel"><h3>✅ ${L('Attendance timings', 'हाज़िरी का समय')}</h3>
    ${S.v2Missing ? `<div class="banner bad">${checkErr('setup')}</div>` : ''}
    <form data-form="attTimes" class="stack">
      <div class="three"><label>${L('Check-in opens', 'चेक-इन शुरू')}<input type="time" name="open" value="${c.open}"></label><label>${L('Late after', 'इसके बाद देर')}<input type="time" name="late" value="${c.late}"></label><label>${L('Check-in closes', 'चेक-इन बंद')}<input type="time" name="close" value="${c.close}"></label></div>
      <div class="three"><label>${L('Check-out from', 'चेक-आउट से')}<input type="time" name="outFrom" value="${c.outFrom}"></label></div>
      <p class="hint">${L('Times are checked on the school server, so a wrong clock on a phone makes no difference.', 'समय स्कूल सर्वर पर जाँचा जाता है, इसलिए फ़ोन की गलत घड़ी से कोई फ़र्क नहीं पड़ता।')}</p>
      <div class="row-end"><button class="btn primary">${t('save')}</button></div></form></section>
    <section class="panel"><h3>📝 ${L('Leave allowed per year', 'प्रति वर्ष अनुमत छुट्टी')}</h3>
      <form data-form="leavePolicy" class="stack"><div class="three">${LEAVE_TYPES.map(tp => `<label>${esc(leaveTypeName(tp))}<input type="number" name="${esc(tp)}" min="0" max="365" value="${pol[tp] || 0}"></label>`).join('')}
        <label>${L('Leave year starts in', 'छुट्टी वर्ष शुरू')}<select name="yearStart">${Array.from({ length: 12 }, (_, i) => `<option value="${i + 1}" ${Number(pol.yearStart) === i + 1 ? 'selected' : ''}>${new Date(2026, i, 1).toLocaleDateString(S.lang === 'hi' ? 'hi-IN' : 'en-IN', { month: 'long' })}</option>`).join('')}</select></label></div>
      <p class="hint">${L('0 = no limit is tracked for that type.', '0 = उस प्रकार की सीमा नहीं गिनी जाती।')}</p>
      <div class="row-end"><button class="btn primary">${t('save')}</button></div></form></section>
    ${(() => { const r = salaryRules(); return `<section class="panel"><h3>💼 ${L('Salary sheet rules', 'वेतन शीट नियम')}</h3>
      <form data-form="salaryRules" class="stack"><div class="three">
        <label>${L('Late marks for one cut', 'कितनी देर पर कटौती')}<input type="number" name="lateCount" min="0" max="31" value="${r.lateCount}"></label>
        <label>${L('Cut for those late marks', 'उतनी देर पर कटौती')}<select name="lateCut">${[[0.25, L('Quarter day', 'चौथाई दिन')], [0.5, L('Half day', 'आधा दिन')], [1, L('Full day', 'पूरा दिन')]].map(([v, l]) => `<option value="${v}" ${r.lateCut === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
        <label>${L('Check-ins waiting for approval count as', 'स्वीकृति बाकी चेक-इन गिनें')}<select name="pendingAs"><option value="present" ${r.pendingAs === 'present' ? 'selected' : ''}>${attLabel('present')}</option><option value="absent" ${r.pendingAs === 'absent' ? 'selected' : ''}>${attLabel('absent')}</option></select></label></div>
      <p class="hint">${L('0 late marks = no cut for being late. The sheet shows days only, not money.', '0 = देर पर कोई कटौती नहीं। शीट में केवल दिन हैं, राशि नहीं।')}</p>
      <div class="row-end"><button class="btn primary">${t('save')}</button></div></form></section>`; })()}`;
}

/* =================================================================
   11. ACTIONS / CHANGES / FORMS for the new features
   ================================================================= */
Object.assign(ACTIONS, {
  checkIn: () => doCheck('in'),
  checkOut: () => doCheck('out'),
  attTab: el => { V2.attTab = el.dataset.tab; if (V2.attTab === 'attempts') V2.attempts = null; if (V2.attTab === 'month') ensureMonthLoaded(UI.reportMonth || todayISO().slice(0, 7)); render(); },
  attShift: el => { V2.attDate = addDays(V2.attDate || todayISO(), Number(el.dataset.n)); render(); },
  attemptsReload: () => { V2.attempts = null; render(); },
  attApprove: el => {
    const a = S.attendance.find(x => x.id === el.dataset.id); if (!a) return;
    a.status = a.in && a.in.at && fmtClock(a.in.at) > campusCfg().late ? 'late' : 'present'; a.decidedBy = me().id; a.decidedAt = nowStamp();
    notify(a.teacherId, '', { en: `Your check-in on ${fmtDate(a.date)} was approved.`, hi: `${fmtDate(a.date)} का आपका चेक-इन स्वीकृत हुआ।` });
    logAudit(me().id, `Approved check-in of ${nameOf(a.teacherId)} on ${a.date}`); commit();
  },
  attReject: el => {
    const a = S.attendance.find(x => x.id === el.dataset.id); if (!a) return;
    confirmBox(L(`Refuse ${nameOf(a.teacherId)}'s check-in on ${fmtDate(a.date)}? The day counts as absent.`, `${fmtDate(a.date)} को ${nameOf(a.teacherId)} का चेक-इन अस्वीकार करें? दिन अनुपस्थित गिना जाएगा।`), () => {
      a.status = 'rejected'; a.decidedBy = me().id; a.decidedAt = nowStamp();
      notify(a.teacherId, '', { en: `Your check-in on ${fmtDate(a.date)} was refused by the office.`, hi: `${fmtDate(a.date)} का आपका चेक-इन ऑफ़िस ने अस्वीकार किया।` });
      logAudit(me().id, `Refused check-in of ${nameOf(a.teacherId)} on ${a.date}`); commit();
    }, t('reject'));
  },
  attOffice: el => {
    const tid = el.dataset.tid, date = V2.attDate || todayISO();
    const ex = attOf(tid, date);
    const rec = { id: attId(tid, date), teacherId: tid, date, status: el.dataset.st, source: 'office', by: me().id, flags: [], in: { at: `${date}T${nowHM()}:00` }, markedAt: nowStamp() };
    if (ex) Object.assign(ex, rec); else S.attendance.unshift(rec);
    logAudit(me().id, `Marked ${nameOf(tid)} ${el.dataset.st} on ${date} (office)`); commit();
  },
  attAbsent: el => {
    const tid = el.dataset.tid, date = V2.attDate || todayISO();
    confirmBox(L(`Mark ${nameOf(tid)} absent on ${fmtDate(date)} and plan substitutes for their periods?`, `${fmtDate(date)} को ${nameOf(tid)} को अनुपस्थित करें और उनके पीरियड का अरेंजमेंट बनाएँ?`), () => {
      const ex = attOf(tid, date);
      const rec = { id: attId(tid, date), teacherId: tid, date, status: 'absent', source: 'office', by: me().id, flags: [], markedAt: nowStamp() };
      if (ex) Object.assign(ex, rec); else S.attendance.unshift(rec);
      addAbsence(tid, date, 'full', [], L('Not checked in', 'चेक-इन नहीं'), me().id);
      commit(); toast(L('Marked absent — substitutes drafted', 'अनुपस्थित — अरेंजमेंट बना'));
    }, L('Mark absent', 'अनुपस्थित करें'));
  },
  attClear: el => { S.attendance = S.attendance.filter(a => a.id !== el.dataset.id); logAudit(me().id, 'Removed an office attendance mark'); commit(); },
  exportAttendance: () => { const ym = UI.reportMonth || todayISO().slice(0, 7); deliverFile(makeXlsx(attendanceSheets(ym)), `MTS-staff-attendance-${ym}.xlsx`, L('Staff attendance', 'स्टाफ़ हाज़िरी') + ' ' + ym); },
  printAttendance: () => { const ym = UI.reportMonth || todayISO().slice(0, 7); const sh = attendanceSheets(ym); printHTML(L('Staff attendance', 'स्टाफ़ हाज़िरी') + ' — ' + ym, rowsToTable(sh[0].rows) + '<br>' + rowsToTable(sh[1].rows)); },
  exportAll: () => { const ym = UI.reportMonth || todayISO().slice(0, 7); deliverFile(makeXlsx([...attendanceSheets(ym), workloadSheet(ym), ...leaveSheets(), syllabusSheet()]), `MTS-report-${ym}.xlsx`, `MTS report ${ym}`); },
  printReport: () => { const ym = UI.reportMonth || todayISO().slice(0, 7); printHTML(L('Monthly report', 'मासिक रिपोर्ट') + ' — ' + ym, `<h4>${L('Attendance', 'हाज़िरी')}</h4>${rowsToTable(attendanceSheets(ym)[0].rows)}<h4>${L('Workload', 'कार्यभार')}</h4>${rowsToTable(workloadSheet(ym).rows)}<h4>${L('Leave left', 'शेष छुट्टी')}</h4>${rowsToTable(leaveSheets()[0].rows)}`); },
  exportSyllabus: () => deliverFile(makeXlsx([syllabusSheet()]), `MTS-syllabus-${todayISO()}.xlsx`, 'Syllabus'),
  leaveCal: el => { V2.leaveCal = el.dataset.ym; render(); },
  syOpen: el => openModal(`${el.dataset.cls} · ${subjName(el.dataset.subj)}`, syEditorHTML(el.dataset.cls, el.dataset.subj), { wide: true }),
  syTab: el => { V2.syTab = el.dataset.tab || null; render(); },
  syDel: el => { syUpsert(el.dataset.cls, el.dataset.subj, r => { r.chapters = r.chapters.filter(c => c.id !== el.dataset.ch); }); queueFlush(); openModal(`${el.dataset.cls} · ${subjName(el.dataset.subj)}`, syEditorHTML(el.dataset.cls, el.dataset.subj), { wide: true }); },
  examNew: () => openModal(L('New exam', 'नई परीक्षा'), examFormHTML(), { wide: true }),
  examOpen: el => { V2.examId = el.dataset.id; render(); },
  examBack: () => { V2.examId = null; render(); },
  examDel: el => { const e = examById(el.dataset.id); confirmBox(L(`Delete ${e.name}?`, `${e.name} हटाएँ?`), () => { S.exams = S.exams.filter(x => x.id !== e.id); logAudit(me().id, `Deleted exam ${e.name}`); commit(); }, L('Delete', 'हटाएँ')); },
  examAuto: el => { const e = examById(el.dataset.id); const doIt = () => { autoAssign(e); e.updatedAt = nowStamp(); logAudit(me().id, `Shared duties for ${e.name}`); commit(); toast(L('Duties shared fairly', 'ड्यूटी बराबर बाँटी गई')); }; if (Object.values(e.duties || {}).some(x => x.length)) confirmBox(L('Replace the current duties?', 'मौजूदा ड्यूटी बदलें?'), doIt, L('Replace', 'बदलें')); else doIt(); },
  examPublish: el => {
    const e = examById(el.dataset.id); e.published = true; e.publishedAt = nowStamp();
    const who = new Set(); Object.values(e.duties || {}).forEach(ids => ids.forEach(id => who.add(id)));
    who.forEach(id => { const n = Object.values(e.duties).filter(ids => ids.includes(id)).length; notify(id, '', { en: `${e.name}: you have ${n} exam duty(ies). See Exam duties.`, hi: `${e.name}: आपकी ${n} परीक्षा ड्यूटी हैं। परीक्षा ड्यूटी देखें।` }); });
    logAudit(me().id, `Published exam duties for ${e.name}`); commit(); toast(L('Published — teachers notified', 'प्रकाशित — शिक्षकों को सूचना भेजी'));
  },
  examPrint: el => { const e = examById(el.dataset.id); printHTML(e.name + ' — ' + L('Invigilation chart', 'निरीक्षण चार्ट'), rowsToTable(examSheet(e).rows)); },
  examExport: el => { const e = examById(el.dataset.id); deliverFile(makeXlsx([examSheet(e)]), `MTS-${e.name.replace(/\s+/g, '-')}-duties.xlsx`, e.name); },
  noticeReaders: el => { const list = readersOf(el.dataset.id); openModal(L('Who has read it', 'किसने पढ़ा'), `<div class="two-col"><div><h4>✓ ${L('Read', 'पढ़ा')} (${list.filter(x => x.read).length})</h4><ul class="plain">${list.filter(x => x.read).map(x => `<li>${esc(x.s.name)}</li>`).join('') || '<li class="muted">—</li>'}</ul></div><div><h4>${L('Not yet', 'अभी नहीं')} (${list.filter(x => !x.read).length})</h4><ul class="plain">${list.filter(x => !x.read).map(x => `<li>${esc(x.s.name)}</li>`).join('') || '<li class="muted">—</li>'}</ul></div></div><div class="row-end"><button class="btn" data-act="closeModal">${t('close')}</button></div>`); },
  enableNotif: async () => { if (!notifSupported()) { toast(L('Notifications are not supported here', 'यहाँ सूचनाएँ उपलब्ध नहीं')); return; } const p = await Notification.requestPermission(); render(); if (p === 'granted') { sysNotify(SCHOOL.short, L('Notifications are on. You will get period reminders and new arrangements while the app is open.', 'सूचनाएँ चालू हैं। ऐप खुला रहने पर पीरियड रिमाइंडर और नए अरेंजमेंट मिलेंगे।'), 'hello'); } },
  cycleTheme: () => cycleTheme(),
  voice: () => startVoice(),
  voiceToggle: () => { V2.voiceOn = !V2.voiceOn; if (!V2.voiceOn && 'speechSynthesis' in window) speechSynthesis.cancel(); render(); },
  swapMode: () => { V2.swapFrom = V2.swapFrom === undefined || V2.swapFrom === null ? 'on' : null; render(); },
  swapPick: el => {
    const d = Number(el.dataset.d), p = Number(el.dataset.p);
    if (V2.swapFrom === 'on') { V2.swapFrom = { d, p }; render(); return; }
    const a = V2.swapFrom; if (!a || (a.d === d && a.p === p)) { V2.swapFrom = 'on'; render(); return; }
    const cls = UI.ttClass; const err = swapCheck(cls, a, { d, p });
    if (err) { toast('⛔ ' + err); V2.swapFrom = 'on'; render(); return; }
    const la = S.tt[cls][a.d][a.p - 1], lb = S.tt[cls][d][p - 1];
    S.tt[cls][a.d][a.p - 1] = lb; S.tt[cls][d][p - 1] = la;
    const ids = new Set([...partsOf(la), ...partsOf(lb)].map(g => g.t));
    ids.forEach(tid => notify(tid, '', { en: `Timetable changed: ${cls} ${DAYS[a.d]} P${a.p} ⇄ ${DAYS[d]} P${p}`, hi: `समय-सारणी बदली: ${cls} ${DAYS_HI[a.d]} P${a.p} ⇄ ${DAYS_HI[d]} P${p}` }));
    logAudit(me().id, `Swapped ${cls} ${DAYS[a.d]} P${a.p} with ${DAYS[d]} P${p}`);
    V2.swapFrom = 'on'; commit(); toast(L('Periods swapped', 'पीरियड बदले गए'));
  },
});
Object.assign(CHANGES, {
  attDate: el => { if (el.value) { V2.attDate = el.value; render(); } },
  syTick: el => {
    const { cls, subj, ch } = el.dataset;
    syUpsert(cls, subj, r => { const c = r.chapters.find(x => x.id === ch); if (c) { c.done = el.checked; c.doneOn = el.checked ? todayISO() : null; } });
    logAudit(me().id, `Syllabus ${cls} ${subj}: ${el.checked ? 'finished' : 'reopened'} a chapter`);
    queueFlush(); const li = el.closest('li'); if (li) li.classList.toggle('done', el.checked);
  },
  examSet: el => {
    const e = examById(el.dataset.id); const k = el.dataset.key; const i = Number(el.dataset.i);
    e.duties = e.duties || {};
    if (el.value) {
      const sessKey = k.split('|').slice(0, 2).join('|') + '|';
      const other = Object.entries(e.duties).find(([kk, xs]) => xs.some((x, j) => x === el.value && !(kk === k && j === i)) && kk.startsWith(sessKey));
      if (other) { toast('⛔ ' + L(`${nameOf(el.value)} already has duty in ${other[0].split('|')[2]} at this time.`, `${nameOf(el.value)} की इसी समय ${other[0].split('|')[2]} में ड्यूटी है।`)); render(); return; }
    }
    const ids = (e.duties[k] || []).slice(); ids[i] = el.value; e.duties[k] = ids.filter(Boolean);
    e.updatedAt = nowStamp(); commit();
  },
});
Object.assign(FORMS, {
  attTimes: fd => {
    const v = k => String(fd.get(k) || '');
    const c = { open: v('open') || '07:00', late: v('late') || '09:00', close: v('close') || '12:00', outFrom: v('outFrom') || '13:30' };
    if (!(c.open <= c.late && c.late <= c.close && c.close <= c.outFrom)) { toast(L('Times must be in order: opens ≤ late ≤ closes ≤ check-out.', 'समय क्रम में हो: शुरू ≤ देर ≤ बंद ≤ चेक-आउट।')); return; }
    S.config.attendance = { ...c, since: ((S.config.attendance || {}).since) || attSince(), by: me().id, at: nowStamp() };
    logAudit(me().id, `Set attendance timings (${c.open}–${c.close}, late after ${c.late})`); commit(); toast(L('Saved', 'सहेजा गया'));
  },
  leavePolicy: fd => {
    const pol = { yearStart: Number(fd.get('yearStart')) || 4 };
    LEAVE_TYPES.forEach(tp => { pol[tp] = Math.max(0, Number(fd.get(tp)) || 0); });
    S.config.leavePolicy = pol; logAudit(me().id, 'Changed leave allowance'); commit(); toast(L('Saved', 'सहेजा गया'));
  },
  syAdd: (fd, form) => {
    const { cls, subj } = form.dataset;
    const names = String(fd.get('names') || '').split('\n').map(s => s.replace(/^\s*\d+[.)]\s*/, '').trim()).filter(Boolean).slice(0, 60);
    if (!names.length) return;
    syUpsert(cls, subj, r => names.forEach(n => r.chapters.push({ id: uid('ch'), name: n.slice(0, 120), done: false })));
    logAudit(me().id, `Syllabus ${cls} ${subj}: added ${names.length} chapter(s)`); queueFlush();
    openModal(`${cls} · ${subjName(subj)}`, syEditorHTML(cls, subj), { wide: true });
  },
  exam: fd => {
    const from = fd.get('from'), to = fd.get('to');
    if (to < from) { toast(L('The end date is before the start date.', 'अंतिम तारीख़ शुरू से पहले है।')); return; }
    const sessions = String(fd.get('sessions') || '').split('\n').map(s => s.trim()).filter(Boolean).map((s, i) => { const [label, ...rest] = s.split(','); return { id: 's' + (i + 1), label: label.trim(), time: rest.join(',').trim() }; });
    const e = { id: uid('ex'), name: String(fd.get('name')).trim(), days: workDaysBetween(from, to), sessions: sessions.length ? sessions : [{ id: 's1', label: 'Exam', time: '' }], rooms: fd.getAll('rooms'), perRoom: Math.max(1, Math.min(3, Number(fd.get('perRoom')) || 1)), duties: {}, published: false, createdAt: nowStamp(), by: me().id };
    if (!e.days.length || !e.rooms.length) { toast(L('Choose dates and at least one room.', 'तारीख़ें और कम से कम एक कक्ष चुनें।')); return; }
    autoAssign(e); S.exams.push(e); V2.examId = e.id; closeModal();
    logAudit(me().id, `Created exam ${e.name}`); commit(); toast(L('Exam created and duties shared — check and publish', 'परीक्षा बनी और ड्यूटी बँटी — जाँचकर प्रकाशित करें'));
  },
});


/* =================================================================
   12. SALARY-READY ATTENDANCE SHEET (days only — no amounts)
   ================================================================= */
const DEFAULT_SALARY_RULES = { lateCount: 3, lateCut: 0.5, pendingAs: 'present' };
const salaryRules = () => ({ ...DEFAULT_SALARY_RULES, ...((S.config && S.config.salaryRules) || {}) });
/* For one person: every approved leave day in the leave year, in date order, marked paid or unpaid
   (paid while the yearly allowance for that type lasts; 0 allowance = not limited; Official duty is always paid). */
function leaveDayMap(tid, ym) {
  const pol = leavePolicy(); const yr = leaveYear(ym + '-01');
  const used = {}; const map = {};
  S.leaves.filter(l => l.teacherId === tid && l.status === 'approved' && l.to >= yr.from && l.from <= yr.to)
    .sort((a, b) => a.from.localeCompare(b.from))
    .forEach(l => workDaysBetween(l.from < yr.from ? yr.from : l.from, l.to).forEach(d => {
      const unit = l.scope === 'full' ? 1 : 0.5;
      const allow = Number(pol[l.type]) || 0;
      used[l.type] = (used[l.type] || 0) + unit;
      const unlimited = l.type === 'Official duty' || allow <= 0;
      const over = unlimited ? 0 : Math.min(unit, Math.max(0, used[l.type] - allow));
      const prev = map[d] || { paid: 0, unpaid: 0, types: [] };
      map[d] = { paid: prev.paid + unit - over, unpaid: prev.unpaid + over, types: prev.types.concat(l.type), duty: prev.duty || l.type === 'Official duty' };
    }));
  return map;
}
/* one row of numbers for one person and month (counts up to today for the current month) */
function salaryRow(p, ym) {
  const rules = salaryRules();
  const [y, m] = ym.split('-').map(Number);
  const daysInMonth = new Date(y, m, 0).getDate();
  const lm = leaveDayMap(p.id, ym);
  const r = { daysInMonth, sundays: 0, holidays: 0, working: 0, counted: 0, present: 0, late: 0, duty: 0, paidLeave: 0, unpaidLeave: 0, absent: 0, pending: 0, before: 0, notes: [] };
  for (let d = 1; d <= daysInMonth; d++) {
    const iso = `${ym}-${pad(d)}`;
    if (dayIdx(iso) < 0) { if (holidayName(iso)) r.holidays++; else r.sundays++; continue; }
    r.working++;
    if (iso > todayISO()) continue;
    r.counted++;
    const st = attStatus(p.id, iso);
    const lv = lm[iso];
    if (st === 'untracked') { r.before++; continue; }
    if (st === 'present' || st === 'late') {
      if (st === 'late') r.late++; else r.present++;
      if (lv) { r.paidLeave += lv.paid; r.unpaidLeave += lv.unpaid; } // half-day leave on a day they also came
      continue;
    }
    if (st === 'review') { r.pending++; if (rules.pendingAs === 'present') r.present++; else r.absent++; continue; }
    if (st === 'leave') {
      if (lv) { if (lv.duty) r.duty += lv.paid; else r.paidLeave += lv.paid; r.unpaidLeave += lv.unpaid; if (lv.paid + lv.unpaid < 1) r.absent += 1 - (lv.paid + lv.unpaid); }
      else r.absent++; // marked absent by the office without a leave application
      continue;
    }
    if (st === 'absent' || st === 'rejected') { r.absent++; continue; }
    if (st === 'not_in') { r.counted--; continue; } // today, before closing time
  }
  r.lateCut = rules.lateCount > 0 ? Math.floor(r.late / rules.lateCount) * rules.lateCut : 0;
  r.lwp = r.absent + r.unpaidLeave + r.lateCut;
  r.payableFull = Math.max(0, daysInMonth - r.lwp);
  if (r.pending) r.notes.push(L(`${r.pending} check-in(s) waiting for approval`, `${r.pending} चेक-इन स्वीकृति बाकी`));
  if (r.before) r.notes.push(L(`${r.before} day(s) before attendance started, counted as present`, `${r.before} दिन हाज़िरी शुरू होने से पहले, उपस्थित गिने`));
  if (r.unpaidLeave) r.notes.push(L('leave beyond the yearly allowance', 'वार्षिक सीमा से अधिक छुट्टी'));
  return r;
}
const salaryPeople = () => S.staff.filter(s => s.active && s.role !== 'admin').slice().sort((a, b) => a.name.localeCompare(b.name));
function salarySheets(ym) {
  const rules = salaryRules();
  const monthDone = ym < todayISO().slice(0, 7);
  const head = [L('S.No.', 'क्र.'), L('Staff', 'स्टाफ़'), L('Role', 'पद'), L('Days in month', 'माह के दिन'), L('Sundays', 'रविवार'), L('Holidays', 'अवकाश'), L('Working days', 'कार्य दिवस'),
    L('Present (on time)', 'उपस्थित (समय पर)'), L('Late', 'देर से'), L('Official duty', 'विद्यालय कार्य'), L('Paid leave', 'सवेतन छुट्टी'), L('Absent', 'अनुपस्थित'), L('Unpaid leave', 'अवैतनिक छुट्टी'),
    L(`Late cut (${rules.lateCount} late = ${rules.lateCut} day)`, `देर कटौती (${rules.lateCount} देर = ${rules.lateCut} दिन)`), L('Total days cut (LWP)', 'कुल कटौती दिन (LWP)'), L('Payable days', 'देय दिन'), L('Remarks', 'टिप्पणी')];
  const rows = [head];
  const people = salaryPeople();
  people.forEach((p, i) => {
    const r = salaryRow(p, ym);
    rows.push([i + 1, p.name, roleLabel(p.role), r.daysInMonth, r.sundays, r.holidays, r.working, r.present, r.late, r.duty, r.paidLeave, r.absent, r.unpaidLeave, r.lateCut, r.lwp, r.payableFull, r.notes.join('; ')]);
  });
  // day-by-day detail, so every number above can be checked
  const [y, m] = ym.split('-').map(Number);
  const last = new Date(y, m, 0).getDate();
  const days = Array.from({ length: last }, (_, i) => `${ym}-${pad(i + 1)}`);
  const code = (p, d, lm) => {
    if (dayIdx(d) < 0) return holidayName(d) ? 'H' : 'S';
    if (d > todayISO()) return '';
    const st = attStatus(p.id, d); const lv = lm[d];
    if (st === 'present') return lv ? 'P/½L' : 'P';
    if (st === 'late') return lv ? 'L/½L' : 'L';
    if (st === 'review') return '?';
    if (st === 'untracked') return '-';
    if (st === 'leave') return lv ? (lv.duty ? 'OD' : lv.unpaid ? 'UL' : 'PL') : 'A';
    if (st === 'absent' || st === 'rejected') return 'A';
    return '';
  };
  const grid = [[L('Staff', 'स्टाफ़'), ...days.map(d => Number(d.slice(8)))]];
  people.forEach(p => { const lm = leaveDayMap(p.id, ym); grid.push([p.name, ...days.map(d => code(p, d, lm))]); });
  const key = [[L('Code', 'कोड'), L('Meaning', 'अर्थ')], ['P', attLabel('present')], ['L', attLabel('late')], ['OD', L('Official duty (paid)', 'विद्यालय कार्य (सवेतन)')], ['PL', L('Paid leave', 'सवेतन छुट्टी')], ['UL', L('Unpaid leave (allowance used up)', 'अवैतनिक छुट्टी (सीमा पूरी)')],
    ['A', L('Absent (no approved leave)', 'अनुपस्थित (स्वीकृत छुट्टी नहीं)')], ['½L', L('Half-day leave on that day', 'उस दिन आधे दिन की छुट्टी')], ['?', L('Check-in waiting for approval', 'चेक-इन स्वीकृति बाकी')], ['-', L('Before attendance started (counted present)', 'हाज़िरी शुरू होने से पहले (उपस्थित गिना)')], ['S', L('Sunday', 'रविवार')], ['H', L('School holiday (paid)', 'विद्यालय अवकाश (सवेतन)')],
    ['', ''], [L('Rule', 'नियम'), L(`Payable days = days in month − absent − unpaid leave − late cut. Every ${rules.lateCount} late marks cut ${rules.lateCut} day. Leave is paid until the yearly allowance for its type is used up.`, `देय दिन = माह के दिन − अनुपस्थित − अवैतनिक छुट्टी − देर कटौती। हर ${rules.lateCount} देर पर ${rules.lateCut} दिन कटौती। छुट्टी तब तक सवेतन है जब तक उस प्रकार की वार्षिक सीमा बची है।`)],
    [L('Status', 'स्थिति'), monthDone ? L('Month complete', 'माह पूरा') : L(`Counted up to ${fmtDate(todayISO())}. Days after today are treated as present.`, `${fmtDate(todayISO())} तक गिना गया। आज के बाद के दिन उपस्थित माने गए।`)]];
  return [{ name: L('Salary days', 'वेतन दिवस'), rows, widths: [6, 26, 14, 9, 9, 9, 9, 10, 7, 9, 9, 9, 10, 14, 12, 10, 40] },
    { name: L('Day by day', 'दिनवार'), rows: grid, widths: [26, ...days.map(() => 5)] },
    { name: L('Key', 'संकेत'), rows: key.concat([['', ''], [L('Holidays this month', 'इस माह अवकाश'), '']], days.filter(holidayName).map(d => [d, holidayName(d)])), widths: [14, 90] }];
}
function salaryPanelHTML(ym) {
  if (S.v2Missing) return '';
  const rules = salaryRules();
  const people = salaryPeople();
  const rows = people.map(p => ({ p, r: salaryRow(p, ym) }));
  const monthDone = ym < todayISO().slice(0, 7);
  return `<section class="panel"><div class="panel-head"><h3>💼 ${L('Salary-ready attendance', 'वेतन हेतु हाज़िरी')} · ${ym}</h3><div class="btns"><button class="btn small primary" data-act="exportSalary">⬇️ Excel</button><button class="btn small ghost" data-act="printSalary">📄 PDF</button></div></div>
    <p class="hint">${monthDone ? '' : L(`Month not finished: counted up to today, later days are treated as present. `, `माह पूरा नहीं: आज तक गिना गया, बाद के दिन उपस्थित माने गए। `)}${L(`Every ${rules.lateCount} late marks cut ${rules.lateCut} day. Leave beyond the yearly allowance is unpaid.`, `हर ${rules.lateCount} देर पर ${rules.lateCut} दिन कटौती। वार्षिक सीमा से अधिक छुट्टी अवैतनिक।`)} <a href="#" data-act="go" data-view="settings">${L('Change rules', 'नियम बदलें')}</a></p>
    <div class="table-wrap"><table class="data"><thead><tr><th>${L('Staff', 'स्टाफ़')}</th><th>${L('Working', 'कार्य')}</th><th>${attLabel('present')}</th><th>${attLabel('late')}</th><th>${L('Paid leave', 'सवेतन छुट्टी')}</th><th>${attLabel('absent')}</th><th>${L('Unpaid leave', 'अवैतनिक')}</th><th>${L('Late cut', 'देर कटौती')}</th><th>${L('Days cut', 'कटौती')}</th><th>${L('Payable', 'देय')}</th></tr></thead>
    <tbody>${rows.map(({ p, r }) => `<tr><td><b>${esc(p.name)}</b>${r.notes.length ? `<br><small class="muted">${esc(r.notes.join('; '))}</small>` : ''}</td><td>${r.working}</td><td>${r.present}</td><td class="${r.late >= rules.lateCount ? 'warn-text' : ''}">${r.late}</td><td>${r.paidLeave + r.duty}</td><td class="${r.absent ? 'bad' : ''}">${r.absent}</td><td class="${r.unpaidLeave ? 'bad' : ''}">${r.unpaidLeave}</td><td>${r.lateCut}</td><td class="${r.lwp ? 'bad' : ''}"><b>${r.lwp}</b></td><td><b>${r.payableFull}</b> / ${r.daysInMonth}</td></tr>`).join('')}</tbody></table></div></section>`;
}
Object.assign(ACTIONS, {
  exportSalary: () => { const ym = UI.reportMonth || todayISO().slice(0, 7); deliverFile(makeXlsx(salarySheets(ym)), `MTS-salary-attendance-${ym}.xlsx`, L('Salary attendance', 'वेतन हाज़िरी') + ' ' + ym); logAudit(me().id, `Downloaded salary attendance sheet ${ym}`); },
  printSalary: () => { const ym = UI.reportMonth || todayISO().slice(0, 7); const sh = salarySheets(ym); printHTML(L('Salary-ready attendance', 'वेतन हेतु हाज़िरी') + ' — ' + ym, rowsToTable(sh[0].rows) + '<br>' + rowsToTable(sh[2].rows)); },
});
Object.assign(FORMS, {
  salaryRules: fd => {
    const lateCount = Math.max(0, Math.min(31, Math.round(Number(fd.get('lateCount')) || 0)));
    const lateCut = [0.25, 0.5, 1].includes(Number(fd.get('lateCut'))) ? Number(fd.get('lateCut')) : 0.5;
    const pendingAs = fd.get('pendingAs') === 'absent' ? 'absent' : 'present';
    S.config.salaryRules = { lateCount, lateCut, pendingAs };
    logAudit(me().id, `Salary rules: ${lateCount} late = ${lateCut} day cut`); commit(); toast(L('Saved', 'सहेजा गया'));
  },
});


/* =================================================================
   13. SCHOOL HOLIDAYS (whole school closed; Sundays are already closed)
   ================================================================= */
const holidayDays = () => ((S.config && S.config.holidays && S.config.holidays.days) || {});
/* group consecutive days with the same name into one line: "20–22 Nov · Chhath Puja" */
function holidayGroups() {
  const list = Object.entries(holidayDays()).sort(([a], [b]) => a.localeCompare(b));
  const out = [];
  list.forEach(([d, name]) => {
    const g = out[out.length - 1];
    if (g && g.name === name) {
      let x = addDays(g.to, 1); while (x < d && parseISO(x).getDay() === 0) x = addDays(x, 1);
      if (x === d) { g.to = d; g.days.push(d); return; }
    }
    out.push({ from: d, to: d, name, days: [d] });
  });
  return out;
}
function holidaysPanelHTML() {
  const groups = holidayGroups();
  const today = todayISO();
  const upcoming = groups.filter(g => g.to >= today), past = groups.filter(g => g.to < today);
  const line = g => `<li><div><div><strong>${esc(g.name)}</strong><small>${fmtDate(g.from)}${g.to !== g.from ? ' – ' + fmtDate(g.to) : ''} · ${g.days.length} ${L(g.days.length === 1 ? 'day' : 'days', 'दिन')}</small></div></div><button class="btn tiny danger-ghost" data-act="holidayDel" data-from="${g.from}" data-to="${g.to}" data-name="${esc(g.name)}">${L('Remove', 'हटाएँ')}</button></li>`;
  return `<section class="panel"><h3>🎉 ${L('School holidays', 'विद्यालय अवकाश')}</h3>
    <p class="hint">${L('Declare a holiday for the whole school. It counts like a Sunday: no classes or substitutions, check-in is closed, it is not counted as anyone\'s leave, and it is paid in the salary sheet.', 'पूरे विद्यालय के लिए अवकाश घोषित करें। यह रविवार की तरह गिना जाता है: कोई कक्षा या अरेंजमेंट नहीं, चेक-इन बंद, किसी की छुट्टी में नहीं गिना जाता, और वेतन शीट में सवेतन।')}</p>
    <form data-form="holidayAdd" class="stack">
      <div class="three"><label>${L('Holiday name', 'अवकाश का नाम')} *<input name="name" required maxlength="60" placeholder="${esc(L('e.g. Chhath Puja', 'जैसे छठ पूजा'))}" list="holNames"><datalist id="holNames">${['Republic Day', 'Holi', 'Eid-ul-Fitr', 'Ram Navami', 'Independence Day', 'Raksha Bandhan', 'Janmashtami', 'Gandhi Jayanti', 'Durga Puja', 'Dussehra', 'Diwali', 'Chhath Puja', 'Christmas', 'Winter break', 'Summer vacation'].map(n => `<option>${n}</option>`).join('')}</datalist></label>
        <label>${t('from')} *<input type="date" name="from" required value="${today}"></label>
        <label>${t('to')} <small class="muted">(${L('leave empty for one day', 'एक दिन हो तो खाली छोड़ें')})</small><input type="date" name="to"></label></div>
      <label class="inline"><input type="checkbox" name="tell" checked> ${L('Tell all staff in the app', 'सभी स्टाफ़ को ऐप में सूचना भेजें')}</label>
      <div class="row-end"><button class="btn primary">+ ${L('Declare holiday', 'अवकाश घोषित करें')}</button></div></form>
    ${upcoming.length ? `<h4>${L('Coming up', 'आने वाले')}</h4><ul class="list">${upcoming.map(line).join('')}</ul>` : `<p class="muted">${L('No holidays declared yet.', 'अभी कोई अवकाश घोषित नहीं।')}</p>`}
    ${past.length ? `<details><summary class="muted">${L('Past holidays', 'बीते अवकाश')} (${past.length})</summary><ul class="list">${past.slice().reverse().map(line).join('')}</ul></details>` : ''}
  </section>`;
}
Object.assign(FORMS, {
  holidayAdd: fd => {
    const name = String(fd.get('name') || '').trim().slice(0, 60);
    const from = fd.get('from'); const to = fd.get('to') || from;
    if (!name || !from) return;
    if (to < from) { toast(L('The end date is before the start date.', 'अंतिम तारीख़ शुरू से पहले है।')); return; }
    const all = []; let d = from; let guard = 0;
    while (d <= to && guard++ < 120) { if (parseISO(d).getDay() !== 0) all.push(d); d = addDays(d, 1); }
    if (!all.length) { toast(L('Those dates are all Sundays — they are already closed.', 'ये सभी रविवार हैं — पहले से बंद।')); return; }
    const taken = all.filter(x => holidayDays()[x]);
    const go = () => {
      const days = { ...holidayDays() }; all.forEach(x => { days[x] = name; });
      S.config.holidays = { days, by: me().id, at: nowStamp() };
      // drop draft substitution plans for those days
      all.forEach(x => { if (S.plans[x] && S.plans[x].status !== 'published') delete S.plans[x]; });
      const when = all.length === 1 ? fmtDate(all[0]) : `${fmtDate(all[0])} – ${fmtDate(all[all.length - 1])}`;
      if (fd.get('tell') === 'on') S.staff.filter(s => s.active && s.id !== me().id).forEach(s => notify(s.id, '', { en: `🎉 School holiday: ${name} — ${when}. No classes.`, hi: `🎉 विद्यालय अवकाश: ${name} — ${when}। कक्षाएँ नहीं होंगी।` }));
      const onLeave = S.leaves.filter(l => l.status !== 'rejected' && all.some(x => x >= l.from && x <= l.to)).length;
      logAudit(me().id, `Declared holiday "${name}" ${all[0]}${all.length > 1 ? ' to ' + all[all.length - 1] : ''} (${all.length} day(s))`);
      commit();
      toast(L(`Holiday declared: ${all.length} day(s)`, `अवकाश घोषित: ${all.length} दिन`) + (onLeave ? ' · ' + L(`${onLeave} leave request(s) now count fewer days`, `${onLeave} छुट्टी आवेदन में अब कम दिन गिने जाएँगे`) : ''));
    };
    if (taken.length) confirmBox(L(`${taken.length} of these days already have a holiday. Replace the name with "${name}"?`, `इनमें से ${taken.length} दिन पहले से अवकाश हैं। नाम "${name}" से बदलें?`), go, L('Replace', 'बदलें'));
    else go();
  },
});
Object.assign(ACTIONS, {
  holidayDel: el => {
    const { from, to, name } = el.dataset;
    confirmBox(L(`Remove the holiday "${name}" (${fmtDate(from)}${to !== from ? ' – ' + fmtDate(to) : ''})? Those days become school days again.`, `अवकाश "${name}" (${fmtDate(from)}${to !== from ? ' – ' + fmtDate(to) : ''}) हटाएँ? ये दिन फिर स्कूल के दिन होंगे।`), () => {
      const days = { ...holidayDays() };
      Object.keys(days).forEach(d => { if (d >= from && d <= to && days[d] === name) delete days[d]; });
      S.config.holidays = { days, by: me().id, at: nowStamp() };
      logAudit(me().id, `Removed holiday "${name}" ${from}${to !== from ? ' to ' + to : ''}`); commit(); toast(L('Holiday removed', 'अवकाश हटाया गया'));
    }, L('Remove', 'हटाएँ'));
  },
});


/* =================================================================
   14. ONE-TAP WHATSAPP TO SUBSTITUTES
   ================================================================= */
const waPhone = s => { const d = String((s && s.phone) || '').replace(/\D/g, '').slice(-10); return /^[6-9]\d{9}$/.test(d) ? '91' + d : ''; };
function waItemsFor(plan, tid) { return Object.values(plan.items).filter(i => i.teacherId === tid).sort((a, b) => a.p - b.p); }
const waSig = list => list.map(i => `${i.p}|${i.cls}|${i.subject}|${i.absentId}`).join(';');
function waMessage(date, tid, list) {
  const lines = list.map(i => `• P${i.p} (${periodTime(i.p)}) — ${i.cls} — ${SUBJECTS[i.subject] ? SUBJECTS[i.subject].en : i.subject} (for ${nameOf(i.absentId)})`);
  return `🔁 *Arrangement — ${fmtDate(date)}*\n${nameOf(tid)}, please take:\n${lines.join('\n')}\n\nकृपया ऊपर दिए पीरियड लें और MTS Staff App में "देख लिया" दबाएँ।\n— Office, ${SCHOOL.name}`;
}
function waPanelHTML(date, plan) {
  if (!plan || !plan.items) return '';
  const tids = [...new Set(Object.values(plan.items).map(i => i.teacherId).filter(Boolean))].sort((a, b) => Math.min(...waItemsFor(plan, a).map(i => i.p)) - Math.min(...waItemsFor(plan, b).map(i => i.p)));
  if (!tids.length) return '';
  const sent = plan.wa || {};
  const rows = tids.map(tid => {
    const list = waItemsFor(plan, tid); const s = staffById(tid); const ph = waPhone(s);
    const st = sent[tid]; const fresh = st && st.sig === waSig(list);
    return `<li><div><div><strong>${esc(nameOf(tid))}</strong><small>${list.map(i => `P${i.p} ${esc(i.cls)}`).join(', ')}${st ? ` · ${fresh ? '✓ ' + L('sent', 'भेजा') + ' ' + new Date(st.at).toTimeString().slice(0, 5) : '<span class="warn-text">' + L('changed since sent', 'भेजने के बाद बदला') + '</span>'}` : ''}</small></div></div>
      ${ph ? `<button class="btn small ${fresh ? 'ghost' : 'wa'}" data-act="waSend" data-tid="${tid}">${fresh ? L('Send again', 'फिर भेजें') : '📲 WhatsApp'}</button>` : `<button class="btn small ghost" data-act="go" data-view="staff">${L('Add mobile no.', 'मोबाइल जोड़ें')}</button>`}</li>`;
  }).join('');
  const done = tids.filter(tid => sent[tid] && sent[tid].sig === waSig(waItemsFor(plan, tid))).length;
  return `<section class="panel wa-panel"><div class="panel-head"><h3>📲 ${L('Tell substitutes on WhatsApp', 'अरेंजमेंट शिक्षकों को WhatsApp करें')} <small class="muted">${done}/${tids.length} ${L('sent', 'भेजे')}</small></h3>
    <button class="btn small ghost" data-act="waGroup">👥 ${L('Send whole sheet to a group', 'पूरी शीट ग्रुप में भेजें')}</button></div>
    ${plan.status !== 'published' ? `<p class="hint warn-text">${L('Tip: publish the plan first, so teachers also see it in the app.', 'सुझाव: पहले प्लान प्रकाशित करें, ताकि शिक्षक ऐप में भी देख सकें।')}</p>` : ''}
    <p class="hint">${L('Each button opens WhatsApp with the message already written for that teacher — just press send.', 'हर बटन उस शिक्षक के लिए लिखा संदेश WhatsApp में खोलता है — बस भेजें दबाएँ।')}</p>
    <ul class="list">${rows}</ul></section>`;
}
Object.assign(ACTIONS, {
  waSend: el => {
    const date = UI.date; const plan = S.plans[date]; const tid = el.dataset.tid;
    if (!plan) return;
    const list = waItemsFor(plan, tid); const ph = waPhone(staffById(tid));
    if (!list.length || !ph) return;
    window.open(`https://wa.me/${ph}?text=${encodeURIComponent(waMessage(date, tid, list))}`, '_blank');
    plan.wa = { ...(plan.wa || {}), [tid]: { at: nowStamp(), sig: waSig(list), by: me().id } };
    logAudit(me().id, `WhatsApp arrangement message opened for ${nameOf(tid)} (${date})`);
    commit();
  },
  waGroup: () => {
    const date = UI.date; const plan = S.plans[date]; if (!plan) return;
    const rows = Object.values(plan.items).sort((a, b) => a.p - b.p || CLASSES.indexOf(a.cls) - CLASSES.indexOf(b.cls));
    const txt = `🔁 *Arrangement sheet — ${fmtDate(date)}*\n${rows.map(i => `P${i.p} ${i.cls} ${SUBJECTS[i.subject] ? SUBJECTS[i.subject].en : i.subject} — *${i.teacherId ? nameOf(i.teacherId) : 'NOT COVERED'}* (for ${nameOf(i.absentId)})`).join('\n')}\n— Office, ${SCHOOL.name}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(txt)}`, '_blank');
  },
});

/* timers: reminders every 30 s; refresh "now" cards every minute */
setInterval(() => { try { reminderTick(); } catch (e) { } }, 30000);
setInterval(() => { try { if (S && me() && ['myday', 'dashboard'].includes(UI.view) && !document.getElementById('modal-root').innerHTML) scheduleRender(); } catch (e) { } }, 60000);

/* ---------- v2 blocks used inside existing screens ---------- */
function dashAttendanceHTML(date) {
  if (S.v2Missing) return '';
  const cfg = campusCfg();
  const people = S.staff.filter(s => s.active && s.role !== 'admin');
  const st = people.map(p => attStatus(p.id, date));
  const c = k => st.filter(x => x === k).length;
  const notIn = people.filter(p => ['not_in', 'absent'].includes(attStatus(p.id, date)));
  if (dayIdx(date) < 0) return '';
  return `<section class="panel att-dash"><div class="panel-head"><h3>✅ ${L('Staff attendance', 'स्टाफ़ हाज़िरी')} · ${fmtDate(date)}</h3><button class="btn small ghost" data-act="go" data-view="attendance">${L('Open', 'खोलें')} →</button></div>

    <div class="att-bar">${[['present', c('present')], ['late', c('late')], ['leave', c('leave')], [date === todayISO() && nowHM() <= cfg.close ? 'not_in' : 'absent', c('not_in') + c('absent') + c('rejected')]].map(([k, n]) => `<div class="att-seg att-${k}" style="flex:${Math.max(n, 0.0001)}" title="${esc(attLabel(k))}: ${n}"></div>`).join('')}</div>
    <p class="att-legend">${[['present', c('present')], ['late', c('late')], ['leave', c('leave')]].map(([k, n]) => `${attChip(k)} <b>${n}</b>`).join(' ')} ${attChip(date === todayISO() && nowHM() <= cfg.close ? 'not_in' : 'absent')} <b>${c('not_in') + c('absent') + c('rejected')}</b></p>
    ${notIn.length && notIn.length <= 12 ? `<p class="muted">${date === todayISO() && nowHM() <= cfg.close ? L('Not checked in yet', 'अभी चेक-इन नहीं') : L('Did not check in', 'चेक-इन नहीं किया')}: ${notIn.map(p => esc(p.name)).join(', ')}</p>` : ''}
    </section>`;
}
function myDayExtrasHTML(date) {
  const u = me();
  const duties = S.v2Missing ? [] : myDuties(u.id, date);
  const notif = notifSupported() && Notification.permission === 'default';
  if (!duties.length && !notif) return '';
  return `<div>${duties.length ? `<section class="panel"><div class="panel-head"><h3>🗒️ ${L('Exam duty', 'परीक्षा ड्यूटी')}</h3></div><ul class="list">${duties.map(d => `<li><div><div><strong>${esc(d.session)} ${esc(d.time)}</strong><small>${esc(d.exam)} · ${L('Room', 'कक्ष')} ${esc(d.room)}</small></div></div></li>`).join('')}</ul></section>` : ''}
    ${notif ? `<section class="panel"><p>🔔 ${L('Get a reminder 5 minutes before each period and when you get an arrangement.', 'हर पीरियड से 5 मिनट पहले और अरेंजमेंट मिलने पर रिमाइंडर पाएँ।')}</p><button class="btn primary" data-act="enableNotif">${L('Turn on reminders', 'रिमाइंडर चालू करें')}</button></section>` : ''}</div>`;
}
function reportAttendanceHTML(ym) {
  if (S.v2Missing) return '';
  ensureMonthLoaded(ym);
  const people = S.staff.filter(s => s.active && s.role !== 'admin');
  const rows = people.map(p => ({ p, s: monthStats(p.id, ym) }));
  const tot = rows.reduce((a, r) => ({ present: a.present + r.s.present, late: a.late + r.s.late, absent: a.absent + r.s.absent, leave: a.leave + r.s.leave }), { present: 0, late: 0, absent: 0, leave: 0 });
  return `<section class="panel"><div class="panel-head"><h3>✅ ${L('Staff attendance this month', 'इस माह स्टाफ़ हाज़िरी')}</h3><button class="btn small ghost" data-act="exportAttendance">⬇️ Excel</button></div>
    <div class="cards"><div class="stat ok"><span>${attLabel('present')}</span><b>${tot.present}</b></div><div class="stat ${tot.late ? 'warn' : ''}"><span>${attLabel('late')}</span><b>${tot.late}</b></div><div class="stat ${tot.absent ? 'warn' : ''}"><span>${attLabel('absent')}</span><b>${tot.absent}</b></div><div class="stat"><span>${attLabel('leave')}</span><b>${tot.leave}</b></div></div>
    <div class="table-wrap"><table class="data"><thead><tr><th>${L('Staff', 'स्टाफ़')}</th><th>${attLabel('present')}</th><th>${attLabel('late')}</th><th>${attLabel('absent')}</th><th>${attLabel('leave')}</th><th>%</th></tr></thead>
    <tbody>${rows.sort((a, b) => b.s.absent + b.s.late - (a.s.absent + a.s.late)).map(({ p, s }) => { const pc = s.days - s.leave > 0 ? Math.round(((s.present + s.late) / (s.days - s.leave)) * 100) : null; return `<tr><td>${esc(p.name)}</td><td>${s.present}</td><td class="${s.late >= 3 ? 'warn-text' : ''}">${s.late}</td><td class="${s.absent ? 'bad' : ''}">${s.absent}</td><td>${s.leave}</td><td>${pc == null ? '—' : pc + '%'}</td></tr>`; }).join('')}</tbody></table></div></section>`;
}
Object.assign(I18N.en, { attendance: 'Attendance', syllabus: 'Syllabus', exams: 'Exam duties' });
Object.assign(I18N.hi, { attendance: 'हाज़िरी', syllabus: 'पाठ्यक्रम', exams: 'परीक्षा ड्यूटी' });
Object.assign(ACTIONS, { reloadPage: () => location.reload() });

/* ---------- wiring ---------- */
document.addEventListener('click', ev => {
  const el = ev.target.closest('[data-act]');
  if (!el) return;
  // the dark backdrop closes the dialog only when the backdrop itself is clicked
  if (el.dataset.act === 'closeModalBack' && ev.target !== el) return;
  const fn = ACTIONS[el.dataset.act];
  if (fn) { ev.preventDefault(); fn(el, ev); }
});
document.addEventListener('change', ev => {
  const el = ev.target.closest('[data-change]');
  if (el && CHANGES[el.dataset.change]) CHANGES[el.dataset.change](el, ev);
});
document.addEventListener('submit', ev => {
  const form = ev.target.closest('form[data-form]');
  if (!form) return;
  ev.preventDefault();
  const fn = FORMS[form.dataset.form];
  if (fn) fn(new FormData(form), form);
});
document.addEventListener('keydown', ev => { if (ev.key === 'Escape') closeModal(); });

function showCode(s, code) {
  const link = APP_CONFIG.siteUrl || location.href.split('#')[0];
  const msg = `${SCHOOL.name} staff app\n${L('Open', 'खोलें')}: ${link}\n${L('Mobile', 'मोबाइल')}: ${s.phone}\n${L('Activation code', 'एक्टिवेशन कोड')}: ${code}\n${L('Enter your mobile number and this code, then choose your own 6-digit PIN.', 'अपना मोबाइल नंबर और यह कोड डालें, फिर अपना 6 अंकों का PIN चुनें।')}`;
  openModal(L('Activation code', 'एक्टिवेशन कोड'), `<p><b>${esc(s.name)}</b> · +91 ${esc(s.phone)}</p>
    <div class="bigcode">${esc(code)}</div>
    <p class="hint">${L('Give this code to the staff member (in person or on WhatsApp). It works once.', 'यह कोड स्टाफ़ सदस्य को दें (सामने या WhatsApp पर)। यह एक बार काम करता है।')}</p>
    <textarea class="copybox" rows="5" readonly>${esc(msg)}</textarea>
    <div class="row-end"><a class="btn ghost" href="https://wa.me/91${esc(s.phone)}?text=${encodeURIComponent(msg)}" target="_blank" rel="noopener">WhatsApp</a><button class="btn primary" data-act="copyCodeMsg" data-msg="${esc(msg)}">📋 ${L('Copy message', 'संदेश कॉपी करें')}</button></div>`);
}


/* ===== Assistant: school-data look-ups used by the built-in assistant (brain.js) ===== */

/* ---------- helpers for tool inputs ---------- */
function resolveDate(s) {
  if (!s) return todayISO();
  const v = String(s).trim().toLowerCase();
  if (/^(today|aaj|आज)$/.test(v)) return todayISO();
  if (/^(tomorrow|kal|कल)$/.test(v)) return addDays(todayISO(), 1);
  if (/^yesterday$/.test(v)) return addDays(todayISO(), -1);
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v;
  let m = v.match(/^(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](\d{2,4}))?$/);
  if (m) { const y = m[3] ? (m[3].length === 2 ? '20' + m[3] : m[3]) : todayISO().slice(0, 4); return `${y}-${pad(m[2])}-${pad(m[1])}`; }
  const d = dayFromName(v);
  if (d >= 0) { let dt = todayISO(); for (let i = 0; i < 7 && dayIdx(dt) !== d; i++) dt = addDays(dt, 1); return dt; }
  return todayISO();
}
function dayFromName(v) {
  if (v === undefined || v === null || v === '') return -1;
  if (typeof v === 'number') return v >= 0 && v < 6 ? v : -1;
  const s = String(v).toLowerCase();
  const i = DAYS.findIndex(x => s.startsWith(x.toLowerCase()));
  if (i >= 0) return i;
  const hi = DAYS_HI.findIndex(x => s.startsWith(x.slice(0, 3)));
  return hi;
}
const findPerson = q => {
  if (!q) return null;
  const s = String(q).toLowerCase().trim();
  return S.staff.find(x => x.id.toLowerCase() === s) || S.staff.find(x => x.name.toLowerCase() === s) ||
    S.staff.find(x => x.name.toLowerCase().includes(s)) || S.staff.find(x => s.split(/\s+/).every(w => x.name.toLowerCase().includes(w))) || null;
};
const subjCode = q => {
  if (!q) return null;
  const s = String(q).toLowerCase();
  return Object.keys(SUBJECTS).find(k => k.toLowerCase() === s || SUBJECTS[k].en.toLowerCase().startsWith(s) || SUBJECTS[k].hi === q) || null;
};
const clsCode = q => { if (!q) return null; const n = x => String(x).toUpperCase().replace(/\s|CLASS|-/g, ''); return CLASSES.find(c => n(c) === n(q)) || n(q); };
const inRange = (d, from, to) => (!from || d >= from) && (!to || d <= to);
const lessonText = l => (l ? `${l.label || l.cls || ''} ${subjName(l.s)}`.trim() : 'free');

/* ---------- the tools Claude can use ---------- */
function aiTools() {
  const mgr = isManager(me());
  const list = [
    { name: 'school_overview', description: 'Today\'s date, the school day structure (periods, times, lunch), classes, subjects, the current user and headline counts (staff, absences today, pending leave, open requests).',
      input_schema: { type: 'object', properties: {} },
      run: () => ({
        school: `${SCHOOL.name}, ${SCHOOL.place}`, today: todayISO(), weekday: dayIdx(todayISO()) >= 0 ? DAYS_LONG[dayIdx(todayISO())] : 'Sunday (no school)',
        workingDays: DAYS_LONG, periods: PERIODS.map(p => ({ period: p.n, time: periodTime(p.n) })), lunch: `${LUNCH.start}-${LUNCH.end} after P${LUNCH.after}`,
        classes: CLASSES, subjects: Object.fromEntries(Object.entries(SUBJECTS).map(([k, v]) => [k, v.en])),
        user: { name: me().name, role: me().role },
        counts: { activeTeachers: teachers().length, absentToday: new Set(absencesOn(todayISO()).map(a => a.teacherId)).size, pendingLeave: S.leaves.filter(l => l.status === 'pending').length, openRequests: S.requests.filter(r => !['delivered', 'rejected'].includes(r.status)).length },
        substitutionRules: S.settings,
      }) },
    { name: 'find_staff', description: 'List staff with role, subjects, classes they teach, class-teacher duty, periods per week and active status. Filter by name text, subject, class or role. Leave all filters empty for everyone.',
      input_schema: { type: 'object', properties: { name: { type: 'string' }, subject: { type: 'string', description: 'code or name, e.g. MAT or Mathematics' }, class: { type: 'string', description: 'e.g. 9A' }, role: { type: 'string', enum: ['admin', 'coordinator', 'teacher'] }, include_inactive: { type: 'boolean' } } },
      run: i => {
        const sc = subjCode(i.subject), cc = clsCode(i.class);
        return S.staff.filter(s => (i.include_inactive || s.active) && (!i.role || s.role === i.role) && (!i.name || s.name.toLowerCase().includes(String(i.name).toLowerCase()))
          && (!sc || s.subjects.includes(sc)) && (!cc || teachesClass(s.id, cc)))
          .map(s => ({ name: s.name, role: s.role, subjects: s.subjects.map(k => SUBJECTS[k] ? SUBJECTS[k].en : k), active: s.active,
            classesTaught: CLASSES.filter(c => teachesClass(s.id, c)), classTeacherOf: Object.entries(S.classTeachers).filter(([, v]) => v === s.id).map(([k]) => k),
            periodsPerWeek: s.role === 'teacher' ? weeklyLoad(s.id) : null, ...(mgr ? { mobile: s.phone } : {}) }));
      } },
    { name: 'teacher_schedule', description: 'One teacher\'s periods. With a date: that day including published substitutions and leave. Without date: the full weekly timetable.',
      input_schema: { type: 'object', properties: { teacher: { type: 'string' }, date: { type: 'string', description: 'YYYY-MM-DD, today, tomorrow or a weekday name' } }, required: ['teacher'] },
      run: i => {
        const s = findPerson(i.teacher); if (!s) return { error: 'No staff member matches that name' };
        if (!i.date) return { teacher: s.name, week: DAYS.map((d, di) => ({ day: DAYS_LONG[di], periods: PERIODS.map(p => `P${p.n}: ${lessonText(teacherLessonAt(s.id, di, p.n))}`) })), periodsPerWeek: weeklyLoad(s.id) };
        const dt = resolveDate(i.date), d = dayIdx(dt); if (d < 0) return { date: dt, note: 'Sunday — no school' };
        const plan = S.plans[dt];
        return { teacher: s.name, date: dt, day: DAYS_LONG[d], periods: PERIODS.map(p => {
          const sub = plan && plan.status === 'published' && Object.values(plan.items).find(x => x.teacherId === s.id && x.p === p.n);
          const absent = isAbsent(s.id, dt, p.n);
          return { period: p.n, time: periodTime(p.n), duty: absent ? 'on leave' : sub ? `SUBSTITUTION ${sub.cls} ${SUBJECTS[sub.subject].en} (for ${nameOf(sub.absentId)})` : lessonText(teacherLessonAt(s.id, d, p.n)) };
        }) };
      } },
    { name: 'class_timetable', description: 'A class timetable for one weekday, or the whole week if no day is given. Classes: ' + CLASSES.join(', '),
      input_schema: { type: 'object', properties: { class: { type: 'string' }, day: { type: 'string', description: 'weekday name or date' } }, required: ['class'] },
      run: i => {
        const c = clsCode(i.class); if (!S.tt[c]) return { error: 'Unknown class. Classes: ' + CLASSES.join(', ') };
        const row = d => PERIODS.map(p => { const l = lessonAt(c, d, p.n); return l ? `P${p.n} ${cellSubj(l)} — ${cellTeachers(l)}` : `P${p.n} free`; });
        const ct = nameOf(S.classTeachers[c]);
        if (!i.day) return { class: c, classTeacher: ct, week: DAYS.map((d, di) => ({ day: DAYS_LONG[di], periods: row(di) })) };
        const d = /\d/.test(i.day) || /today|tomorrow|aaj|kal/i.test(i.day) ? dayIdx(resolveDate(i.day)) : dayFromName(i.day);
        if (d < 0) return { error: 'Sunday or unknown day' };
        return { class: c, classTeacher: ct, day: DAYS_LONG[d], periods: row(d) };
      } },
    { name: 'who_teaches', description: 'Which teacher teaches which subject in which class (from the timetable), with periods per week. Filter by class and/or subject.',
      input_schema: { type: 'object', properties: { class: { type: 'string' }, subject: { type: 'string' } } },
      run: i => {
        const cc = clsCode(i.class), sc = subjCode(i.subject); const out = {};
        CLASSES.filter(c => !cc || c === cc).forEach(c => S.tt[c].forEach(day => day.forEach(l => partsOf(l).forEach(g => {
          if (sc && g.s !== sc) return; const k = `${c}|${g.s}|${g.t}`; out[k] = (out[k] || 0) + 1;
        }))));
        return Object.entries(out).map(([k, n]) => { const [c, s, t] = k.split('|'); return { class: c, subject: SUBJECTS[s].en, teacher: nameOf(t), periodsPerWeek: n }; });
      } },
    { name: 'free_teachers', description: 'Teachers who have no class in a period (and are not absent) on a date. Without period: every period of that day.',
      input_schema: { type: 'object', properties: { date: { type: 'string' }, period: { type: 'integer', minimum: 1, maximum: 8 } } },
      run: i => {
        const dt = resolveDate(i.date), d = dayIdx(dt); if (d < 0) return { date: dt, note: 'Sunday — no school' };
        const plan = S.plans[dt];
        const busySub = (tid, p) => plan && Object.values(plan.items).some(x => x.teacherId === tid && x.p === p);
        const ps = i.period ? [i.period] : PERIODS.map(p => p.n);
        return { date: dt, day: DAYS_LONG[d], periods: ps.map(p => ({ period: p, time: periodTime(p), free: teachers().filter(tc => !teacherLessonAt(tc.id, d, p) && !isAbsent(tc.id, dt, p) && !busySub(tc.id, p)).map(tc => tc.name) })) };
      } },
    { name: 'absences', description: 'Teachers marked absent (from approved leave or marked by the office) between two dates, optionally for one teacher. Defaults to today.',
      input_schema: { type: 'object', properties: { from: { type: 'string' }, to: { type: 'string' }, teacher: { type: 'string' } } },
      run: i => {
        const from = resolveDate(i.from || 'today'), to = i.to ? resolveDate(i.to) : (i.from ? from : todayISO()); const p = i.teacher && findPerson(i.teacher);
        return S.absences.filter(a => inRange(a.date, from, to) && (!p || a.teacherId === p.id)).sort((a, b) => a.date.localeCompare(b.date))
          .map(a => ({ date: a.date, teacher: nameOf(a.teacherId), scope: a.scope === 'periods' ? 'P' + scopePeriods(a.scope, a.periods).join(',P') : a.scope, note: a.note || '', source: a.source }));
      } },
    { name: 'leave_requests', description: 'Leave applications with status (pending/approved/rejected), dates, type, reason and remark. Filter by status, teacher, and date range (overlapping).',
      input_schema: { type: 'object', properties: { status: { type: 'string', enum: ['pending', 'approved', 'rejected'] }, teacher: { type: 'string' }, from: { type: 'string' }, to: { type: 'string' } } },
      run: i => {
        const p = i.teacher && findPerson(i.teacher); const from = i.from && resolveDate(i.from), to = i.to && resolveDate(i.to);
        return S.leaves.filter(l => (!i.status || l.status === i.status) && (!p || l.teacherId === p.id) && (!from || l.to >= from) && (!to || l.from <= to))
          .sort((a, b) => b.from.localeCompare(a.from))
          .map(l => ({ teacher: nameOf(l.teacherId), from: l.from, to: l.to, duration: l.scope, type: l.type, reason: l.description, status: l.status, remark: l.remark || '', decidedBy: l.decidedBy ? nameOf(l.decidedBy) : null, appliedOn: (l.createdAt || '').slice(0, 10) }));
      } },
    { name: 'substitutions', description: 'Substitution (arrangement) periods between two dates: date, period, class, subject, absent teacher, substitute, whether the substitute has seen it, and plan status. Filter by teacher (either side) or class.',
      input_schema: { type: 'object', properties: { from: { type: 'string' }, to: { type: 'string' }, teacher: { type: 'string' }, class: { type: 'string' }, published_only: { type: 'boolean' } } },
      run: i => {
        const from = resolveDate(i.from || 'today'), to = i.to ? resolveDate(i.to) : (i.from ? from : todayISO()); const p = i.teacher && findPerson(i.teacher); const cc = clsCode(i.class);
        const rows = [];
        Object.entries(S.plans).filter(([dt]) => inRange(dt, from, to)).sort(([a], [b]) => a.localeCompare(b)).forEach(([dt, plan]) => {
          if (i.published_only && plan.status !== 'published') return;
          if (!isManager(me()) && plan.status !== 'published') return;
          Object.values(plan.items).sort((a, b) => a.p - b.p).forEach(x => {
            if (p && x.teacherId !== p.id && x.absentId !== p.id) return; if (cc && x.cls !== cc) return;
            rows.push({ date: dt, period: x.p, class: x.cls, subject: SUBJECTS[x.subject].en, absentTeacher: nameOf(x.absentId), substitute: x.teacherId ? nameOf(x.teacherId) : 'NOT COVERED', seen: isAcked(dt, x.key, x.teacherId), planStatus: plan.status });
          });
        });
        return rows;
      } },
    { name: 'workload_and_fairness', description: 'Per teacher: periods per week, substitutions taken and leave days in a date range (default: this month). Use for fairness, workload or "who did most/least" questions.',
      input_schema: { type: 'object', properties: { from: { type: 'string' }, to: { type: 'string' } } },
      run: i => {
        const from = i.from ? resolveDate(i.from) : todayISO().slice(0, 8) + '01', to = i.to ? resolveDate(i.to) : todayISO();
        const subs = {}, leave = {};
        Object.entries(S.plans).forEach(([dt, plan]) => { if (inRange(dt, from, to) && plan.status === 'published') Object.values(plan.items).forEach(x => { if (x.teacherId) subs[x.teacherId] = (subs[x.teacherId] || 0) + 1; }); });
        S.absences.forEach(a => { if (inRange(a.date, from, to)) (leave[a.teacherId] = leave[a.teacherId] || new Set()).add(a.date); });
        return { from, to, teachers: teachers().map(tc => ({ teacher: tc.name, periodsPerWeek: weeklyLoad(tc.id), substitutionsTaken: subs[tc.id] || 0, leaveDays: leave[tc.id] ? leave[tc.id].size : 0 })).sort((a, b) => b.substitutionsTaken - a.substitutionsTaken) };
      } },
    { name: 'dpp_worksheet_requests', description: 'DPP and worksheet requests with class, subject, chapter/topic or description, copies, needed-by date, status, who raised it, who is preparing it, and whether a draft exists.',
      input_schema: { type: 'object', properties: { kind: { type: 'string', enum: ['dpp', 'worksheet'] }, status: { type: 'string', enum: ['requested', 'approved', 'in_progress', 'ready', 'delivered', 'rejected'] }, class: { type: 'string' }, teacher: { type: 'string' }, overdue_only: { type: 'boolean' }, open_only: { type: 'boolean' } } },
      run: i => {
        const cc = clsCode(i.class), p = i.teacher && findPerson(i.teacher), today = todayISO();
        return S.requests.filter(r => (!i.kind || r.kind === i.kind) && (!i.status || r.status === i.status) && (!cc || r.classId === cc) && (!p || r.teacherId === p.id || r.assignee === p.id)
          && (!i.open_only || !['delivered', 'rejected'].includes(r.status)) && (!i.overdue_only || (r.neededBy < today && !['delivered', 'rejected'].includes(r.status))))
          .sort((a, b) => a.neededBy.localeCompare(b.neededBy))
          .map(r => ({ kind: r.kind, class: r.classId, subject: SUBJECTS[r.subject] ? SUBJECTS[r.subject].en : r.subject, what: r.kind === 'dpp' ? `${r.chapter}${r.topic ? ' — ' + r.topic : ''} (${r.numQ} Q, ${r.difficulty})` : `${r.wsType}: ${r.description}`,
            copies: r.copies, neededBy: r.neededBy, overdue: r.neededBy < today && !['delivered', 'rejected'].includes(r.status), status: r.status, raisedBy: nameOf(r.teacherId), preparedBy: r.assignee ? nameOf(r.assignee) : null, remark: r.remark || '', hasDraft: !!r.draft }));
      } },
    { name: 'notices', description: 'Notices on the staff notice board, newest first.',
      input_schema: { type: 'object', properties: {} },
      run: () => S.notices.map(n => ({ title: n.title, message: n.body, postedBy: nameOf(n.by), on: (n.at || '').slice(0, 10) })) },
    { name: 'my_notifications', description: 'The current user\'s recent notifications.',
      input_schema: { type: 'object', properties: {} },
      run: () => S.notifications.filter(n => n.userId === me().id).slice(0, 30).map(n => ({ text: n.en, at: (n.at || '').slice(0, 16), read: n.read })) },
  ];
  if (mgr) list.push(
    { name: 'preview_substitution', description: 'What-if: if a teacher were absent on a date (full day, first/second half or given periods), which periods need cover and who the app would suggest (top 3 with reasons). Changes nothing.',
      input_schema: { type: 'object', properties: { teacher: { type: 'string' }, date: { type: 'string' }, scope: { type: 'string', enum: ['full', 'first', 'second', 'periods'] }, periods: { type: 'array', items: { type: 'integer' } } }, required: ['teacher'] },
      run: i => {
        const s = findPerson(i.teacher); if (!s) return { error: 'No staff member matches that name' };
        const dt = resolveDate(i.date), d = dayIdx(dt); if (d < 0) return { date: dt, note: 'Sunday — no school' };
        const temp = { id: '__preview', teacherId: s.id, date: dt, scope: i.scope || 'full', periods: i.periods || [] };
        S.absences.push(temp);
        try {
          const gaps = computeGaps(dt).filter(g => g.absentId === s.id);
          const existing = S.plans[dt] ? Object.values(S.plans[dt].items).filter(x => x.teacherId && x.absentId !== s.id).map(x => ({ teacherId: x.teacherId, p: x.p })) : [];
          const placed = existing.slice();
          return { teacher: s.name, date: dt, periodsToCover: gaps.map(g => {
            const ranked = rankCandidates(dt, g, placed); if (ranked[0]) placed.push({ teacherId: ranked[0].id, p: g.p });
            return { period: g.p, class: g.cls, subject: SUBJECTS[g.subject].en, suggestions: ranked.slice(0, 3).map(r => ({ teacher: nameOf(r.id), score: r.score, why: r.why.map(w => `${w.en} (${w.pts > 0 ? '+' : ''}${w.pts})`).join('; ') })) };
          }) };
        } finally { S.absences = S.absences.filter(a => a.id !== '__preview'); }
      } },
    { name: 'audit_log', description: 'Recent changes made in the app (who did what, when). Optional text filter.',
      input_schema: { type: 'object', properties: { contains: { type: 'string' }, limit: { type: 'integer' } } },
      run: i => S.audit.filter(a => !i.contains || a.text.toLowerCase().includes(String(i.contains).toLowerCase())).slice(0, Math.min(i.limit || 40, 150)).map(a => ({ at: (a.at || '').slice(0, 16), by: nameOf(a.by), action: a.text })) },
  );
  return list;
}

/* ---------- tiny, safe markdown for answers ---------- */
function md(src) {
  const lines = esc(src).split('\n');
  const inline = s => s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<i>$2</i>').replace(/`([^`]+)`/g, '<code>$1</code>');
  let html = '', i = 0;
  while (i < lines.length) {
    const ln = lines[i];
    if (/^\s*\|.*\|\s*$/.test(ln) && i + 1 < lines.length && /^\s*\|[\s:\-|]+\|\s*$/.test(lines[i + 1])) {
      const cells = l => l.trim().replace(/^\||\|$/g, '').split('|').map(c => inline(c.trim()));
      html += '<div class="md-table"><table><thead><tr>' + cells(ln).map(c => `<th>${c}</th>`).join('') + '</tr></thead><tbody>';
      i += 2;
      while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) { html += '<tr>' + cells(lines[i]).map(c => `<td>${c}</td>`).join('') + '</tr>'; i++; }
      html += '</tbody></table></div>'; continue;
    }
    if (/^\s*[-*•]\s+/.test(ln)) {
      html += '<ul>'; while (i < lines.length && /^\s*[-*•]\s+/.test(lines[i])) { html += `<li>${inline(lines[i].replace(/^\s*[-*•]\s+/, ''))}</li>`; i++; } html += '</ul>'; continue;
    }
    if (/^\s*\d+[.)]\s+/.test(ln)) {
      html += '<ol>'; while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) { html += `<li>${inline(lines[i].replace(/^\s*\d+[.)]\s+/, ''))}</li>`; i++; } html += '</ol>'; continue;
    }
    if (/^#{1,4}\s+/.test(ln)) { html += `<p><b>${inline(ln.replace(/^#{1,4}\s+/, ''))}</b></p>`; i++; continue; }
    if (!ln.trim()) { i++; continue; }
    html += `<p>${inline(ln)}</p>`; i++;
  }
  return html;
}

/* ===== Timetable Builder (Admin / Coordinator) ===== */
const BLD = { cls: null, scope: 'all', preview: null, pcls: null, busy: false, seed: 1 };
const SLOTS = () => DAYS.length * PERIODS.length;

/* What a class should have each week: { SUBJ: { n: periods, t: teacherId } }.
   Until someone edits it, it is read from the current timetable. */
function curriculumOf(cls) {
  if (S.curriculum[cls]) return S.curriculum[cls];
  const out = {}, votes = {};
  (S.tt[cls] || []).forEach(day => day.forEach(l => {
    if (!l) return;
    out[l.s] = out[l.s] || { n: 0, t: l.t };
    out[l.s].n++;
    votes[l.s] = votes[l.s] || {};
    votes[l.s][l.t] = (votes[l.s][l.t] || 0) + 1;
  }));
  Object.keys(out).forEach(s => { out[s].t = Object.entries(votes[s]).sort((a, b) => b[1] - a[1])[0][0]; });
  return out;
}
function editCurriculum(cls) {
  if (!S.curriculum[cls]) S.curriculum[cls] = JSON.parse(JSON.stringify(curriculumOf(cls)));
  return S.curriculum[cls];
}
const currTotal = cls => Object.values(curriculumOf(cls)).reduce((a, x) => a + (Number(x.n) || 0), 0);
function plannedLoad() {
  const load = {};
  CLASSES.forEach(c => Object.values(curriculumOf(c)).forEach(x => { if (x.t && x.n) load[x.t] = (load[x.t] || 0) + Number(x.n); }));
  return load;
}

/* Problems that make a timetable impossible, before we try to build it */
function curriculumProblems(classes) {
  const out = [];
  classes.forEach(c => {
    const cur = curriculumOf(c), tot = currTotal(c);
    if (tot > SLOTS()) out.push(L(`${c}: ${tot} periods planned, but a week has only ${SLOTS()}.`, `${c}: ${tot} पीरियड तय हैं, पर सप्ताह में केवल ${SLOTS()} हैं।`));
    if (tot === 0) out.push(L(`${c}: no subjects added yet.`, `${c}: अभी कोई विषय नहीं जोड़ा।`));
    Object.entries(cur).forEach(([s, x]) => {
      if (!x.n) return;
      if (!x.t || !staffById(x.t) || !staffById(x.t).active) out.push(L(`${c}: choose a teacher for ${subjName(s)}.`, `${c}: ${subjName(s)} के लिए शिक्षक चुनें।`));
      if (x.n > DAYS.length * 2) out.push(L(`${c}: ${subjName(s)} has ${x.n} periods; the most possible is ${DAYS.length * 2} (2 a day).`, `${c}: ${subjName(s)} के ${x.n} पीरियड; अधिकतम ${DAYS.length * 2} (दिन में 2) संभव हैं।`));
    });
  });
  Object.entries(plannedLoad()).forEach(([tid, n]) => {
    if (n > SLOTS()) out.push(L(`${nameOf(tid)} has ${n} periods planned — more than the ${SLOTS()} in a week.`, `${nameOf(tid)} के ${n} पीरियड तय हैं — सप्ताह के ${SLOTS()} से ज़्यादा।`));
  });
  return out;
}

/* Build a clash-free timetable for `targets`; all other classes stay as they are. */
function buildTimetable(targets, seed) {
  const ND = DAYS.length, NP = PERIODS.length, NS = ND * NP;
  let best = null;
  for (let attempt = 0; attempt < 12; attempt++) {
    const rnd = mulberry32(seed * 104729 + attempt * 7919);
    const rows = {};
    CLASSES.forEach(c => {
      if (!targets.includes(c)) { rows[c] = []; for (let d = 0; d < ND; d++) for (let p = 1; p <= NP; p++) rows[c].push(lessonAt(c, d, p)); return; }
      const list = [];
      Object.entries(curriculumOf(c)).forEach(([s, x]) => { for (let i = 0; i < x.n; i++) list.push({ s, t: x.t }); });
      while (list.length < NS) list.push(null);
      for (let i = list.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [list[i], list[j]] = [list[j], list[i]]; }
      rows[c] = list;
    });
    const hard = (c, i) => {
      const cell = rows[c][i]; if (!cell) return 0;
      let cost = 0;
      for (const o of CLASSES) if (o !== c && partsOf(rows[o][i]).some(g => g.t === cell.t)) cost++;
      const d0 = Math.floor(i / NP) * NP; let same = 0;
      for (let k = d0; k < d0 + NP; k++) if (rows[c][k] && rows[c][k].s === cell.s) same++;
      if (same > 2) cost += same - 2;
      return cost;
    };
    const total = () => { let n = 0; targets.forEach(c => { for (let i = 0; i < NS; i++) n += hard(c, i); }); return n; };
    let cost = total();
    for (let step = 0; step < 70000 && cost > 0; step++) {
      const c = targets[Math.floor(rnd() * targets.length)], i = Math.floor(rnd() * NS);
      if (hard(c, i) === 0 && rnd() > 0.02) continue;
      let pick = -1, bestDelta = Infinity;
      for (let k = 0; k < 20; k++) {
        const j = Math.floor(rnd() * NS);
        if (j === i) continue;
        const a = rows[c][i], b = rows[c][j];
        if ((a && b && a.s === b.s) || (!a && !b)) continue;
        const before = hard(c, i) + hard(c, j);
        rows[c][i] = b; rows[c][j] = a;
        const after = hard(c, i) + hard(c, j);
        rows[c][i] = a; rows[c][j] = b;
        const delta = after - before + (rnd() - 0.5) * 0.2;
        if (delta < bestDelta) { bestDelta = delta; pick = j; }
      }
      if (pick >= 0 && bestDelta <= 0.1) [rows[c][i], rows[c][pick]] = [rows[c][pick], rows[c][i]];
      if (step % 500 === 0) cost = total();
    }
    cost = total();
    if (cost === 0) {
      // tidy up without breaking anything: free periods to the end of the day, same subject not twice a day
      const soft = c => {
        let n = 0;
        for (let d = 0; d < ND; d++) {
          let seenFree = false; const cnt = {};
          for (let p = 0; p < NP; p++) {
            const x = rows[c][d * NP + p];
            if (!x) seenFree = true; else { if (seenFree) n += 3; cnt[x.s] = (cnt[x.s] || 0) + 1; }
          }
          Object.values(cnt).forEach(v => { if (v > 1) n += 1; });
        }
        return n;
      };
      for (let step = 0; step < 25000; step++) {
        const c = targets[Math.floor(rnd() * targets.length)], i = Math.floor(rnd() * NS), j = Math.floor(rnd() * NS);
        if (i === j) continue;
        const before = soft(c);
        if (before === 0) continue;
        [rows[c][i], rows[c][j]] = [rows[c][j], rows[c][i]];
        if (hard(c, i) + hard(c, j) > 0 || soft(c) > before) [rows[c][i], rows[c][j]] = [rows[c][j], rows[c][i]];
      }
    }
    if (!best || cost < best.cost) {
      const tt = {};
      targets.forEach(c => { tt[c] = []; for (let d = 0; d < ND; d++) tt[c].push(rows[c].slice(d * NP, d * NP + NP).map(x => (x ? { s: x.s, t: x.t } : null))); });
      best = { tt, cost };
    }
    if (cost === 0) break;
  }
  return { tt: best.tt, ok: best.cost === 0, cost: best.cost, classes: targets.slice() };
}

/* Problems in the timetable that is live right now */
function timetableIssues() {
  const clashes = [], empty = {};
  for (let d = 0; d < DAYS.length; d++) for (let p = 1; p <= PERIODS.length; p++) {
    const seen = {};
    CLASSES.forEach(c => {
      const l = lessonAt(c, d, p);
      if (!l) { empty[c] = (empty[c] || 0) + 1; return; }
      partsOf(l).forEach(g => {
        if (!g.t) return;
        const first = seen[g.t];
        if (!first) seen[g.t] = { c, j: !!l.j };
        else if (!(l.j && first.j)) clashes.push({ day: d, p, teacher: g.t, classes: [first.c, c] });
      });
    });
  }
  const inactive = [];
  CLASSES.forEach(c => (S.tt[c] || []).forEach(day => day.forEach(l => partsOf(l).forEach(g => { if ((!staffById(g.t) || !staffById(g.t).active) && !inactive.includes(`${c}|${g.t}`)) inactive.push(`${c}|${g.t}`); }))));
  return { clashes, empty, inactive };
}

/* ---------- screen ---------- */
function ttGridHTML(tt, cls) {
  const head = `<tr><th>${t('period')}</th>${DAYS.map((d, i) => `<th>${S.lang === 'hi' ? DAYS_HI[i].slice(0, 3) : d}</th>`).join('')}</tr>`;
  let rows = '';
  PERIODS.forEach(pp => {
    rows += `<tr><th><b>P${pp.n}</b><small>${periodTime(pp.n)}</small></th>` + DAYS.map((_, d) => {
      const l = tt[cls][d][pp.n - 1];
      return l ? `<td class="subj-${l.s}"><b>${esc(cellSubj(l))}</b><small>${esc(cellTeachers(l))}</small></td>` : `<td class="freecell">—</td>`;
    }).join('') + '</tr>';
    if (pp.n === LUNCH.after) rows += `<tr class="lunchrow"><th><small>${LUNCH.start}–${LUNCH.end}</small></th><td colspan="${DAYS.length}">🍱 ${t('lunch')}</td></tr>`;
  });
  return `<div class="table-wrap"><table class="tt">${head}${rows}</table></div>`;
}

function viewBuilder() {
  if (!BLD.cls || !S.tt[BLD.cls]) BLD.cls = CLASSES[0];
  const cls = BLD.cls, cur = curriculumOf(cls), tot = currTotal(cls), slots = SLOTS();
  const load = plannedLoad();
  const unused = Object.keys(SUBJECTS).filter(s => !cur[s]);
  const subjRows = Object.entries(cur).map(([s, x]) => `<tr>
      <td><b>${esc(subjName(s))}</b></td>
      <td><div class="stepper"><button class="btn tiny" data-act="bldStep" data-s="${s}" data-n="-1" aria-label="less">−</button><input type="number" min="0" max="12" value="${x.n}" data-change="bldPeriods" data-s="${s}" aria-label="${esc(subjName(s))} periods"><button class="btn tiny" data-act="bldStep" data-s="${s}" data-n="1" aria-label="more">+</button></div></td>
      <td><select data-change="bldTeacher" data-s="${s}" aria-label="${esc(subjName(s))} teacher">${teacherOptions(x.t, { includeEmpty: true, emptyLabel: L('Choose teacher', 'शिक्षक चुनें') })}</select></td>
      <td><button class="btn tiny ghost" data-act="bldRemoveSubject" data-s="${s}">✕</button></td></tr>`).join('');
  const problems = curriculumProblems(BLD.scope === 'all' ? CLASSES : [cls]);
  const loadRows = teachers().map(tc => ({ tc, n: load[tc.id] || 0 })).sort((a, b) => b.n - a.n);
  const pv = BLD.preview;
  const issues = timetableIssues();

  let previewHTML = '';
  if (BLD.busy) previewHTML = `<section class="panel"><div class="spinner"></div><p class="muted" style="text-align:center">${L('Building a clash-free timetable…', 'बिना टकराव की समय-सारणी बन रही है…')}</p></section>`;
  else if (pv) {
    if (!pv.classes.includes(BLD.pcls)) BLD.pcls = pv.classes[0];
    previewHTML = `<section class="panel preview">
      <div class="panel-head"><h3>${L('Step 3 · Preview', 'चरण 3 · पूर्वावलोकन')}</h3>${pv.ok ? `<span class="chip st-approved">✓ ${L('No clashes', 'कोई टकराव नहीं')}</span>` : `<span class="chip st-rejected">${pv.cost} ${L('clashes left', 'टकराव बाकी')}</span>`}</div>
      ${pv.ok ? `<p class="muted">${L('This is only a preview. Nothing changes for staff until you press “Use this timetable”.', 'यह केवल पूर्वावलोकन है। “यह समय-सारणी लागू करें” दबाने तक स्टाफ़ के लिए कुछ नहीं बदलता।')}</p>`
        : `<div class="banner warn">${L('Could not remove every clash. Usually a teacher has too many periods, or too many classes need the same teacher. Reduce periods or change a teacher, then try again.', 'सभी टकराव नहीं हट सके। अक्सर किसी शिक्षक के पीरियड बहुत ज़्यादा होते हैं। पीरियड घटाएँ या शिक्षक बदलें, फिर कोशिश करें।')}</div>`}
      <div class="tabs">${pv.classes.map(c => `<button class="tab ${c === BLD.pcls ? 'active' : ''}" data-act="bldPreviewClass" data-c="${c}">${c}</button>`).join('')}</div>
      ${ttGridHTML(pv.tt, BLD.pcls)}
      <div class="row-end"><button class="btn ghost" data-act="bldDiscard">${L('Discard', 'हटाएँ')}</button><button class="btn" data-act="bldGenerate">↻ ${L('Try another arrangement', 'दूसरी व्यवस्था देखें')}</button>
        ${pv.ok ? `<button class="btn primary" data-act="bldApply">✓ ${L('Use this timetable', 'यह समय-सारणी लागू करें')}</button>` : ''}</div>
    </section>`;
  }

  return `<div class="page-head"><h2>${t('builder')}</h2><button class="btn ghost" data-act="go" data-view="timetable">📅 ${L('See current timetable', 'मौजूदा समय-सारणी देखें')}</button></div>
  <p class="muted">${L('Set how many periods each subject gets and who teaches it. The app then arranges the week so that no teacher is in two classes at once.', 'तय करें कि हर विषय को कितने पीरियड मिलें और कौन पढ़ाए। फिर ऐप सप्ताह ऐसे जमाता है कि कोई शिक्षक एक साथ दो कक्षाओं में न हो।')}</p>
  ${issues.clashes.length ? `<div class="banner warn">⚠️ ${L(`The current timetable has ${issues.clashes.length} teacher clash(es). Ask the assistant “check timetable” for the list.`, `मौजूदा समय-सारणी में ${issues.clashes.length} टकराव हैं। सूची के लिए सहायक से “check timetable” पूछें।`)}</div>` : ''}

  <section class="panel">
    <div class="panel-head"><h3>${L('Step 1 · Choose a class', 'चरण 1 · कक्षा चुनें')}</h3><div class="btns"><button class="btn small" data-act="bldAddClass">+ ${L('Add class', 'कक्षा जोड़ें')}</button><button class="btn small danger-ghost" data-act="bldRemoveClass">${L('Remove this class', 'यह कक्षा हटाएँ')}</button></div></div>
    <div class="tabs">${CLASSES.map(c => { const n = currTotal(c); return `<button class="tab ${c === cls ? 'active' : ''}" data-act="bldClass" data-c="${c}">${c}${n > slots ? ' ⚠️' : ''}</button>`; }).join('')}</div>
    <label class="inline-field">${L('Class teacher of', 'कक्षा-शिक्षक —')} ${cls}<select data-change="bldClassTeacher">${teacherOptions(S.classTeachers[cls] || '', { includeEmpty: true })}</select></label>
  </section>

  <div class="grid2">
    <section class="panel">
      <div class="panel-head"><h3>${L('Step 2 · Subjects for', 'चरण 2 · विषय —')} ${cls}</h3>
        <span class="chip ${tot > slots ? 'st-rejected' : tot === slots ? 'st-approved' : 'st-requested'}">${tot} / ${slots} ${L('periods', 'पीरियड')}${tot < slots ? ` · ${slots - tot} ${L('free', 'खाली')}` : ''}</span></div>
      <div class="table-wrap"><table class="data bld"><thead><tr><th>${t('subject')}</th><th>${L('Periods / week', 'पीरियड / सप्ताह')}</th><th>${t('teacher')}</th><th></th></tr></thead><tbody>${subjRows || `<tr><td colspan="4" class="muted">${L('No subjects yet. Add one below.', 'अभी कोई विषय नहीं। नीचे से जोड़ें।')}</td></tr>`}</tbody></table></div>
      <div class="btns bld-add">
        ${unused.length ? `<select data-change="bldAddSubject" aria-label="Add subject"><option value="">+ ${L('Add subject…', 'विषय जोड़ें…')}</option>${unused.map(s => `<option value="${s}">${esc(subjName(s))}</option>`).join('')}</select>` : ''}
        <button class="btn small ghost" data-act="bldNewSubject">+ ${L('New subject', 'नया विषय')}</button>
        <select data-change="bldCopyFrom" aria-label="Copy from class"><option value="">${L('Copy from class…', 'किसी कक्षा से कॉपी…')}</option>${CLASSES.filter(c => c !== cls).map(c => `<option>${c}</option>`).join('')}</select>
      </div>
    </section>
    <section class="panel">
      <div class="panel-head"><h3>${L('Teacher load (all classes)', 'शिक्षक कार्यभार (सभी कक्षाएँ)')}</h3></div>
      <div class="table-wrap loadlist"><table class="data bars"><tbody>${loadRows.map(({ tc, n }) => `<tr><td>${esc(tc.name)}</td><td><div class="bar ${n > slots ? 'over' : n > 40 ? 'sub' : ''}"><i style="width:${Math.min(100, (n / slots) * 100)}%"></i><span>${n}${n > slots ? ' ⚠️' : ''}</span></div></td></tr>`).join('')}</tbody></table></div>
      <p class="hint">${L(`Periods per week out of ${slots}. Above 40 leaves almost no free period for substitutions.`, `${slots} में से प्रति सप्ताह पीरियड। 40 से ऊपर होने पर अरेंजमेंट के लिए खाली पीरियड लगभग नहीं बचते।`)}</p>
    </section>
  </div>

  <section class="panel">
    <div class="panel-head"><h3>${L('Step 3 · Build the timetable', 'चरण 3 · समय-सारणी बनाएँ')}</h3></div>
    <div class="seg wide"><button class="${BLD.scope === 'all' ? 'active' : ''}" data-act="bldScope" data-scope="all">${L('All classes', 'सभी कक्षाएँ')}</button><button class="${BLD.scope === 'one' ? 'active' : ''}" data-act="bldScope" data-scope="one">${L(`Only ${cls} (keep the others)`, `केवल ${cls} (बाकी वैसी ही)`)}</button></div>
    ${problems.length ? `<div class="error list"><b>${L('Fix these first:', 'पहले इन्हें ठीक करें:')}</b><ul>${problems.slice(0, 8).map(p => `<li>${esc(p)}</li>`).join('')}</ul></div>` : ''}
    <div class="row-end"><button class="btn primary big" data-act="bldGenerate" ${problems.length || BLD.busy ? 'disabled' : ''}>🛠️ ${L('Build timetable', 'समय-सारणी बनाएँ')}</button></div>
  </section>
  ${previewHTML}`;
}

/* ---------- actions ---------- */
Object.assign(ACTIONS, {
  bldClass: el => { BLD.cls = el.dataset.c; render(); },
  bldScope: el => { BLD.scope = el.dataset.scope; BLD.preview = null; render(); },
  bldPreviewClass: el => { BLD.pcls = el.dataset.c; render(); },
  bldDiscard: () => { BLD.preview = null; render(); },
  bldStep: el => { const x = editCurriculum(BLD.cls)[el.dataset.s]; x.n = Math.max(0, Math.min(12, (Number(x.n) || 0) + Number(el.dataset.n))); BLD.preview = null; commit(); },
  bldRemoveSubject: el => { delete editCurriculum(BLD.cls)[el.dataset.s]; BLD.preview = null; commit(); },
  bldNewSubject: () => openModal(L('New subject', 'नया विषय'), `<form data-form="bldSubject" class="stack">
    <label>${L('Name in English', 'अंग्रेज़ी में नाम')} *<input name="en" required maxlength="30" placeholder="e.g. Moral Science"></label>
    <label>${L('Name in Hindi', 'हिंदी में नाम')}<input name="hi" maxlength="30" placeholder="जैसे नैतिक शिक्षा"></label>
    <div class="error hidden" id="subjErr"></div>
    <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn primary">${t('save')}</button></div></form>`),
  bldAddClass: () => openModal(L('Add class', 'कक्षा जोड़ें'), `<form data-form="bldClass" class="stack">
    <label>${L('Class name', 'कक्षा का नाम')} *<input name="name" required maxlength="16" placeholder="e.g. 5A or 6 Arjuna"></label>
    <label>${L('Start with the subjects of', 'इस कक्षा के विषयों से शुरू करें')}<select name="from"><option value="">${L('Empty', 'खाली')}</option>${CLASSES.map(c => `<option>${c}</option>`).join('')}</select></label>
    <div class="error hidden" id="clsErr"></div>
    <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn primary">${L('Add', 'जोड़ें')}</button></div></form>`),
  bldRemoveClass: () => {
    if (CLASSES.length <= 1) { toast(L('At least one class is needed', 'कम से कम एक कक्षा चाहिए')); return; }
    const c = BLD.cls;
    confirmBox(L(`Remove class ${c} and its whole timetable? This cannot be undone.`, `कक्षा ${c} और उसकी पूरी समय-सारणी हटाएँ? यह वापस नहीं होगा।`), () => {
      delete S.tt[c]; delete S.curriculum[c]; delete S.classTeachers[c]; syncClasses(); BLD.cls = CLASSES[0]; BLD.preview = null;
      if (UI.ttClass === c) UI.ttClass = CLASSES[0];
      Object.keys(S.plans).forEach(dt => { if (dt >= todayISO()) generatePlan(dt, me().id); });
      logAudit(me().id, `Removed class ${c}`); commit(); toast(L('Class removed', 'कक्षा हटाई गई'));
    }, L('Remove', 'हटाएँ'));
  },
  bldGenerate: () => {
    const targets = BLD.scope === 'all' ? CLASSES.slice() : [BLD.cls];
    if (curriculumProblems(targets).length) return;
    BLD.busy = true; BLD.preview = null; render();
    setTimeout(() => {
      try { BLD.preview = buildTimetable(targets, BLD.seed++ + Math.floor(Math.random() * 1000)); BLD.pcls = targets.includes(BLD.cls) ? BLD.cls : targets[0]; }
      catch (e) { toast(L('Could not build — please try again', 'नहीं बन सकी — फिर कोशिश करें')); }
      BLD.busy = false; render();
      const el = document.querySelector('.preview'); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 60);
  },
  bldApply: () => {
    const pv = BLD.preview; if (!pv || !pv.ok) return;
    confirmBox(L(`Replace the timetable of ${pv.classes.length === CLASSES.length ? 'all classes' : pv.classes.join(', ')} with this one? All staff will see the new timetable at once.`, `${pv.classes.length === CLASSES.length ? 'सभी कक्षाओं' : pv.classes.join(', ')} की समय-सारणी इससे बदलें? सभी स्टाफ़ को तुरंत नई समय-सारणी दिखेगी।`), () => {
      pv.classes.forEach(c => { S.tt[c] = pv.tt[c]; if (!S.curriculum[c]) S.curriculum[c] = JSON.parse(JSON.stringify(curriculumOf(c))); });
      Object.keys(S.plans).forEach(dt => { if (dt >= todayISO()) generatePlan(dt, me().id); });
      S.staff.filter(s => s.active && s.id !== me().id).forEach(s => notify(s.id, '', { en: 'The school timetable has been updated. Please check your new periods.', hi: 'स्कूल की समय-सारणी बदली गई है। कृपया अपने नए पीरियड देखें।' }));
      logAudit(me().id, `Applied a new timetable for ${pv.classes.length === CLASSES.length ? 'all classes' : pv.classes.join(', ')}`);
      BLD.preview = null; UI.ttClass = BLD.cls; UI.ttMode = 'class'; UI.view = 'timetable';
      commit(); toast(L('New timetable is live', 'नई समय-सारणी लागू हो गई'));
    }, L('Use this timetable', 'लागू करें'));
  },
});
Object.assign(CHANGES, {
  bldPeriods: el => { editCurriculum(BLD.cls)[el.dataset.s].n = Math.max(0, Math.min(12, Math.round(Number(el.value) || 0))); BLD.preview = null; commit(); },
  bldTeacher: el => { editCurriculum(BLD.cls)[el.dataset.s].t = el.value; BLD.preview = null; commit(); },
  bldAddSubject: el => {
    if (!el.value) return;
    const s = el.value, def = teachers().find(tc => tc.subjects.includes(s));
    editCurriculum(BLD.cls)[s] = { n: 1, t: def ? def.id : '' }; BLD.preview = null; commit();
  },
  bldCopyFrom: el => {
    if (!el.value) return;
    const from = el.value, to = BLD.cls;
    confirmBox(L(`Replace the subject list of ${to} with a copy of ${from}?`, `${to} की विषय-सूची को ${from} की कॉपी से बदलें?`), () => { S.curriculum[to] = JSON.parse(JSON.stringify(curriculumOf(from))); BLD.preview = null; commit(); }, L('Copy', 'कॉपी'));
  },
  bldClassTeacher: el => { if (el.value) S.classTeachers[BLD.cls] = el.value; else delete S.classTeachers[BLD.cls]; logAudit(me().id, `Class teacher of ${BLD.cls}: ${el.value ? nameOf(el.value) : 'none'}`); commit(); },
});
Object.assign(FORMS, {
  bldSubject: fd => {
    const en = String(fd.get('en')).trim(), hi = String(fd.get('hi') || '').trim() || en;
    const err = document.getElementById('subjErr');
    if (Object.values(SUBJECTS).some(v => v.en.toLowerCase() === en.toLowerCase())) { err.textContent = L('This subject already exists.', 'यह विषय पहले से है।'); err.classList.remove('hidden'); return; }
    let code = en.replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase() || 'SUB', n = 1;
    while (SUBJECTS[code]) code = code.slice(0, 2) + n++;
    S.customSubjects[code] = { en, hi }; SUBJECTS[code] = { en, hi };
    editCurriculum(BLD.cls)[code] = { n: 1, t: '' };
    logAudit(me().id, `Added subject ${en}`); BLD.preview = null; closeModal(); commit();
  },
  bldClass: fd => {
    let name = String(fd.get('name')).trim().replace(/\s+/g, ' ');
    const err = document.getElementById('clsErr');
    name = /^\d+\s?[A-Za-z]{1,3}$/.test(name) ? name.toUpperCase().replace(/\s/g, '') : name.toLowerCase().replace(/(^|[\s\-])([a-z])/g, (m, a, b) => a + b.toUpperCase());
    if (!/^[0-9A-Za-z][0-9A-Za-z\- ]{0,15}$/.test(name)) { err.textContent = L('Use letters and numbers only, like 5A or 6 Arjuna (up to 16 characters).', 'केवल अक्षर और अंक, जैसे 5A या 6 Arjuna (अधिकतम 16 अक्षर)।'); err.classList.remove('hidden'); return; }
    if (Object.keys(S.tt).some(k => k.toLowerCase() === name.toLowerCase())) { err.textContent = L('This class already exists.', 'यह कक्षा पहले से है।'); err.classList.remove('hidden'); return; }
    S.tt[name] = DAYS.map(() => PERIODS.map(() => null));
    S.curriculum[name] = fd.get('from') ? JSON.parse(JSON.stringify(curriculumOf(fd.get('from')))) : {};
    syncClasses(); BLD.cls = name; BLD.scope = 'one'; BLD.preview = null;
    logAudit(me().id, `Added class ${name}`); closeModal(); commit();
    toast(L('Class added. Set its subjects, then build its timetable.', 'कक्षा जुड़ी। विषय तय करें, फिर समय-सारणी बनाएँ।'));
  },
});

/* ===== Built-in smart assistant: understands questions in English, Hindi and Hinglish
   and answers from school data. No outside AI service is used. ===== */
const BR = { ctx: {}, lastIntent: null };

/* ---------- small helpers ---------- */
const tool = (name, input) => aiTools().find(x => x.name === name).run(input || {});
const tbl = (head, rows) => `| ${head.join(' | ')} |\n|${head.map(() => '---').join('|')}|\n` + rows.map(r => `| ${r.map(c => String(c == null ? '' : c).replace(/\|/g, '/').replace(/\n/g, ' ')).join(' | ')} |`).join('\n');
const rlabel = r => (r.from === r.to ? fmtDate(r.from) : `${fmtDate(r.from)} – ${fmtDate(r.to)}`);
const one = iso => ({ from: iso, to: iso });
const monthRange = (y, m) => { const last = new Date(y, m, 0).getDate(); return { from: `${y}-${pad(m)}-01`, to: `${y}-${pad(m)}-${pad(last)}` }; };
const thisMonth = () => { const t0 = todayISO(); return monthRange(Number(t0.slice(0, 4)), Number(t0.slice(5, 7))); };
const nowHM = () => { const d = new Date(); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };
function currentPeriod() { const hm = nowHM(); const p = PERIODS.find(x => hm >= x.start && hm < x.end); return p ? p.n : null; }
function lev(a, b) {
  if (Math.abs(a.length - b.length) > 1) return 9;
  const dp = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return dp[a.length][b.length];
}
function dutyAt(tid, dt, p) {
  const d = dayIdx(dt); if (d < 0) return { k: 'off', text: L('no school', 'स्कूल बंद') };
  if (isAbsent(tid, dt, p)) return { k: 'leave', text: L('on leave', 'छुट्टी पर') };
  const plan = S.plans[dt];
  const sub = plan && (plan.status === 'published' || isManager(me())) && Object.values(plan.items).find(x => x.teacherId === tid && x.p === p);
  if (sub) return { k: 'sub', text: `${L('Substitution', 'अरेंजमेंट')}: ${sub.cls} · ${subjName(sub.subject)}` };
  const l = teacherLessonAt(tid, d, p);
  return l ? { k: 'class', text: `${l.label} · ${subjName(l.s)}` } : { k: 'free', text: t('free') };
}

/* ---------- understanding the question ---------- */
const SUBJ_WORDS = {
  MAT: ['math', 'maths', 'mathematics', 'ganit', 'गणित'], SCI: ['science', 'vigyan', 'विज्ञान'], ENG: ['english', 'angrezi', 'अंग्रेज़ी', 'अंग्रेजी'],
  HIN: ['hindi', 'हिंदी', 'हिन्दी'], SST: ['sst', 'social', 'samajik', 'सामाजिक'], SKT: ['sanskrit', 'संस्कृत'], CMP: ['computer', 'computers', 'कंप्यूटर'],
  GAM: ['games', 'sports', 'khel', 'खेल'], ART: ['art', 'drawing', 'kala', 'कला'], LIB: ['library', 'pustakalay', 'पुस्तकालय'],
  BMT: ['basic maths', 'basic math'], AI: ['ai', 'artificial intelligence'], CNV: ['conversation', 'conv', 'spoken'], RDG: ['reading'], URD: ['urdu', 'उर्दू'],
  PHY: ['physics', 'phy', 'भौतिकी'], CHE: ['chemistry', 'chem', 'रसायन'], BIO: ['biology', 'bio', 'जीव विज्ञान'], MAB: ['mental ability', 'reasoning'],
  CIV: ['civics', 'नागरिक'], HIS: ['history', 'itihas', 'इतिहास'], GEO: ['geography', 'geo', 'bhugol', 'भूगोल'],
};
function entSubject(lower) {
  const pairs = [];
  Object.keys(SUBJECTS).forEach(code => (SUBJ_WORDS[code] || []).concat([SUBJECTS[code].en.toLowerCase(), SUBJECTS[code].hi]).forEach(w => { if (w) pairs.push([w, code]); }));
  pairs.sort((a, b) => b[0].length - a[0].length);
  for (const [w, code] of pairs) if (/^[a-z ]+$/.test(w) ? new RegExp('\\b' + w + '\\b').test(lower) : lower.includes(w)) return code;
  return null;
}
const NAME_STOP = new Set(['office', 'admin', 'teacher', 'sir', 'madam', 'maam', 'the', 'and', 'for', 'who', 'free', 'class', 'leave', 'today', 'period']);
function entPerson(lower) {
  const words = lower.match(/[a-z]+/g) || [];
  let hits = S.staff.map(s => {
    const toks = (s.name.toLowerCase().match(/[a-z]+/g) || []).filter(x => x.length >= 3 && !NAME_STOP.has(x));
    let n = 0, full = 0;
    toks.forEach(tk => { if (words.includes(tk)) { n += 1; full++; } else if (tk.length >= 5 && words.some(w => w.length >= 4 && lev(tk, w) <= 1)) { n += 0.9; full++; } });
    return { s, n, all: full === toks.length };
  }).filter(x => x.n > 0);
  if (!hits.length) return {};
  const top = Math.max(...hits.map(h => h.n));
  let best = hits.filter(h => h.n === top);
  if (best.length > 1 && best.some(h => h.all)) best = best.filter(h => h.all);
  return best.length === 1 ? { person: best[0].s } : { ambiguous: best.map(h => h.s) };
}
function entClass(q) {
  const up = q.toUpperCase();
  const sorted = CLASSES.slice().sort((a, b) => b.length - a.length);
  const rx = x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/[\s\-]+/g, '[\\s\\-]*');
  for (const c of sorted) {
    const m = c.toUpperCase().match(/^(\d+)[\s\-]*(.*)$/);
    const pat = m ? `(?<![A-Z0-9])${m[1]}(?:ST|ND|RD|TH)?[\\s\\-]*${rx(m[2])}(?![A-Z0-9])` : `(?<![A-Z0-9])${rx(c.toUpperCase())}(?![A-Z0-9])`;
    if (new RegExp(pat).test(up)) return { cls: c };
  }
  const g = q.toLowerCase().match(/(?:class|kaksha|कक्षा|std|standard)\s*(\d{1,2})(?!\d)/);
  if (g) { const list = CLASSES.filter(c => new RegExp('^' + g[1] + '(?!\\d)').test(c)); if (list.length) return { grade: list }; }
  return {};
}
const ORD = { first: 1, second: 2, third: 3, fourth: 4, fifth: 5, sixth: 6, seventh: 7, eighth: 8, pehla: 1, pehle: 1, pahla: 1, doosra: 2, dusra: 2, teesra: 3, tisra: 3, chautha: 4, panchva: 5, paanchva: 5, chhatha: 6, satva: 7, saatva: 7, aathva: 8, last: PERIODS.length, aakhri: PERIODS.length };
function entPeriod(lower) {
  let m = lower.match(/(?:period|पीरियड|घंटी|ghanti|\bp)\s*[-#]?\s*([1-8])(?!\d)/) || lower.match(/\b([1-8])\s*(?:st|nd|rd|th)?\s*(?:period|पीरियड|घंटी|ghanti)/);
  if (m) return { period: Number(m[1]) };
  m = lower.match(/\b(first|second|third|fourth|fifth|sixth|seventh|eighth|last|pehla|pehle|pahla|doosra|dusra|teesra|tisra|chautha|panchva|paanchva|chhatha|satva|saatva|aathva|aakhri)\s+(?:period|पीरियड|ghanti)/);
  if (m) return { period: ORD[m[1]] };
  if (/\b(now|right now|currently|abhi|is samay|at the moment)\b|अभी|इस समय/.test(lower)) return { now: true, period: currentPeriod() };
  return {};
}
const MONTHS = [['january', 'jan', 'janvari', 'जनवरी'], ['february', 'feb', 'farvari', 'फरवरी'], ['march', 'mar', 'मार्च'], ['april', 'apr', 'अप्रैल'], ['मई'], ['june', 'jun', 'जून'], ['july', 'jul', 'जुलाई'],
  ['august', 'aug', 'agast', 'अगस्त'], ['september', 'sep', 'sept', 'sitambar', 'सितंबर'], ['october', 'oct', 'aktubar', 'अक्टूबर'], ['november', 'nov', 'navambar', 'नवंबर'], ['december', 'dec', 'disambar', 'दिसंबर']];
const WDAYS = [['monday', 'mon', 'somvar', 'somwar', 'सोमवार'], ['tuesday', 'tue', 'tues', 'mangalvar', 'mangalwar', 'मंगलवार'], ['wednesday', 'wed', 'budhvar', 'budhwar', 'बुधवार'],
  ['thursday', 'thu', 'thur', 'thurs', 'guruvar', 'guruwar', 'brihaspativar', 'गुरुवार'], ['friday', 'fri', 'shukravar', 'shukrawar', 'शुक्रवार'], ['saturday', 'sat', 'shanivar', 'shaniwar', 'शनिवार']];
const hasWord = (lower, w) => (/^[a-z]+$/.test(w) ? new RegExp('\\b' + w + '\\b').test(lower) : lower.includes(w));
function entRange(lower) {
  const today = todayISO(), y = Number(today.slice(0, 4));
  const past = /\b(was|were|did|took|tha|thi|thay|hua|hui|hue|gaya|gaye|gayi|liya|pichhle|pichle|last)\b|था|थी|थे|हुआ|गया|लिया|पिछले/.test(lower);
  let m = lower.match(/\b(\d{4})-(\d{2})-(\d{2})\b/); if (m) return one(m[0]);
  m = lower.match(/\b(\d{1,2})[\/.](\d{1,2})(?:[\/.](\d{2,4}))?\b/);
  if (m && +m[2] >= 1 && +m[2] <= 12 && +m[1] <= 31) return one(`${m[3] ? (m[3].length === 2 ? '20' + m[3] : m[3]) : y}-${pad(m[2])}-${pad(m[1])}`);
  for (let i = 0; i < 12; i++) for (const w of MONTHS[i]) {
    if (!hasWord(lower, w)) continue;
    const dm = lower.match(new RegExp('\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+' + w + '\\b')) || lower.match(new RegExp('\\b' + w + '\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b'));
    let yr = y; if (monthRange(y, i + 1).from > today && past) yr = y - 1;
    if (dm && +dm[1] <= 31) return one(`${yr}-${pad(i + 1)}-${pad(dm[1])}`);
    return monthRange(yr, i + 1);
  }
  if (/\bin may\b|\bmay month\b|\bof may\b/.test(lower)) return monthRange(y, 5);
  if (/day after tomorrow|\bparso\b|\bparson\b|परसों/.test(lower)) return one(addDays(today, past ? -2 : 2));
  if (/\byesterday\b|beeta kal|बीता कल/.test(lower)) return one(addDays(today, -1));
  if (/\btomorrow\b|\btmrw\b|aane wala kal/.test(lower)) return one(addDays(today, 1));
  if (/\bkal\b|कल(?![\u0900-\u097F])/.test(lower)) return one(addDays(today, past ? -1 : 1));
  if (/\btoday\b|\baaj\b|आज|\btonight\b/.test(lower)) return one(today);
  const ws = weekStart(today);
  if (/last week|pichh?le (hafte|saptah|week)|पिछले (हफ्ते|सप्ताह)/.test(lower)) return { from: addDays(ws, -7), to: addDays(ws, -2) };
  if (/next week|agle (hafte|saptah|week)|अगले (हफ्ते|सप्ताह)/.test(lower)) return { from: addDays(ws, 7), to: addDays(ws, 12) };
  if (/this week|is (hafte|saptah|week)|इस (हफ्ते|सप्ताह)|\bweek\b|\bhafte\b|\bweekly\b/.test(lower) && !/per week|a week|\/ ?week|weekly|prati saptah/.test(lower)) return { from: ws, to: addDays(ws, 5) };
  if (/last month|pichh?le (mahine|month|maah)|पिछले (महीने|माह)/.test(lower)) { const d = new Date(y, Number(today.slice(5, 7)) - 2, 1); return monthRange(d.getFullYear(), d.getMonth() + 1); }
  if (/this month|is (mahine|month|maah)|इस (महीने|माह)|\bmonth\b|\bmahine\b|\bmonthly\b/.test(lower)) return thisMonth();
  if (/this year|is saal|इस साल|\byear\b/.test(lower)) return { from: `${y}-01-01`, to: `${y}-12-31` };
  if (/so far|till now|ab tak|अब तक|all time|overall/.test(lower)) return { from: '2000-01-01', to: '2099-12-31', all: true };
  for (let i = 0; i < 6; i++) for (const w of WDAYS[i]) if (hasWord(lower, w)) {
    let dt = today;
    if (past) { dt = addDays(today, -1); for (let k = 0; k < 7 && dayIdx(dt) !== i; k++) dt = addDays(dt, -1); }
    else for (let k = 0; k < 7 && dayIdx(dt) !== i; k++) dt = addDays(dt, 1);
    return { ...one(dt), weekday: i };
  }
  if (/\bsunday\b|\bravivar\b|रविवार|\bitwar\b/.test(lower)) { let dt = today; for (let k = 0; k < 7 && dayIdx(dt) !== -1; k++) dt = addDays(dt, 1); return one(dt); }
  return null;
}

/* ---------- answers ---------- */
function briefing(dt) {
  const u = me(), d = dayIdx(dt), lines = [];
  if (d < 0) return L(`**${fmtDate(dt)}** is ${holidayName(dt) ? 'a holiday (' + holidayName(dt) + ')' : 'a Sunday'} — no school.`, `**${fmtDate(dt)}** ${holidayName(dt) ? 'अवकाश (' + holidayName(dt) + ')' : 'रविवार'} है — स्कूल बंद।`);
  if (!isManager(u)) {
    const duties = PERIODS.map(p => dutyAt(u.id, dt, p.n));
    const subs = duties.filter(x => x.k === 'sub').length, cls = duties.filter(x => x.k === 'class').length;
    lines.push(L(`**${fmtDate(dt)}** — you have **${cls}** teaching period(s)${subs ? ` and **${subs}** substitution period(s)` : ''}.`, `**${fmtDate(dt)}** — आपके **${cls}** पीरियड${subs ? ` और **${subs}** अरेंजमेंट पीरियड` : ''} हैं।`));
    if (duties.some(x => x.k === 'leave')) lines.push(L('You are marked on leave for part or all of the day.', 'आप दिन के कुछ या पूरे समय छुट्टी पर दर्ज हैं।'));
    const pl = S.leaves.filter(l => l.teacherId === u.id && l.status === 'pending').length;
    const rq = S.requests.filter(r => r.teacherId === u.id && !['delivered', 'rejected'].includes(r.status)).length;
    lines.push(`- ${L('Leave waiting for approval', 'स्वीकृति हेतु छुट्टी')}: **${pl}**`, `- ${L('Your open DPP/worksheet requests', 'आपके खुले DPP/वर्कशीट अनुरोध')}: **${rq}**`);
    return lines.join('\n');
  }
  const abs = absencesOn(dt), names = [...new Set(abs.map(a => nameOf(a.teacherId)))];
  const plan = S.plans[dt], items = plan ? Object.values(plan.items) : [];
  const unc = items.filter(i => !i.teacherId).length, unseen = plan && plan.status === 'published' ? items.filter(i => i.teacherId && !isAcked(dt, i.key, i.teacherId)).length : 0;
  lines.push(`**${fmtDate(dt)}**`);
  lines.push(`- ${L('Absent', 'अनुपस्थित')}: **${names.length}**${names.length ? ' — ' + names.join(', ') : ''}`);
  if (items.length) {
    lines.push(`- ${L('Periods to cover', 'भरने वाले पीरियड')}: **${items.length}** · ${L('not covered', 'खाली')}: **${unc}** · ${L('plan', 'योजना')}: **${plan.status === 'published' ? L('published', 'प्रकाशित') : L('NOT published yet', 'अभी प्रकाशित नहीं')}**`);
    if (unseen) lines.push(`- ${L('Substitutes who have not tapped “Seen”', '“देख लिया” न दबाने वाले')}: **${unseen}**`);
  } else lines.push(`- ${L('No periods need cover.', 'कोई पीरियड खाली नहीं।')}`);
  const today = todayISO();
  lines.push(`- ${L('Leave requests waiting', 'लंबित छुट्टी आवेदन')}: **${S.leaves.filter(l => l.status === 'pending').length}**`);
  lines.push(`- ${L('New DPP/worksheet requests', 'नए DPP/वर्कशीट अनुरोध')}: **${S.requests.filter(r => r.status === 'requested').length}** · ${L('overdue', 'देर से')}: **${S.requests.filter(r => r.neededBy < today && !['delivered', 'rejected'].includes(r.status)).length}**`);
  const iss = timetableIssues();
  if (iss.clashes.length) lines.push(`- ⚠️ ${L('Timetable clashes', 'समय-सारणी टकराव')}: **${iss.clashes.length}**`);
  return lines.join('\n');
}

function scheduleAnswer(p, r, week) {
  if (week) {
    const head = [t('period')].concat(DAYS.map((d, i) => (S.lang === 'hi' ? DAYS_HI[i].slice(0, 3) : d)));
    const rows = PERIODS.map(pp => [`P${pp.n}`].concat(DAYS.map((_, d) => { const l = teacherLessonAt(p.id, d, pp.n); return l ? `${l.label} ${subjName(l.s)}` : '—'; })));
    return `**${p.name}** — ${L('weekly timetable', 'साप्ताहिक समय-सारणी')} (${weeklyLoad(p.id)} ${L('periods', 'पीरियड')})\n\n` + tbl(head, rows);
  }
  const dt = r.from;
  if (dayIdx(dt) < 0) return L(`${fmtDate(dt)} is ${holidayName(dt) ? 'a holiday (' + holidayName(dt) + ')' : 'a Sunday'} — no school.`, `${fmtDate(dt)} ${holidayName(dt) ? 'अवकाश (' + holidayName(dt) + ')' : 'रविवार'} है — स्कूल बंद।`);
  const rows = PERIODS.map(pp => [`P${pp.n}`, periodTime(pp.n), dutyAt(p.id, dt, pp.n).text]);
  const n = rows.filter(x => x[2] !== t('free')).length;
  return `**${p.name}** — ${fmtDate(dt)} (${n} ${L('busy periods', 'व्यस्त पीरियड')})\n\n` + tbl([t('period'), L('Time', 'समय'), L('Duty', 'कार्य')], rows);
}
function classAnswer(cls, r, week) {
  const ct = S.classTeachers[cls] ? ` · ${L('class teacher', 'कक्षा-शिक्षक')}: ${nameOf(S.classTeachers[cls])}` : '';
  if (week || !r) {
    const head = [t('period')].concat(DAYS.map((d, i) => (S.lang === 'hi' ? DAYS_HI[i].slice(0, 3) : d)));
    const rows = PERIODS.map(pp => [`P${pp.n}`].concat(DAYS.map((_, d) => { const l = lessonAt(cls, d, pp.n); return l ? `${cellSubj(l)} (${cellTeachers(l, true)})` : '—'; })));
    return `**${cls}** — ${L('weekly timetable', 'साप्ताहिक समय-सारणी')}${ct}\n\n` + tbl(head, rows);
  }
  const dt = r.from, d = dayIdx(dt);
  if (d < 0) return L(`${fmtDate(dt)} is ${holidayName(dt) ? 'a holiday (' + holidayName(dt) + ')' : 'a Sunday'} — no school.`, `${fmtDate(dt)} ${holidayName(dt) ? 'अवकाश (' + holidayName(dt) + ')' : 'रविवार'} है — स्कूल बंद।`);
  const plan = S.plans[dt];
  const rows = PERIODS.map(pp => {
    const l = lessonAt(cls, d, pp.n); if (!l) return [`P${pp.n}`, periodTime(pp.n), '—', '—'];
    const sub = plan && (plan.status === 'published' || isManager(me())) && plan.items[`${cls}|${pp.n}`];
    return [`P${pp.n}`, periodTime(pp.n), cellSubj(l), sub ? `${sub.teacherId ? nameOf(sub.teacherId) : L('NOT COVERED', 'खाली')} (${L('for', 'की जगह')} ${nameOf(sub.absentId || l.t)})` : cellTeachers(l)];
  });
  return `**${cls}** — ${fmtDate(dt)}${ct}\n\n` + tbl([t('period'), L('Time', 'समय'), t('subject'), t('teacher')], rows);
}
function helpText() {
  const mgr = isManager(me());
  return L(`I answer from the school's own data. Try asking:\n
- **Today**: "today's summary", "who is absent today?", "is everything covered?"
- **Teachers**: "Rohit Sir's schedule tomorrow", "where is Aaisha Ma'am now?", "who is free in period 5?", "who teaches Science in 7 Arjuna?"
- **Classes**: "9 Sharper timetable on Thursday", "what does 8 Arjuna have now?"
- **Substitutions**: "who took the most substitutions this month?", "uncovered periods today", "who has not seen their substitution?"
- **Leave**: "pending leave", "how many leaves did Dipti Ma'am take this month?", "who took the most leave?"
- **DPP & worksheets**: "overdue requests", "DPP requests for 8 Achiever", "worksheets waiting for approval"
- **Workload**: "who has the most periods?", "periods per week of Mahesh Sir"
${mgr ? '- **Planning**: "if Rohit Sir is absent tomorrow who will cover?", "check timetable for clashes", "who changed the timetable?"\n' : ''}- You can also type in Hindi or Hinglish: "aaj kaun absent hai", "period 5 me kaun khali hai", "meri chutti".`,
  `मैं स्कूल के अपने डेटा से उत्तर देता हूँ। ऐसे पूछें:\n
- **आज**: "आज का सारांश", "आज कौन अनुपस्थित है?", "क्या सब पीरियड भर गए?"
- **शिक्षक**: "Rohit Sir का कल का शेड्यूल", "Aaisha Ma'am अभी कहाँ हैं?", "पीरियड 5 में कौन खाली है?", "7 Arjuna में विज्ञान कौन पढ़ाता है?"
- **कक्षा**: "9 Sharper का गुरुवार का टाइमटेबल"
- **अरेंजमेंट**: "इस महीने सबसे ज़्यादा अरेंजमेंट किसके?", "आज खाली रह गए पीरियड"
- **छुट्टी**: "लंबित छुट्टी", "Dipti Ma'am ने इस महीने कितनी छुट्टी ली?"
- **DPP और वर्कशीट**: "देर से चल रहे अनुरोध", "8 Achiever के DPP"
- **कार्यभार**: "सबसे ज़्यादा पीरियड किसके हैं?"
${mgr ? '- **योजना**: "अगर कल Rohit Sir न आएँ तो कौन पढ़ाएगा?", "टाइमटेबल में टकराव जाँचो"\n' : ''}- Hinglish भी चलेगी: "aaj kaun absent hai", "meri chutti".`);
}

function brainAnswer(q) {
  const lower = q.toLowerCase().replace(/[?!।,]/g, ' ').replace(/\s+/g, ' ').trim();
  const u = me(), mgr = isManager(u);
  const has = re => re.test(lower);
  // entities
  let { person, ambiguous } = entPerson(lower);
  const selfRef = has(/\b(my|me|mine|mera|meri|mere|main|mujhe|apna|apni|apne|i)\b|मेरा|मेरी|मेरे|मैं|मुझे|अपना|अपनी/);
  const pron = has(/\b(his|her|their|he|she|unka|unki|unke|uska|uski|inka|inki|woh|wo|vo|unhone|them|same teacher)\b|उनका|उनकी|उसका|उसकी|वह|वो/);
  let { cls, grade } = entClass(q);
  let subject = entSubject(lower);
  let { period, now } = entPeriod(lower);
  let range = entRange(lower);
  const hadEntity = !!(person || cls || grade || subject || period || range);
  if (!person && selfRef) person = u;
  if (!person && pron && BR.ctx.person) person = staffById(BR.ctx.person);
  if (ambiguous && !person) return { text: L(`Which one do you mean? ${ambiguous.map(s => `**${s.name}**`).join(', ')}`, `आप किसकी बात कर रहे हैं? ${ambiguous.map(s => `**${s.name}**`).join(', ')}`), chips: ambiguous.map(s => q.replace(/[?]/g, '') + ' — ' + s.name).slice(0, 3) };

  const week = has(/\bweek\b|weekly|\bhafte\b|\bsaptah\b|pura hafta|whole week|full timetable|सप्ताह|हफ्त/);

  /* intent table: first match wins */
  const intents = [
    ['greet', () => has(/^(hi|hello|hey|namaste|namaskar|good (morning|afternoon|evening)|नमस्ते|नमस्कार)\b/) && lower.split(' ').length <= 3],
    ['thanks', () => has(/^(thanks|thank you|thankyou|shukriya|dhanyavad|dhanyawad|ok thanks|great|nice|धन्यवाद|शुक्रिया)\b/)],
    ['help', () => has(/\bhelp\b|what can you|kya kar sakte|kya puch|how to use|madad|मदद|क्या पूछ|examples?\b/)],
    ['timing', () => has(/\b(timing|timings|what time|kitne baje|kab (shuru|khatam)|when does|start time|end time|bell)\b|बजे|समय क्या/) && has(/period|lunch|school|break|chhutti|पीरियड|स्कूल|लंच|ghanti|घंटी|[1-8]/)],
    ['whatif', () => has(/\b(if|agar|yadi|suppose|what if)\b|अगर|यदि/) && has(/absent|leave|chutti|chhutti|nahi aa|na aa|not come|doesn.?t come|छुट्टी|अनुपस्थित|न आ|नहीं आ/)],
    ['summary', () => has(/summary|briefing|\bbrief\b|overview|daily report|status report|saransh|sar[a]?ansh|aaj ka haal|kya chal raha|what.?s happening|how is today|सारांश|हाल/)],
    ['ttcheck', () => has(/clash|conflict|takrav|takraav|टकराव|double.?book/) || (has(/\bcheck\b|jaanch|जाँच|verify|problem|issue|galti/) && has(/time ?table|samay|समय-सारणी|schedule/))],
    ['free', () => has(/\bfree\b|khali|khaali|खाली|फ्री|available|uplabdh|vacant/)],
    ['subs', () => has(/substitut|arrangement|arrangment|proxy|\bcover(ed|age|s|ing)?\b|uncovered|अरेंजमेंट|प्रॉक्सी|adjustment/)],
    ['workload', () => has(/workload|work load|busiest|lightest|most periods|least periods|sabse (zyada|jyada|kam) period|periods? per week|kitne period|how many periods|karyabhar|कार्यभार|कितने पीरियड/)],
    ['absent', () => has(/absent|anupasthit|अनुपस्थित|not present|gair ?hazir|nahi aa(ye|ya|yi)|नहीं आ|on leave|chh?utti par|छुट्टी पर|who is (out|away)|present/) && !has(/pending|approve|reject|apply|applied|status|lambit|लंबित/)],
    ['leave', () => has(/\bleaves?\b|chh?utti|छुट्टी|avkash|अवकाश|holiday request/)],
    ['requests', () => has(/\bdpps?\b|work ?sheets?|वर्कशीट|requests?\b|anurodh|अनुरोध|overdue|practice problem/)],
    ['classteacher', () => has(/class ?teacher|kaksha.?(shikshak|adhyapak)|कक्षा-शिक्षक|कक्षा शिक्षक/)],
    ['whoteaches', () => has(/who (teaches|takes|is teaching)|kaun padha|kon padha|teaches|padhata|padhati|padhate|teacher (of|for)|ka teacher|ke teacher|कौन पढ़ा|पढ़ाता|पढ़ाती|पढ़ाते|what does .* teach|kya padha/)],
    ['contact', () => has(/phone|mobile|contact|number|नंबर|मोबाइल/) && !!person],
    ['stafflist', () => has(/how many (teachers|staff)|kitne (teacher|shikshak|staff)|list (of )?(all )?(teachers|staff)|all teachers|staff list|sabhi (teacher|shikshak)|teachers? list|कितने शिक्षक|सभी शिक्षक|inactive|who are the|teachers of|shikshak/)],
    ['notices', () => has(/notice|suchna|सूचना|announcement|circular/) && !has(/notification/)],
    ['notifs', () => has(/notification|alerts?\b/)],
    ['audit', () => has(/audit|change log|who changed|kisne (badla|kiya)|history of changes|बदलाव|किसने/)],
    ['counts', () => has(/how many (classes|sections|periods|subjects)|kitni (kaksha|class)|kitne (section|vishay)|total classes|कितनी कक्षा/)],
    ['where', () => !!person && has(/where|kahan|kaha|kidhar|कहाँ|कहां|which class|kis class|kaun si class|किस कक्षा/)],
    ['classnow', () => !!cls && (now || !!period) && !person],
    ['schedule', () => !!person && has(/schedule|time ?table|periods?|classes|routine|\bday\b|\bdin\b|duty|duties|शेड्यूल|समय-सारणी|पीरियड|busy/)],
    ['classtt', () => !!(cls || grade) && has(/time ?table|schedule|routine|periods|समय-सारणी|टाइमटेबल/)],
    ['persononly', () => !!person && !selfRef],
    ['classonly', () => !!(cls || grade)],
    ['subjectinfo', () => !!subject],
    ['periodonly', () => !!period],
    ['dateonly', () => !!range],
    ['selfonly', () => !!person],
  ];
  let intent = (intents.find(([, test]) => test()) || [])[0];
  const bare = ['persononly', 'classonly', 'subjectinfo', 'periodonly', 'dateonly', 'selfonly'].includes(intent);
  // follow-up: "and tomorrow?", "what about 9A?" — reuse the previous kind of question
  const followUp = has(/^(and|aur|what about|how about|or|ya|same for|then|phir|और)\b/) || lower.split(' ').length <= 3;
  if (BR.lastIntent && hadEntity && followUp && bare) {
    const c = BR.ctx, li = BR.lastIntent;
    const newPerson = !!entPerson(lower).person, newClass = !!(cls || grade);
    const fits = (range && ['schedule', 'where', 'free', 'classtt', 'classnow', 'subs', 'absent', 'leave', 'requests', 'summary', 'whatif', 'workload'].includes(li))
      || (newPerson && ['schedule', 'where', 'free', 'subs', 'absent', 'leave', 'requests', 'whatif', 'workload', 'contact', 'whoteaches'].includes(li))
      || (newClass && ['classtt', 'classnow', 'whoteaches', 'classteacher', 'requests', 'subs'].includes(li))
      || (subject && ['whoteaches', 'free', 'requests', 'stafflist'].includes(li))
      || (period && ['free', 'where', 'classnow', 'schedule'].includes(li));
    if (fits) {
      intent = li;
      if (!person && c.person && !newClass) person = staffById(c.person);
      if (!newClass && c.cls && !newPerson) cls = c.cls;
      if (!subject && c.subject && ['whoteaches', 'free'].includes(li)) subject = c.subject;
      if (!period && c.period && !range && ['free', 'where', 'classnow'].includes(li)) period = c.period;
      if (!range && c.range && ['schedule', 'where', 'free', 'classtt', 'classnow', 'absent', 'whatif'].includes(li)) range = c.range;
    }
  }
  intent = { persononly: 'schedule', selfonly: 'schedule', classonly: 'classtt', periodonly: 'free' }[intent] || intent;
  const Rr = range || one(todayISO()), RMr = range || thisMonth();
  const out = runIntent(intent, { q, lower, has, u, mgr, person, cls, grade, subject, period, now, range, R: Rr, RM: RMr, week, selfRef });
  if (intent && !['greet', 'thanks', 'help'].includes(intent)) {
    BR.lastIntent = intent;
    BR.ctx = { person: person ? person.id : BR.ctx.person, cls: cls || BR.ctx.cls, subject: subject || BR.ctx.subject, period: period || null, range: range || null };
  }
  return out;
}

function runIntent(intent, e) {
  const { has, u, mgr, person, cls, grade, subject, period, range, R, RM, week } = e;
  const today = todayISO();
  const noData = (en, hi) => ({ text: L(en, hi) });
  switch (intent) {
    case 'greet': return { text: L(`Namaste ${u.name.split(' ')[0]}! Ask me anything about the school's timetable, absences, substitutions, leave or requests.`, `नमस्ते ${u.name.split(' ')[0]}! समय-सारणी, अनुपस्थिति, अरेंजमेंट, छुट्टी या अनुरोध के बारे में कुछ भी पूछें।`), chips: [L("Today's summary", 'आज का सारांश'), L('What can you do?', 'आप क्या कर सकते हैं?')] };
    case 'thanks': return { text: L('Happy to help.', 'खुशी हुई।') };
    case 'help': return { text: helpText() };
    case 'timing': {
      if (period) return { text: L(`**P${period}** runs **${periodTime(period)}**.`, `**P${period}** का समय **${periodTime(period)}** है।`) };
      const rows = PERIODS.map(p => [`P${p.n}`, periodTime(p.n)]); rows.splice(LUNCH.after, 0, [t('lunch'), `${LUNCH.start}–${LUNCH.end}`]);
      return { text: `${L('School day', 'स्कूल का दिन')} (${DAYS[0]}–${DAYS[DAYS.length - 1]})\n\n` + tbl([t('period'), L('Time', 'समय')], rows) };
    }
    case 'summary': return { text: briefing(R.from), chips: mgr ? [L('Who is free now?', 'अभी कौन खाली है?'), L('Pending leave', 'लंबित छुट्टी'), L('Overdue requests', 'देर से चल रहे अनुरोध')] : [L('My schedule today', 'आज मेरा शेड्यूल'), L('My leave', 'मेरी छुट्टी')] };
    case 'ttcheck': {
      const iss = timetableIssues(), lines = [];
      if (!iss.clashes.length) lines.push(L('✅ **No clashes** — no teacher is in two classes at the same time.', '✅ **कोई टकराव नहीं** — कोई शिक्षक एक साथ दो कक्षाओं में नहीं है।'));
      else lines.push(L(`⚠️ **${iss.clashes.length} clash(es)** found:`, `⚠️ **${iss.clashes.length} टकराव** मिले:`) + '\n\n' + tbl([L('Day', 'दिन'), t('period'), t('teacher'), L('Classes', 'कक्षाएँ')], iss.clashes.slice(0, 30).map(c => [dayName(c.day), `P${c.p}`, nameOf(c.teacher), c.classes.join(' + ')])));
      const emp = Object.entries(iss.empty);
      if (emp.length) lines.push(L('Empty periods per week: ', 'प्रति सप्ताह खाली पीरियड: ') + emp.map(([c, n]) => `${c}: ${n}`).join(', '));
      if (iss.inactive.length) lines.push(L('⚠️ Periods given to removed or inactive staff: ', '⚠️ हटाए गए/निष्क्रिय स्टाफ़ को दिए पीरियड: ') + iss.inactive.map(x => x.split('|')[0] + ' (' + nameOf(x.split('|')[1]) + ')').join(', '));
      const over = teachers().filter(tc => weeklyLoad(tc.id) > 40);
      if (over.length) lines.push(L('Teachers with more than 40 periods a week: ', '40 से ज़्यादा पीरियड वाले शिक्षक: ') + over.map(tc => `${tc.name} (${weeklyLoad(tc.id)})`).join(', '));
      return { text: lines.join('\n\n') };
    }
    case 'whatif': {
      if (!mgr) return { text: L('Only the Admin or Coordinator can plan substitutions. You can see your own substitution periods on My Day.', 'अरेंजमेंट की योजना केवल एडमिन या कोऑर्डिनेटर बना सकते हैं। अपने अरेंजमेंट पीरियड आप “मेरा दिन” पर देख सकते हैं।') };
      if (!person || person.role !== 'teacher') return noData('Tell me which teacher, e.g. "If Rohit Sir is absent tomorrow, who will cover?"', 'बताएँ कौन-से शिक्षक, जैसे "अगर कल Rohit Sir न आएँ तो कौन पढ़ाएगा?"');
      let dt = range ? range.from : (dayIdx(today) < 0 ? addDays(today, 1) : today);
      if (dt < today && has(/\bkal\b|कल/)) dt = addDays(today, 1);
      const scope = has(/first half|pehli pali|morning|subah|पहली पाली/) ? 'first' : has(/second half|doosri pali|dusri pali|after lunch|afternoon|दूसरी पाली/) ? 'second' : 'full';
      const res = tool('preview_substitution', { teacher: person.id, date: dt, scope });
      if (res.note) return { text: L(`${fmtDate(dt)} is ${holidayName(dt) ? 'a holiday (' + holidayName(dt) + ')' : 'a Sunday'} — no school.`, `${fmtDate(dt)} ${holidayName(dt) ? 'अवकाश (' + holidayName(dt) + ')' : 'रविवार'} है।`) };
      if (!res.periodsToCover.length) return { text: L(`**${person.name}** has no classes in that time on ${fmtDate(dt)}, so nothing needs cover.`, `${fmtDate(dt)} को उस समय **${person.name}** की कोई कक्षा नहीं, इसलिए अरेंजमेंट नहीं चाहिए।`) };
      const rows = res.periodsToCover.map(g => [`P${g.period}`, g.class, g.subject, g.suggestions[0] ? `**${g.suggestions[0].teacher}** (${g.suggestions[0].score})` : L('nobody free', 'कोई खाली नहीं'), g.suggestions.slice(1).map(s => s.teacher).join(', ') || '—']);
      return { text: L(`If **${person.name}** is absent on **${fmtDate(dt)}**${scope !== 'full' ? ` (${scope} half)` : ''}, **${rows.length}** period(s) need cover. This is only a preview — nothing was changed.`, `अगर **${person.name}** **${fmtDate(dt)}** को न आएँ, तो **${rows.length}** पीरियड भरने होंगे। यह केवल अनुमान है — कुछ बदला नहीं गया।`) + '\n\n' + tbl([t('period'), t('class'), t('subject'), L('Best substitute', 'सबसे उपयुक्त'), L('Other options', 'अन्य विकल्प')], rows) + '\n\n' + L('To do it for real, use **Mark absent** on the Substitutions screen.', 'असल में करने के लिए अरेंजमेंट स्क्रीन पर **अनुपस्थित दर्ज करें** दबाएँ।') };
    }
    case 'free': {
      const dt = R.from, d = dayIdx(dt);
      if (d < 0) return { text: L(`${fmtDate(dt)} is ${holidayName(dt) ? 'a holiday (' + holidayName(dt) + ')' : 'a Sunday'} — no school.`, `${fmtDate(dt)} ${holidayName(dt) ? 'अवकाश (' + holidayName(dt) + ')' : 'रविवार'} है — स्कूल बंद।`) };
      if (e.now && !period) return { text: L(`No period is running right now (${nowHM()}).`, `अभी (${nowHM()}) कोई पीरियड नहीं चल रहा।`), chips: [L('Who is free in period 5?', 'पीरियड 5 में कौन खाली है?')] };
      if (person && person.role === 'teacher' && !(e.selfRef && has(/who|kaun|कौन/))) {
        if (period) { const du = dutyAt(person.id, dt, period); return { text: du.k === 'free' ? L(`✅ Yes — **${person.name}** is free in **P${period}** on ${fmtDate(dt)}.`, `✅ हाँ — **${person.name}** ${fmtDate(dt)} को **P${period}** में खाली हैं।`) : L(`❌ No — in **P${period}** on ${fmtDate(dt)}, **${person.name}** has: ${du.text}.`, `❌ नहीं — ${fmtDate(dt)} को **P${period}** में **${person.name}**: ${du.text}।`) }; }
        const fp = PERIODS.filter(pp => dutyAt(person.id, dt, pp.n).k === 'free').map(pp => `P${pp.n} (${periodTime(pp.n)})`);
        return { text: fp.length ? L(`**${person.name}** is free on ${fmtDate(dt)} in: ${fp.join(', ')}.`, `**${person.name}** ${fmtDate(dt)} को इन पीरियड में खाली हैं: ${fp.join(', ')}।`) : L(`**${person.name}** has no free period on ${fmtDate(dt)}.`, `${fmtDate(dt)} को **${person.name}** का कोई पीरियड खाली नहीं।`) };
      }
      const res = tool('free_teachers', { date: dt, period: period || undefined });
      const filt = names => (subject ? names.filter(n => { const s = findPerson(n); return s && s.subjects.includes(subject); }) : names);
      if (period) { const names = filt(res.periods[0].free); return { text: names.length ? L(`Free in **P${period}** (${periodTime(period)}) on ${fmtDate(dt)}${subject ? `, ${subjName(subject)} teachers` : ''} — **${names.length}**:\n\n`, `${fmtDate(dt)} को **P${period}** (${periodTime(period)}) में खाली — **${names.length}**:\n\n`) + names.map(n => `- ${n}`).join('\n') : L(`No ${subject ? subjName(subject) + ' teacher' : 'teacher'} is free in P${period} on ${fmtDate(dt)}.`, `${fmtDate(dt)} को P${period} में कोई ${subject ? subjName(subject) + ' ' : ''}शिक्षक खाली नहीं।`) }; }
      return { text: `${L('Free teachers on', 'खाली शिक्षक —')} ${fmtDate(dt)}\n\n` + tbl([t('period'), L('Free', 'खाली')], res.periods.map(x => [`P${x.period}`, filt(x.free).join(', ') || '—'])) };
    }
    case 'subs': {
      const rank = has(/most|highest|maximum|sabse (zyada|jyada|adhik)|top|least|lowest|sabse kam|fair|barabar|ranking|सबसे|count|kitne|how many/);
      if (rank && !(person && has(/how many|kitne|count/))) {
        const res = tool('workload_and_fairness', { from: RM.from, to: RM.to }).teachers;
        const least = has(/least|lowest|sabse kam|सबसे कम/);
        const list = res.slice().sort((a, b) => (least ? a.substitutionsTaken - b.substitutionsTaken : b.substitutionsTaken - a.substitutionsTaken));
        const tot = res.reduce((a, x) => a + x.substitutionsTaken, 0);
        if (!tot) return { text: L(`No published substitutions in ${rlabel(RM)}.`, `${rlabel(RM)} में कोई प्रकाशित अरेंजमेंट नहीं।`) };
        const gap = Math.max(...res.map(x => x.substitutionsTaken)) - Math.min(...res.map(x => x.substitutionsTaken));
        return { text: L(`Substitutions taken, ${rlabel(RM)} — **${tot}** in total, gap between most and least: **${gap}**${gap > 3 ? ' ⚠️ (target is 3 or less)' : ''}`, `अरेंजमेंट, ${rlabel(RM)} — कुल **${tot}**, सबसे ज़्यादा और सबसे कम का अंतर: **${gap}**`) + '\n\n' + tbl([t('teacher'), L('Substitutions', 'अरेंजमेंट'), L('Periods/week', 'पीरियड/सप्ताह')], list.slice(0, 12).map(x => [x.teacher, x.substitutionsTaken, x.periodsPerWeek])) };
      }
      const P = person && person.role === 'teacher' ? person : null;
      const rr = range || (P ? thisMonth() : one(today));
      let rows = tool('substitutions', { from: rr.from, to: rr.to, teacher: P ? P.id : undefined, class: cls || undefined });
      if (has(/not covered|uncovered|unfilled|khali reh|nahi bhar|खाली रह/)) { rows = rows.filter(x => x.substitute === 'NOT COVERED'); if (!rows.length) return { text: L(`✅ Every period is covered (${rlabel(rr)}).`, `✅ सभी पीरियड भर गए हैं (${rlabel(rr)})।`) }; }
      const unseenQ = has(/not seen|unseen|hasn.?t seen|haven.?t seen|nahi dekha|acknowledg|नहीं देखा/);
      if (unseenQ) { rows = rows.filter(x => x.planStatus === 'published' && x.substitute !== 'NOT COVERED' && !x.seen); if (!rows.length) return { text: L(`✅ Everyone has tapped “Seen” (${rlabel(rr)}).`, `✅ सभी ने “देख लिया” दबा दिया है (${rlabel(rr)})।`) }; }
      if (!rows.length) return { text: L(`No substitutions${P ? ` for **${P.name}**` : ''}${cls ? ` in ${cls}` : ''} (${rlabel(rr)}).`, `${rlabel(rr)} में${P ? ` **${P.name}** के लिए` : ''} कोई अरेंजमेंट नहीं।`) };
      const unc = rows.filter(x => x.substitute === 'NOT COVERED').length, draft = rows.some(x => x.planStatus !== 'published');
      const multi = rr.from !== rr.to;
      if (unseenQ) return { text: L(`**${rows.length}** substitution period(s) not yet marked “Seen” (${rlabel(rr)}):`, `**${rows.length}** अरेंजमेंट पीरियड अभी “देख लिया” नहीं हुए (${rlabel(rr)}):`) + '\n\n' + tbl([t('period'), t('class'), L('Substitute', 'अरेंजमेंट')], rows.map(x => [`P${x.period}`, x.class, x.substitute])) };
      return { text: L(`**${rows.length}** substitution period(s)${P ? ` involving **${P.name}**` : ''}, ${rlabel(rr)}${unc ? ` — ⚠️ **${unc} not covered**` : ''}${draft ? ' — plan **not published yet**' : ''}`, `**${rows.length}** अरेंजमेंट पीरियड, ${rlabel(rr)}${unc ? ` — ⚠️ **${unc} खाली**` : ''}${draft ? ' — योजना **अभी प्रकाशित नहीं**' : ''}`) + '\n\n' +
        tbl((multi ? [t('date')] : []).concat([t('period'), t('class'), t('subject'), L('Absent', 'अनुपस्थित'), L('Substitute', 'अरेंजमेंट'), t('seen')]), rows.slice(0, 40).map(x => (multi ? [fmtDate(x.date)] : []).concat([`P${x.period}`, x.class, x.subject, x.absentTeacher, x.substitute === 'NOT COVERED' ? L('⚠️ NOT COVERED', '⚠️ खाली') : x.substitute, x.seen ? '✓' : '—']))) };
    }
    case 'workload': {
      if (person && person.role === 'teacher') {
        const perDay = DAYS.map((d, i) => `${d} ${periodsOnDay(person.id, i)}`).join(', ');
        return { text: L(`**${person.name}** teaches **${weeklyLoad(person.id)}** periods a week (${perDay}).`, `**${person.name}** सप्ताह में **${weeklyLoad(person.id)}** पीरियड पढ़ाते हैं (${perDay})।`) };
      }
      const least = has(/least|lightest|lowest|sabse kam|सबसे कम/);
      const list = teachers().map(tc => ({ n: tc.name, w: weeklyLoad(tc.id), s: tc.subjects.map(subjName).join(', ') })).sort((a, b) => (least ? a.w - b.w : b.w - a.w));
      const avg = (list.reduce((a, x) => a + x.w, 0) / (list.length || 1)).toFixed(1);
      return { text: L(`Teaching periods per week (average **${avg}**, out of ${SLOTS()}):`, `प्रति सप्ताह पीरियड (औसत **${avg}**, ${SLOTS()} में से):`) + '\n\n' + tbl([t('teacher'), L('Periods/week', 'पीरियड/सप्ताह'), L('Subjects', 'विषय')], list.map(x => [x.n, x.w, x.s])) };
    }
    case 'absent': {
      const rows = tool('absences', { from: R.from, to: R.to, teacher: person && person.role === 'teacher' && !e.selfRef ? person.id : undefined });
      if (person && person.role === 'teacher' && !e.selfRef && R.from === R.to) return { text: rows.length ? L(`Yes — **${person.name}** is absent on ${fmtDate(R.from)} (${rows[0].scope}${rows[0].note ? ', ' + rows[0].note : ''}).`, `हाँ — **${person.name}** ${fmtDate(R.from)} को अनुपस्थित हैं।`) : L(`No — **${person.name}** is not marked absent on ${fmtDate(R.from)}.`, `नहीं — **${person.name}** ${fmtDate(R.from)} को अनुपस्थित दर्ज नहीं हैं।`) };
      if (!rows.length) return { text: mgr ? L(`✅ Nobody is marked absent (${rlabel(R)}).`, `✅ कोई अनुपस्थित दर्ज नहीं (${rlabel(R)})।`) : L(`You are not marked absent (${rlabel(R)}). I can only see your own absences.`, `आप अनुपस्थित दर्ज नहीं हैं (${rlabel(R)})। मैं केवल आपकी अपनी अनुपस्थिति देख सकता हूँ।`) };
      const multi = R.from !== R.to, lab = { full: L('Full day', 'पूरा दिन'), first: L('First half', 'पहली पाली'), second: L('Second half', 'दूसरी पाली') };
      return { text: L(`**${new Set(rows.map(x => x.teacher)).size}** teacher(s) absent, ${rlabel(R)}:`, `**${new Set(rows.map(x => x.teacher)).size}** शिक्षक अनुपस्थित, ${rlabel(R)}:`) + '\n\n' + tbl((multi ? [t('date')] : []).concat([t('teacher'), L('When', 'कब'), L('Note', 'नोट')]), rows.slice(0, 40).map(x => (multi ? [fmtDate(x.date)] : []).concat([x.teacher, lab[x.scope] || x.scope, x.note]))), chips: mgr && !multi ? [L('Is everything covered?', 'क्या सब पीरियड भर गए?')] : [] };
    }
    case 'leave': {
      const P = person && person.role === 'teacher' ? person : null;
      if (has(/most|highest|sabse (zyada|jyada)|सबसे ज़्यादा|सबसे ज्यादा|ranking/) && !P) {
        const res = tool('workload_and_fairness', { from: RM.from, to: RM.to }).teachers.filter(x => x.leaveDays > 0).sort((a, b) => b.leaveDays - a.leaveDays);
        return { text: res.length ? L(`Leave days, ${rlabel(RM)}:`, `छुट्टी के दिन, ${rlabel(RM)}:`) + '\n\n' + tbl([t('teacher'), L('Days absent', 'अनुपस्थित दिन')], res.map(x => [x.teacher, x.leaveDays])) : L(`Nobody was absent in ${rlabel(RM)}.`, `${rlabel(RM)} में कोई अनुपस्थित नहीं रहा।`) };
      }
      if (P && has(/how many|kitni|kitne|count|total|days|din|कितनी|कितने/)) {
        const days = new Set(S.absences.filter(a => a.teacherId === P.id && a.date >= RM.from && a.date <= RM.to).map(a => a.date));
        return { text: L(`**${P.name}** was absent on **${days.size}** day(s) in ${rlabel(RM)}${days.size ? ': ' + [...days].sort().map(fmtDate).join(', ') : ''}.`, `**${P.name}** ${rlabel(RM)} में **${days.size}** दिन अनुपस्थित रहे${days.size ? ': ' + [...days].sort().map(fmtDate).join(', ') : ''}।`) };
      }
      const status = has(/pending|waiting|lambit|लंबित|to approve|awaiting|decide/) ? 'pending' : has(/approved|sweekrit|svikrit|स्वीकृत|granted/) ? 'approved' : has(/rejected|asweekrit|अस्वीकृत|denied|refused/) ? 'rejected' : (!P && !range ? 'pending' : undefined);
      const rows = tool('leave_requests', { status, teacher: P ? P.id : undefined, from: range ? range.from : undefined, to: range ? range.to : undefined });
      const what = status ? t(status).toLowerCase() + ' ' : '';
      if (!rows.length) return { text: L(`No ${what}leave requests${P ? ` for **${P.name}**` : ''}${range ? ` (${rlabel(range)})` : ''}.${mgr ? '' : ' I can only see your own.'}`, `कोई ${status ? t(status) + ' ' : ''}छुट्टी आवेदन नहीं${P ? ` (**${P.name}**)` : ''}।`) };
      return { text: L(`**${rows.length}** ${what}leave request(s)${P ? ` of **${P.name}**` : ''}${range ? `, ${rlabel(range)}` : ''}:`, `**${rows.length}** ${status ? t(status) + ' ' : ''}छुट्टी आवेदन${P ? ` — **${P.name}**` : ''}:`) + '\n\n' + tbl([t('teacher'), L('Dates', 'तारीख़'), t('type'), L('Reason', 'कारण'), t('status')], rows.slice(0, 30).map(x => [x.teacher, x.from === x.to ? fmtDate(x.from) : `${fmtDate(x.from)} – ${fmtDate(x.to)}`, x.type, x.reason.length > 70 ? x.reason.slice(0, 70) + '…' : x.reason, t(x.status) + (x.remark ? ` (${x.remark})` : '')])) + (mgr && status === 'pending' ? '\n\n' + L('Approve or reject them on the **Leave** screen.', '**छुट्टी** स्क्रीन पर स्वीकृत या अस्वीकृत करें।') : '') };
    }
    case 'requests': {
      const kind = has(/\bdpps?\b|practice problem/) && !has(/work ?sheet|वर्कशीट/) ? 'dpp' : has(/work ?sheet|वर्कशीट/) && !has(/\bdpps?\b/) ? 'worksheet' : undefined;
      const overdue = has(/overdue|late|delayed|der se|देर|pending for long|missed/);
      const status = has(/waiting for approval|to approve|new requests?|naye|नए|not approved/) ? 'requested' : has(/in progress|kaam jaari|being prepared/) ? 'in_progress' : has(/\bready\b|taiyar|तैयार/) ? 'ready' : has(/delivered|pahuncha|पहुँचा|completed|done/) ? 'delivered' : has(/rejected|अस्वीकृत/) ? 'rejected' : has(/approved|स्वीकृत/) ? 'approved' : undefined;
      const P = person && (person.role === 'teacher' || e.selfRef) ? person : null;
      let rows = tool('dpp_worksheet_requests', { kind, status, class: cls || undefined, teacher: P ? P.id : undefined, overdue_only: overdue, open_only: !status && !overdue && !has(/all|sabhi|सभी|history|total/) });
      if (subject) rows = rows.filter(x => x.subject === SUBJECTS[subject].en);
      const label = (kind === 'dpp' ? 'DPP ' : kind === 'worksheet' ? L('worksheet ', 'वर्कशीट ') : L('DPP/worksheet ', 'DPP/वर्कशीट ')) + (overdue ? L('overdue ', 'देर से ') : '') ;
      if (has(/how many|kitne|count|total|कितने/)) return { text: L(`**${rows.length}** ${label}request(s)${status ? ' with status ' + t(status) : !overdue ? ' open' : ''}${cls ? ` for ${cls}` : ''}${P ? ` by/for ${P.name}` : ''}.`, `**${rows.length}** ${label}अनुरोध${cls ? ` (${cls})` : ''}।`) };
      if (!rows.length) return { text: overdue ? L('✅ Nothing is overdue.', '✅ कुछ भी देर से नहीं है।') : L(`No ${label}requests found${cls ? ` for ${cls}` : ''}${P ? ` for ${P.name}` : ''}.${mgr ? '' : ' I can only see your own.'}`, `कोई ${label}अनुरोध नहीं मिला।`) };
      return { text: L(`**${rows.length}** ${label}request(s)${cls ? ` for ${cls}` : ''}${P ? ` — ${P.name}` : ''}:`, `**${rows.length}** ${label}अनुरोध:`) + '\n\n' + tbl([L('Kind', 'प्रकार'), t('class'), t('subject'), L('What', 'क्या'), L('Needed by', 'कब तक'), t('status'), L('By', 'द्वारा')], rows.slice(0, 30).map(x => [x.kind === 'dpp' ? 'DPP' : t('worksheet'), x.class, x.subject, x.what.length > 60 ? x.what.slice(0, 60) + '…' : x.what, fmtDate(x.neededBy) + (x.overdue ? ' ⚠️' : ''), t(x.status), x.raisedBy])) };
    }
    case 'classteacher': {
      if (cls) return { text: S.classTeachers[cls] ? L(`The class teacher of **${cls}** is **${nameOf(S.classTeachers[cls])}**.`, `**${cls}** के कक्षा-शिक्षक **${nameOf(S.classTeachers[cls])}** हैं।`) : L(`No class teacher is set for ${cls}.`, `${cls} के लिए कक्षा-शिक्षक तय नहीं।`) };
      if (person && !e.selfRef || (e.selfRef && person)) { const mine = Object.entries(S.classTeachers).filter(([, v]) => v === person.id).map(([k]) => k); if (person.role === 'teacher') return { text: mine.length ? L(`**${person.name}** is class teacher of **${mine.join(', ')}**.`, `**${person.name}** **${mine.join(', ')}** के कक्षा-शिक्षक हैं।`) : L(`**${person.name}** is not a class teacher.`, `**${person.name}** किसी कक्षा के कक्षा-शिक्षक नहीं हैं।`) }; }
      return { text: L('Class teachers:', 'कक्षा-शिक्षक:') + '\n\n' + tbl([t('class'), L('Class teacher', 'कक्षा-शिक्षक')], CLASSES.map(c => [c, S.classTeachers[c] ? nameOf(S.classTeachers[c]) : '—'])) };
    }
    case 'whoteaches': {
      if (person && person.role === 'teacher' && !cls && !subject) {
        const rows = tool('who_teaches', {}).filter(x => x.teacher === person.name);
        return { text: rows.length ? L(`**${person.name}** teaches (${weeklyLoad(person.id)} periods a week):`, `**${person.name}** पढ़ाते हैं (सप्ताह में ${weeklyLoad(person.id)} पीरियड):`) + '\n\n' + tbl([t('class'), t('subject'), L('Periods/week', 'पीरियड/सप्ताह')], rows.map(x => [x.class, subjName(subjCode(x.subject) || x.subject), x.periodsPerWeek])) : L(`**${person.name}** has no periods in the timetable.`, `समय-सारणी में **${person.name}** का कोई पीरियड नहीं।`) };
      }
      const classes = cls ? [cls] : grade || null;
      let rows = tool('who_teaches', { subject: subject ? subject : undefined });
      if (classes) rows = rows.filter(x => classes.includes(x.class));
      if (!rows.length) return { text: L('Nothing in the timetable matches that.', 'समय-सारणी में ऐसा कुछ नहीं मिला।') };
      if (rows.length === 1) return { text: L(`**${rows[0].teacher}** teaches ${rows[0].subject} in **${rows[0].class}** (${rows[0].periodsPerWeek} periods a week).`, `**${rows[0].class}** में ${subjName(subject || subjCode(rows[0].subject) || '')} **${rows[0].teacher}** पढ़ाते हैं (सप्ताह में ${rows[0].periodsPerWeek} पीरियड)।`) };
      rows.sort((a, b) => CLASSES.indexOf(a.class) - CLASSES.indexOf(b.class) || b.periodsPerWeek - a.periodsPerWeek);
      return { text: tbl([t('class'), t('subject'), t('teacher'), L('Periods/week', 'पीरियड/सप्ताह')], rows.slice(0, 60).map(x => [x.class, x.subject, x.teacher, x.periodsPerWeek])) };
    }
    case 'contact': {
      if (!mgr) return { text: L('Only the Admin or Coordinator can see mobile numbers.', 'मोबाइल नंबर केवल एडमिन या कोऑर्डिनेटर देख सकते हैं।') };
      if (!person.phone) return { text: L(`No mobile number is saved for **${person.name}** yet.`, `**${person.name}** का मोबाइल नंबर अभी दर्ज नहीं है।`) };
      return { text: L(`**${person.name}**: +91 ${person.phone}${person.active ? '' : ' (inactive)'}`, `**${person.name}**: +91 ${person.phone}`) };
    }
    case 'stafflist': {
      let list = S.staff.filter(s => (has(/inactive|nishkriya|निष्क्रिय/) ? !s.active : s.active));
      if (subject) list = list.filter(s => s.subjects.includes(subject));
      if (!has(/staff/) || subject) list = list.filter(s => s.role === 'teacher' || subject);
      if (has(/how many|kitne|कितने|count/) && !has(/list|names|naam/)) return { text: L(`There are **${list.length}** ${subject ? subjName(subject) + ' ' : ''}${has(/inactive/) ? 'inactive ' : 'active '}${has(/staff/) && !subject ? 'staff members' : 'teachers'}.`, `**${list.length}** ${subject ? subjName(subject) + ' ' : ''}${has(/staff/) && !subject ? 'स्टाफ़ सदस्य' : 'शिक्षक'} हैं।`), chips: [L('List all teachers', 'सभी शिक्षकों की सूची')] };
      if (!list.length) return { text: L('No staff match that.', 'ऐसा कोई स्टाफ़ नहीं।') };
      return { text: `**${list.length}** ${subject ? subjName(subject) + ' ' : ''}${L('staff', 'स्टाफ़')}:\n\n` + tbl([L('Name', 'नाम'), L('Role', 'भूमिका'), L('Subjects', 'विषय'), L('Periods/week', 'पीरियड/सप्ताह'), L('Class teacher', 'कक्षा-शिक्षक')], list.map(s => [s.name, roleLabel(s.role), s.subjects.map(subjName).join(', ') || '—', s.role === 'teacher' ? weeklyLoad(s.id) : '—', Object.entries(S.classTeachers).filter(([, v]) => v === s.id).map(([k]) => k).join(', ') || '—'])) };
    }
    case 'notices': return { text: S.notices.length ? S.notices.slice(0, 8).map(n => `- **${n.title}** (${fmtTime(n.at)}, ${nameOf(n.by)}): ${n.body}`).join('\n') : L('There are no notices.', 'कोई सूचना नहीं।') };
    case 'notifs': { const mine = S.notifications.filter(n => n.userId === u.id).slice(0, 10); return { text: mine.length ? mine.map(n => `- ${S.lang === 'hi' ? n.hi : n.en} (${fmtTime(n.at)})`).join('\n') : L('You have no notifications.', 'आपके लिए कोई सूचना नहीं।') }; }
    case 'audit': {
      if (!mgr) return { text: L('Only the Admin or Coordinator can see the change log.', 'बदलाव रिकॉर्ड केवल एडमिन या कोऑर्डिनेटर देख सकते हैं।') };
      const key = has(/time ?table|समय-सारणी/) ? 'timetable' : has(/leave|छुट्टी/) ? 'leave' : has(/staff|स्टाफ़/) ? 'staff' : has(/substitut|plan|arrangement/) ? 'substitution' : '';
      let rows = S.audit.filter(a => (!key || a.text.toLowerCase().includes(key)) && (!e.person || e.selfRef || a.by === e.person.id) && (!range || (a.at.slice(0, 10) >= range.from && a.at.slice(0, 10) <= range.to))).slice(0, 25);
      return { text: rows.length ? L('Recent changes:', 'हाल के बदलाव:') + '\n\n' + tbl([L('When', 'कब'), L('Who', 'कौन'), L('What', 'क्या')], rows.map(a => [fmtTime(a.at), nameOf(a.by), a.text])) : L('No matching entries in the change log.', 'बदलाव रिकॉर्ड में ऐसा कुछ नहीं।') };
    }
    case 'counts': return { text: L(`The school has **${CLASSES.length}** classes (${CLASSES.join(', ')}), **${teachers().length}** active teachers, **${Object.keys(SUBJECTS).length}** subjects, and **${PERIODS.length}** periods a day, ${DAYS.length} days a week.`, `स्कूल में **${CLASSES.length}** कक्षाएँ (${CLASSES.join(', ')}), **${teachers().length}** सक्रिय शिक्षक, **${Object.keys(SUBJECTS).length}** विषय, और दिन में **${PERIODS.length}** पीरियड हैं।`) };
    case 'where': {
      const dt = R.from, p = period || currentPeriod();
      if (person.role !== 'teacher') return { text: L(`${person.name} is ${roleLabel(person.role)} and has no teaching periods.`, `${person.name} ${roleLabel(person.role)} हैं; उनके पढ़ाने के पीरियड नहीं हैं।`) };
      if (dt === today && !p) return { text: L(`No period is running right now (${nowHM()}). Here is the day:\n\n`, `अभी (${nowHM()}) कोई पीरियड नहीं चल रहा। पूरा दिन:\n\n`) + scheduleAnswer(person, R) };
      if (!p) return { text: scheduleAnswer(person, R) };
      const du = dutyAt(person.id, dt, p);
      return { text: L(`**${person.name}**, ${fmtDate(dt)} **P${p}** (${periodTime(p)}): **${du.text}**.`, `**${person.name}**, ${fmtDate(dt)} **P${p}** (${periodTime(p)}): **${du.text}**।`), chips: [L(`${person.name.split(' ')[0]}'s full day`, `${person.name.split(' ')[0]} का पूरा दिन`)] };
    }
    case 'classnow': {
      const dt = R.from, d = dayIdx(dt), p = period;
      if (d < 0) return { text: L('That day is a Sunday — no school.', 'उस दिन रविवार है।') };
      if (!p) return { text: L(`No period is running right now (${nowHM()}).\n\n`, `अभी (${nowHM()}) कोई पीरियड नहीं चल रहा।\n\n`) + classAnswer(cls, R) };
      const l = lessonAt(cls, d, p); if (!l) return { text: L(`**${cls}** has a free period in P${p} on ${fmtDate(dt)}.`, `${fmtDate(dt)} को P${p} में **${cls}** का खाली पीरियड है।`) };
      const plan = S.plans[dt], sub = plan && (plan.status === 'published' || mgr) && plan.items[`${cls}|${p}`];
      return { text: L(`**${cls}**, ${fmtDate(dt)} **P${p}** (${periodTime(p)}): **${cellSubj(l)}** with **${sub ? (sub.teacherId ? nameOf(sub.teacherId) + ' (substitute for ' + nameOf(l.t) + ')' : 'NOBODY — not covered') : cellTeachers(l)}**.`, `**${cls}**, ${fmtDate(dt)} **P${p}** (${periodTime(p)}): **${cellSubj(l)}** — **${sub ? (sub.teacherId ? nameOf(sub.teacherId) + ' (' + nameOf(l.t) + ' की जगह)' : 'कोई नहीं — खाली') : cellTeachers(l)}**।`) };
    }
    case 'schedule': {
      if (person.role !== 'teacher') return { text: mgr && e.selfRef ? briefing(R.from) : L(`${person.name} is ${roleLabel(person.role)} and has no teaching periods.`, `${person.name} ${roleLabel(person.role)} हैं; उनके पढ़ाने के पीरियड नहीं हैं।`) };
      if (period && !week) { const du = dutyAt(person.id, R.from, period); return { text: L(`**${person.name}**, ${fmtDate(R.from)} **P${period}** (${periodTime(period)}): **${du.text}**.`, `**${person.name}**, ${fmtDate(R.from)} **P${period}**: **${du.text}**।`) }; }
      const f = person.name.split(' ')[0];
      return { text: scheduleAnswer(person, R, week && !(range && range.from === range.to)), chips: [L(`${f}'s whole week`, `${f} का पूरा सप्ताह`), L(`When is ${f} free today?`, `${f} आज कब खाली हैं?`)] };
    }
    case 'classtt': {
      if (!cls && grade) return { text: grade.map(c => classAnswer(c, range, week || !range)).join('\n\n') };
      if (subject) { const rows = tool('who_teaches', { class: cls, subject }); if (rows.length) return { text: L(`In **${cls}**, ${rows[0].subject} is taught by **${rows.map(r => r.teacher).join(', ')}** (${rows.reduce((a, r) => a + r.periodsPerWeek, 0)} periods a week).`, `**${cls}** में ${subjName(subject)} **${rows.map(r => r.teacher).join(', ')}** पढ़ाते हैं।`) }; }
      const single = range && range.from === range.to;
      return { text: classAnswer(cls, single ? range : null, !single), chips: single ? [L(`${cls} whole week`, `${cls} पूरा सप्ताह`)] : [L(`${cls} timetable today`, `${cls} आज का टाइमटेबल`), L(`Class teacher of ${cls}`, `${cls} के कक्षा-शिक्षक`)] };
    }
    case 'subjectinfo': {
      const list = teachers().filter(s => s.subjects.includes(subject));
      const rows = tool('who_teaches', { subject });
      return { text: L(`**${subjName(subject)}** — ${list.length} teacher(s): ${list.map(s => s.name).join(', ') || '—'}`, `**${subjName(subject)}** — ${list.length} शिक्षक: ${list.map(s => s.name).join(', ') || '—'}`) + (rows.length ? '\n\n' + tbl([t('class'), t('teacher'), L('Periods/week', 'पीरियड/सप्ताह')], rows.sort((a, b) => CLASSES.indexOf(a.class) - CLASSES.indexOf(b.class)).map(x => [x.class, x.teacher, x.periodsPerWeek])) : '') };
    }
    case 'dateonly': return { text: briefing(R.from) };
  }
  return { text: L("I didn't understand that. I can answer questions about the school's data — here are some examples.", 'मैं यह नहीं समझ सका। मैं स्कूल के डेटा से जुड़े प्रश्नों के उत्तर दे सकता हूँ — कुछ उदाहरण:') + '\n\n' + helpText().split('\n').slice(2).join('\n') };
}

/* ---------- chat plumbing ---------- */
function askAssistant(q) {
  UI.chat.push({ role: 'user', text: q });
  let out;
  try { out = brainAnswer(q); } catch (err) { out = { text: L('Sorry, I could not work that out. Please ask in a different way.', 'क्षमा करें, यह नहीं निकाल सका। कृपया दूसरे तरीके से पूछें।') }; }
  UI.chat.push({ role: 'assistant', text: out.text, chips: out.chips || [] });
  speak(out.text);
  if (UI.chat.length > 60) UI.chat = UI.chat.slice(-60);
  render();
  const i = document.querySelector('.chat-in input'); if (i && window.innerWidth > 860) i.focus();
}
function newChat() { UI.chat = []; BR.ctx = {}; BR.lastIntent = null; render(); }
function generateDraft(id) {
  const r = S.requests.find(x => x.id === id);
  document.getElementById('draftText').value = templateDraft(r);
  toast(L('Template added — type the questions in', 'टेम्पलेट जोड़ा — प्रश्न लिखें'));
}

function viewAssistant() {
  const mgr = isManager(me());
  const groups = mgr ? [
    [L('Today', 'आज'), [L("Today's summary", 'आज का सारांश'), L('Who is absent today?', 'आज कौन अनुपस्थित है?'), L('Substitutions today', 'आज के अरेंजमेंट'), L('Who is free now?', 'अभी कौन खाली है?')]],
    [L('Staff', 'स्टाफ़'), [L('Who has the most periods?', 'सबसे ज़्यादा पीरियड किसके हैं?'), L('Most substitutions this month', 'इस महीने सबसे ज़्यादा अरेंजमेंट'), L('Pending leave', 'लंबित छुट्टी'), L('Who took the most leave this month?', 'इस महीने सबसे ज़्यादा छुट्टी किसने ली?')]],
    [L('Planning', 'योजना'), [L(`If ${(teachers()[0] || { name: 'a teacher' }).name} is absent tomorrow who will cover?`, `अगर कल ${(teachers()[0] || { name: '' }).name} न आएँ तो कौन पढ़ाएगा?`), L('Check timetable for clashes', 'टाइमटेबल में टकराव जाँचो'), L('Overdue requests', 'देर से चल रहे अनुरोध'), L(`${CLASSES[0]} timetable tomorrow`, `${CLASSES[0]} का कल का टाइमटेबल`)]],
  ] : [
    [L('My day', 'मेरा दिन'), [L('My schedule today', 'आज मेरा शेड्यूल'), L('My schedule tomorrow', 'कल मेरा शेड्यूल'), L('When am I free today?', 'आज मैं कब खाली हूँ?'), L('My substitutions this month', 'इस महीने मेरे अरेंजमेंट')]],
    [L('My requests', 'मेरे अनुरोध'), [L('My leave', 'मेरी छुट्टी'), L('My DPP and worksheet requests', 'मेरे DPP और वर्कशीट अनुरोध'), L('Notices', 'सूचनाएँ')]],
    [L('School', 'स्कूल'), [L('Who is free in period 5?', 'पीरियड 5 में कौन खाली है?'), L(`${CLASSES[0]} timetable today`, `${CLASSES[0]} का आज का टाइमटेबल`), L('Period timings', 'पीरियड का समय')]],
  ];
  const last = UI.chat[UI.chat.length - 1];
  return `<div class="page-head"><h2>${t('assistant')}</h2><div class="btns"><span class="chip st-approved">⚡ ${L('Instant answers from school data', 'स्कूल डेटा से तुरंत उत्तर')}</span><button class="btn small ${V2.voiceOn ? 'primary' : 'ghost'}" data-act="voiceToggle">🔊 ${V2.voiceOn ? L('Speaking answers', 'उत्तर बोल रहा है') : L('Speak answers', 'उत्तर बोलें')}</button>${UI.chat.length ? `<button class="btn small ghost" data-act="newChat">${L('Clear', 'साफ़ करें')}</button>` : ''}</div></div>
    <section class="panel chat">
      <div class="chat-log">${UI.chat.length ? UI.chat.map(m => m.role === 'assistant'
        ? `<div class="msg assistant"><span class="ai-badge">⚡</span><div class="md">${md(m.text)}</div></div>`
        : `<div class="msg user"><div>${esc(m.text)}</div></div>`).join('') + (last && last.chips && last.chips.length ? `<div class="suggest follow">${last.chips.map(s => `<button class="chip-btn" data-act="askSuggest" data-q="${esc(s)}">${esc(s)}</button>`).join('')}</div>` : '')
        : `<div class="empty small">${L('Ask in English, Hindi or Hinglish — or tap a question below.', 'अंग्रेज़ी, हिंदी या Hinglish में पूछें — या नीचे कोई प्रश्न चुनें।')}</div>
           ${groups.map(([name, qs]) => `<div class="qgroup"><b>${esc(name)}</b><div class="suggest">${qs.map(s => `<button class="chip-btn" data-act="askSuggest" data-q="${esc(s)}">${esc(s)}</button>`).join('')}</div></div>`).join('')}`}</div>
      <form data-form="chat" class="chat-in"><input name="q" placeholder="${esc(L('e.g. who is free in period 5 tomorrow?', 'जैसे: कल पीरियड 5 में कौन खाली है?'))}" autocomplete="off"><button type="button" class="icon-btn mic ${V2.listening ? 'on' : ''}" data-act="voice" aria-label="${esc(L('Ask by voice', 'बोलकर पूछें'))}">🎤</button><button class="btn primary">${t('ask')}</button></form>
      <p class="hint">${L('Answers come straight from the school data you are allowed to see. Nothing is sent to any outside AI service, and the assistant never changes anything.', 'उत्तर सीधे उसी स्कूल डेटा से आते हैं जो आप देख सकते हैं। कुछ भी किसी बाहरी AI सेवा को नहीं भेजा जाता, और सहायक कुछ नहीं बदलता।')} <a href="#" data-act="askSuggest" data-q="help">${L('What can I ask?', 'क्या पूछ सकते हैं?')}</a></p>
    </section>`;
}


/* =================================================================
   ATTENDANCE POP-UP
   Opens by itself when the app is opened during check-in hours and the
   teacher has not marked attendance yet, and every time "Mark my attendance" is tapped.
   ================================================================= */
function needsCheckIn(u) {
  if (!u || S.v2Missing || S.offline || u.role === 'admin') return false;
  const date = todayISO();
  if (absentRequestToday(u.id)) return false;   // has said "I am absent today" (or has leave) for the morning
  if (dayIdx(date) < 0 || attStatus(u.id, date) !== 'not_in') return false;
  const cfg = campusCfg(), hm = nowHM();
  return hm >= cfg.open && hm <= cfg.close;
}
function checkInPopupHTML() {
  const u = me(), cfg = campusCfg(), hm = nowHM(), date = todayISO(), d = dayIdx(date);
  const late = hm > cfg.late;
  let first = null;
  if (d >= 0) for (let p = 1; p <= PERIODS.length && !first; p++) { const l = teacherLessonAt(u.id, d, p); if (l) first = { p, l }; }
  return `<div class="stack checkin-pop">
    <p style="font-size:1.15em"><b>👋 ${esc(L(`Good morning, ${u.name}`, `सुप्रभात, ${u.name}`))}</b></p>
    <p>${esc(fmtDate(date))} · ${L('Time now', 'अभी समय')} <b>${hm}</b></p>
    <div class="banner ${late ? 'warn' : 'ok'}">${late
      ? esc(L(`It is after ${cfg.late}, so this will be marked LATE.`, `${cfg.late} के बाद है, इसलिए यह देर (LATE) दर्ज होगी।`))
      : esc(L(`You are on time. Mark before ${cfg.late} to avoid late.`, `आप समय पर हैं। देर से बचने के लिए ${cfg.late} से पहले लगाएँ।`))}</div>
    ${first ? `<p class="muted">${esc(L('Your first period today', 'आज आपका पहला पीरियड'))}: <b>P${first.p}</b> · ${esc(first.l.label)} · ${esc(subjName(first.l.s))}</p>` : ''}
    <p class="hint">${esc(L('Mark only when you are inside the school, from your own phone.', 'हाज़िरी तभी लगाएँ जब आप स्कूल में हों, अपने ही फ़ोन से।'))}</p>
    <div class="row-end"><button class="btn" data-act="checkInLater">${esc(L('Later', 'बाद में'))}</button><button class="btn primary" data-act="checkInGo">✅ ${esc(L('Mark present now', 'अभी उपस्थित दर्ज करें'))}</button></div></div>`;
}
function openCheckInPopup() { openModal(L('Mark your attendance', 'अपनी हाज़िरी लगाएँ'), checkInPopupHTML()); }
function maybeCheckInPopup() {
  const u = me();
  if (!u || needsCheckIn(u)) return;   // the full lock screen is showing instead
  return;
  if (document.getElementById('modal-root').innerHTML) return;
  const last = V2.checkPopAt || 0;
  if (Date.now() - last < 20 * 60 * 1000) return;   // not more than once in 20 minutes
  V2.checkPopAt = Date.now();
  openCheckInPopup();
}
Object.assign(ACTIONS, {
  checkIn: () => { if (V2.checkBusy) return; openCheckInPopup(); },
  checkInGo: () => { closeModal(); doCheck('in'); },
  checkInLater: () => { V2.checkPopAt = Date.now(); closeModal(); },
});
/* full screen shown instead of the app until attendance is marked (during check-in hours) */
function checkInLockHTML(u) {
  const cfg = campusCfg(), hm = nowHM(), date = todayISO(), d = dayIdx(date);
  const late = hm > cfg.late, m = V2.checkMsg;
  let first = null;
  if (d >= 0) for (let p = 1; p <= PERIODS.length && !first; p++) { const l = teacherLessonAt(u.id, d, p); if (l) first = { p, l }; }
  return `<div class="login-wrap"><div class="login-card checkin-lock">
    <img class="login-logo" src="${LOGO_SRC}" alt="MTS logo">
    <h1>${esc(L(`Good morning, ${u.name}`, `सुप्रभात, ${u.name}`))}</h1>
    <p class="muted">${esc(fmtDate(date))} · ${L('Time now', 'अभी समय')} <b>${hm}</b></p>
    <div class="banner ${late ? 'warn' : 'ok'}">${late
      ? esc(L(`It is after ${cfg.late}, so this will be marked LATE.`, `${cfg.late} के बाद है, इसलिए यह देर (LATE) दर्ज होगी।`))
      : esc(L(`You are on time. Mark before ${cfg.late} to avoid late.`, `आप समय पर हैं। देर से बचने के लिए ${cfg.late} से पहले लगाएँ।`))}</div>
    <p><b>${esc(L('Mark your attendance to open the app.', 'ऐप खोलने के लिए पहले अपनी हाज़िरी लगाएँ।'))}</b></p>
    ${first ? `<p class="muted">${esc(L('Your first period today', 'आज आपका पहला पीरियड'))}: <b>P${first.p}</b> · ${esc(first.l.label)} · ${esc(subjName(first.l.s))}</p>` : ''}
    <button class="btn primary big block" data-act="checkInGo" ${V2.checkBusy ? 'disabled' : ''}>✅ ${esc(L('Mark present now', 'अभी उपस्थित दर्ज करें'))}</button>
    ${m ? `<div class="banner ${m.kind === 'ok' ? 'ok' : m.kind === 'bad' ? 'bad' : ''}">${esc(m.text)}</div>` : ''}
    <p class="hint">${esc(L('Mark only when you are inside the school, from your own phone. If it does not work, ask the office to mark you present — the app opens as soon as they do.', 'हाज़िरी तभी लगाएँ जब आप स्कूल में हों, अपने ही फ़ोन से। न लगे तो ऑफ़िस से उपस्थित दर्ज करवाएँ — वे दर्ज करते ही ऐप खुल जाएगा।'))}</p>
    <button class="btn block" data-act="absentTodayDialog" style="margin-top:10px">🙋 ${esc(L('I am absent today', 'मैं आज अनुपस्थित हूँ'))}</button>
    <div class="row-end"><button class="btn ghost small" data-act="toggleLang">${t('language')}</button><button class="btn ghost small" data-act="logout">${t('logout')}</button></div>
  </div></div>`;
}
/* a leave (sent or approved) that covers this morning, so no need to mark present */
function absentRequestToday(tid) {
  const date = todayISO();
  return S.leaves.some(l => l.teacherId === tid && l.from <= date && l.to >= date && (l.status === 'pending' || l.status === 'approved') && (l.scope === 'full' || l.scope === 'first'));
}
function absentTodayHTML() {
  const types = ['Sick', 'Casual', 'Personal', 'Emergency'];
  return `<form data-form="absentToday" class="stack">
    <p>${esc(fmtDate(todayISO()))}</p>
    <label>${esc(L('Reason', 'कारण'))}<select name="type">${types.map(tp => `<option value="${tp}">${esc(leaveTypeName(tp))}</option>`).join('')}</select></label>
    <label>${esc(L('Absent for', 'कब तक अनुपस्थित'))}<select name="scope">
      <option value="full">${esc(L('Full day', 'पूरा दिन'))}</option>
      <option value="first">${esc(L('First half (I will come after lunch)', 'पहला भाग (लंच के बाद आऊँगा/आऊँगी)'))}</option></select></label>
    <label>${esc(L('Short note for the office', 'ऑफ़िस के लिए छोटा संदेश'))}<textarea name="description" rows="3" required placeholder="${esc(L('e.g. fever, doctor visit', 'जैसे बुखार, डॉक्टर के पास'))}"></textarea></label>
    <p class="hint">${esc(L('This goes to the office as a leave request for today. Your classes will be covered when they approve it.', 'यह आज की छुट्टी के आवेदन के रूप में ऑफ़िस जाएगा। स्वीकृत होते ही आपकी कक्षाओं का अरेंजमेंट हो जाएगा।'))}</p>
    <div class="row-end"><button type="button" class="btn" data-act="closeModal">${t('cancel')}</button><button class="btn primary" type="submit">${esc(L('Send to office', 'ऑफ़िस को भेजें'))}</button></div></form>`;
}
Object.assign(ACTIONS, {
  absentTodayDialog: () => openModal(L('Absent today', 'आज अनुपस्थित'), absentTodayHTML()),
});
Object.assign(FORMS, {
  absentToday: (fd) => {
    const u = me(), date = todayISO();
    const description = String(fd.get('description') || '').trim();
    if (!description) { toast(L('Please write a short note', 'कृपया छोटा संदेश लिखें')); return; }
    const scope = fd.get('scope') === 'first' ? 'first' : 'full';
    const type = fd.get('type');
    const lv = { id: uid('lv'), teacherId: u.id, from: date, to: date, scope, periods: [], type, description, status: 'pending', remark: '', createdAt: nowStamp(), sameDay: true };
    S.leaves.push(lv);
    const part = scope === 'first' ? L(' (first half)', ' (पहला भाग)') : '';
    notifyManagers({ en: `⚠️ ${u.name} is absent TODAY${scope === 'first' ? ' (first half)' : ''} — ${type}: ${description}. Please approve so classes get covered.`, hi: `⚠️ ${u.name} आज अनुपस्थित हैं${scope === 'first' ? ' (पहला भाग)' : ''} — ${({ Sick: 'बीमारी', Casual: 'आकस्मिक', Personal: 'निजी', Emergency: 'आपातकालीन' })[type] || type}: ${description}। कृपया स्वीकृत करें ताकि अरेंजमेंट हो सके।` });
    logAudit(u.id, `Reported absent today (${scope}) from the attendance screen`);
    closeModal(); commit(); toast(L('Sent to the office', 'ऑफ़िस को भेजा गया') + part);
  },
});
/* re-check every minute (check-in hours can start or end while the app is open) */
V2.lockWas = null;
setInterval(() => { const u = S && me(); if (!u) return; const now = needsCheckIn(u); if (V2.lockWas !== null && now !== V2.lockWas) render(); V2.lockWas = now; }, 30000);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && S && me() && needsCheckIn(me())) render(); });


/* =================================================================
   PDF EXPORT
   Every PDF: plain white page, black text, school logo and name in bold at the top.
   Pages are drawn on a canvas (so Hindi shows correctly) and saved as a real .pdf file
   that can be downloaded or shared straight to WhatsApp.
   ================================================================= */
const PDF_FONT = '"Segoe UI", Roboto, "Noto Sans", "Noto Sans Devanagari", "Nirmala UI", Mangal, Arial, sans-serif';
let pdfLogoImg = null;
function pdfLogo() {
  if (pdfLogoImg) return pdfLogoImg;
  pdfLogoImg = new Promise(ok => { const im = new Image(); im.onload = () => ok(im); im.onerror = () => ok(null); im.src = LOGO_SRC; });
  return pdfLogoImg;
}
function pdfWrap(ctx, text, maxW) {
  const out = [];
  String(text == null ? '' : text).split('\n').forEach(para => {
    const words = para.split(' ');
    let line = '';
    const pushWord = w => {
      if (ctx.measureText(w).width <= maxW) return w;
      let part = '';                                  // a single word wider than the column: break it
      for (const ch of Array.from(w)) { if (ctx.measureText(part + ch).width > maxW && part) { out.push(part); part = ch; } else part += ch; }
      return part;
    };
    words.forEach(w => {
      const test = line ? line + ' ' + w : w;
      if (ctx.measureText(test).width <= maxW) line = test;
      else { if (line) out.push(line); line = pushWord(w); }
    });
    out.push(line);
  });
  return out;
}
/* docs: [{ title, sub, sections: [{ heading, rows, equalCols, landscape }] }] ; each doc starts on a new page */
async function makePdf(docs, opt = {}) {
  const logo = await pdfLogo();
  const land = !!opt.landscape;
  const W = land ? 2339 : 1654, H = land ? 1654 : 2339, M = 80;      // A4 at 200 dpi
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const ctx = cv.getContext('2d');
  const F = (px, bold) => `${bold ? '700' : '400'} ${px}px ${PDF_FONT}`;
  const pages = []; let page = null, y = 0;
  const HEADER_H = 250, FOOT = 70;
  const newPage = () => { page = []; pages.push(page); y = M + HEADER_H; };
  const room = () => H - M - FOOT - y;
  const stamp = new Date().toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });

  for (const doc of docs) {
    newPage();
    // document title
    ctx.font = F(40, true); const tl = pdfWrap(ctx, doc.title, W - 2 * M);
    page.push(((yy, lines) => c => { c.font = F(40, true); c.textAlign = 'center'; lines.forEach((l, i) => c.fillText(l, W / 2, yy + 40 + i * 50)); })(y, tl));
    y += tl.length * 50 + 10;
    if (doc.sub) { const yy = y; page.push(c => { c.font = F(27); c.textAlign = 'center'; c.fillText(doc.sub, W / 2, yy + 28); }); y += 50; }
    y += 14;
    for (const sec of doc.sections) {
      const rows = sec.rows.filter(Boolean);
      if (!rows.length) continue;
      const head = rows[0], body = rows.slice(1);
      const nc = head.length, avail = W - 2 * M;
      // choose a font size that lets the widest words fit
      let fs = sec.fontSize || 26, widths = null, pad = 12;
      for (; fs >= 11; fs -= 2) {
        ctx.font = F(fs, true);
        pad = Math.max(6, Math.round(fs * 0.45));
        const nat = Array(nc).fill(0), min = Array(nc).fill(0);
        rows.forEach(r => { if (r.span != null) return; r.forEach((v, ci) => String(v == null ? '' : v).split('\n').forEach(seg => {
          nat[ci] = Math.max(nat[ci], ctx.measureText(seg).width + 2 * pad);
          seg.split(' ').forEach(w => { min[ci] = Math.max(min[ci], Math.min(ctx.measureText(w).width, avail * 0.35) + 2 * pad); });
        })); });
        if (sec.equalCols) { const rest = Math.max(...min.slice(1)); for (let i = 1; i < nc; i++) { min[i] = rest; nat[i] = Math.max(...nat.slice(1)); } }
        const sMin = min.reduce((a, b) => a + b, 0), sNat = nat.reduce((a, b) => a + b, 0);
        if (sMin > avail) continue;
        if (sNat <= avail) widths = nat.map(w => w * avail / sNat);
        else { const extra = avail - sMin, grow = nat.map((w, i) => w - min[i]), sg = grow.reduce((a, b) => a + b, 0) || 1; widths = min.map((w, i) => w + extra * grow[i] / sg); }
        if (sec.fitPage && fs > 16) {                         // keep the whole table on one page
          const lhT = Math.round(fs * 1.3);
          let total = 0;
          rows.forEach((r, ri) => { ctx.font = F(fs, ri === 0); total += (r.span != null ? 1 : Math.max(...r.map((v, ci) => pdfWrap(ctx, v, widths[ci] - 2 * pad).length))) * lhT + 2 * pad; });
          if (total > room() - (sec.heading ? 50 : 0)) { widths = null; continue; }
        }
        break;
      }
      if (!widths) { fs = 11; widths = Array(nc).fill(avail / nc); }
      const lh = Math.round(fs * 1.3);
      const layoutRow = (r, bold) => {
        ctx.font = F(fs, bold);
        if (r.span != null) return { span: r.span, lines: [pdfWrap(ctx, r.span, avail - 2 * pad)], h: lh + 2 * pad };
        const lines = r.map((v, ci) => pdfWrap(ctx, v, widths[ci] - 2 * pad));
        return { lines, h: Math.max(...lines.map(l => l.length)) * lh + 2 * pad };
      };
      const hRow = layoutRow(head, true);
      const drawRow = (lr, yy, bold, isHead) => c => {
        c.lineWidth = isHead ? 3 : 1.5; c.strokeStyle = '#000'; c.font = F(fs, bold); c.textAlign = 'left';
        if (lr.span != null) {
          c.strokeRect(M, yy, avail, lr.h);
          c.font = F(fs, true); c.textAlign = 'center'; c.fillText(lr.lines[0][0] || '', M + avail / 2, yy + pad + fs); return;
        }
        let x = M;
        lr.lines.forEach((ls, ci) => {
          c.strokeRect(x, yy, widths[ci], lr.h);
          const firstColBold = ci === 0 && sec.firstColBold;
          c.font = F(fs, bold || firstColBold);
          ls.forEach((l, li) => { c.font = F(fs, bold || firstColBold || (sec.boldFirstLine && li === 0)); c.fillText(l, x + pad, yy + pad + fs + li * lh); });
          x += widths[ci];
        });
      };
      if (sec.heading) {
        if (room() < 60 + hRow.h + lh * 2 + 2 * pad) newPage();
        const yy = y; page.push(c => { c.font = F(30, true); c.textAlign = 'left'; c.fillText(sec.heading, M, yy + 32); }); y += 50;
      }
      if (room() < hRow.h + lh + 2 * pad) newPage();
      page.push(drawRow(hRow, y, true, true)); y += hRow.h;
      for (const r of body) {
        const lr = layoutRow(r, false);
        if (lr.h > room()) { newPage(); page.push(drawRow(hRow, y, true, true)); y += hRow.h; }
        page.push(drawRow(lr, y, false, false)); y += lr.h;
      }
      y += 36;
    }
    if (doc.note) { ctx.font = F(24); const nl = pdfWrap(ctx, doc.note, W - 2 * M); if (room() < nl.length * 32) newPage(); const yy = y; page.push(c => { c.font = F(24); c.textAlign = 'left'; nl.forEach((l, i) => c.fillText(l, M, yy + 26 + i * 32)); }); y += nl.length * 32; }
  }

  // draw every page: white background, black ink, logo + bold school name, footer.
  // Pages are stored as sharp black-and-white images (small files); the logo is added in colour on top.
  const Z = 1.5;                                             // draw at 300 dpi
  const out = document.createElement('canvas'); out.width = Math.round(W * Z); out.height = Math.round(H * Z);
  const o = out.getContext('2d');
  const bw = 'CompressionStream' in window;
  const LG = 170, logoH = LG, logoW = logo ? LG * (logo.width / logo.height) : 0;
  o.font = F(64, true); const nameW = o.measureText(SCHOOL.name).width;
  const x0 = (W - ((logo ? logoW + 34 : 0) + nameW)) / 2, logoBox = { x: x0, y: M - 10, w: logoW, h: logoH };
  let logoJpg = null;
  if (logo && bw) {
    const lc = document.createElement('canvas'); lc.width = Math.round(logoW * Z); lc.height = Math.round(logoH * Z);
    const lx = lc.getContext('2d'); lx.fillStyle = '#fff'; lx.fillRect(0, 0, lc.width, lc.height); lx.drawImage(logo, 0, 0, lc.width, lc.height);
    logoJpg = { bytes: b64bytes(lc.toDataURL('image/jpeg', 0.9)), w: lc.width, h: lc.height };
  }
  const imgs = [];
  for (let i = 0; i < pages.length; i++) {
    o.setTransform(1, 0, 0, 1, 0, 0);
    o.fillStyle = '#fff'; o.fillRect(0, 0, out.width, out.height);
    o.setTransform(Z, 0, 0, Z, 0, 0);
    o.fillStyle = '#000'; o.strokeStyle = '#000'; o.textBaseline = 'alphabetic';
    if (logo && !bw) o.drawImage(logo, logoBox.x, logoBox.y, logoBox.w, logoBox.h);
    const tx = x0 + (logo ? logoW + 34 : 0);
    o.textAlign = 'left'; o.font = F(64, true); o.fillText(SCHOOL.name, tx, M + 78);
    o.font = F(30); o.fillText(SCHOOL.place, tx + 2, M + 126);
    o.lineWidth = 4; o.beginPath(); o.moveTo(M, M + HEADER_H - 50); o.lineTo(W - M, M + HEADER_H - 50); o.stroke();
    pages[i].forEach(fn => { o.fillStyle = '#000'; fn(o); });
    o.fillStyle = '#000'; o.font = F(22); o.textAlign = 'center';
    o.fillText(`${SCHOOL.name} · Made on ${stamp} · Page ${i + 1} / ${pages.length}`, W / 2, H - M + 10);
    if (bw) imgs.push({ kind: 'bw', w: out.width, h: out.height, bytes: await pdfBitmap(o, out.width, out.height) });
    else imgs.push({ kind: 'jpg', w: out.width, h: out.height, bytes: b64bytes(out.toDataURL('image/jpeg', 0.75)) });
    await new Promise(r => setTimeout(r, 0));                 // keep the phone responsive
  }
  return pdfAssemble(imgs, land, logoJpg, logoJpg && { x: logoBox.x / W, y: logoBox.y / H, w: logoBox.w / W, h: logoBox.h / H });
}
function b64bytes(dataUrl) { const bin = atob(dataUrl.split(',')[1]); const u8 = new Uint8Array(bin.length); for (let k = 0; k < bin.length; k++) u8[k] = bin.charCodeAt(k); return u8; }
/* canvas -> 1-bit black/white rows -> zlib (PDF FlateDecode) */
async function pdfBitmap(ctx, w, h) {
  const rowBytes = Math.ceil(w / 8), packed = new Uint8Array(rowBytes * h);
  const STEP = 200;
  for (let y0 = 0; y0 < h; y0 += STEP) {
    const hh = Math.min(STEP, h - y0), px = ctx.getImageData(0, y0, w, hh).data;
    for (let y = 0; y < hh; y++) {
      const base = (y0 + y) * rowBytes;
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        if ((px[i] * 3 + px[i + 1] * 6 + px[i + 2]) / 10 >= 150) packed[base + (x >> 3)] |= 128 >> (x & 7);   // 1 = white
      }
    }
  }
  const zs = new Blob([packed]).stream().pipeThrough(new CompressionStream('deflate'));
  return new Uint8Array(await new Response(zs).arrayBuffer());
}
function pdfAssemble(imgs, land, logoJpg, lb) {
  const pw = land ? 841.89 : 595.28, ph = land ? 595.28 : 841.89;
  const enc = new TextEncoder(), parts = [], offs = [];
  let len = 0;
  const push = x => { const b = typeof x === 'string' ? enc.encode(x) : x; parts.push(b); len += b.length; };
  push(new Uint8Array([37, 80, 68, 70, 45, 49, 46, 52, 10, 37, 226, 227, 207, 211, 10]));   // %PDF-1.4 + binary marker
  const obj = (id, str, bytes, tail) => { offs[id] = len; push(`${id} 0 obj\n${str}`); if (bytes) { push(bytes); push(tail); } push('\nendobj\n'); };
  const n = imgs.length, LOGO = 3, first = 4;
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, `<< /Type /Pages /Count ${n} /Kids [${imgs.map((_, i) => `${first + i * 3} 0 R`).join(' ')}] >>`);
  if (logoJpg) obj(LOGO, `<< /Type /XObject /Subtype /Image /Width ${logoJpg.w} /Height ${logoJpg.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${logoJpg.bytes.length} >>\nstream\n`, logoJpg.bytes, '\nendstream');
  else obj(LOGO, '<< >>');
  imgs.forEach((im, i) => {
    const pg = first + i * 3, io = pg + 1, ct = pg + 2;
    obj(pg, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pw} ${ph}] /Resources << /XObject << /Im0 ${io} 0 R${logoJpg ? ` /Lg ${LOGO} 0 R` : ''} >> >> /Contents ${ct} 0 R >>`);
    const dict = im.kind === 'bw'
      ? `/ColorSpace /DeviceGray /BitsPerComponent 1 /Filter /FlateDecode`
      : `/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode`;
    obj(io, `<< /Type /XObject /Subtype /Image /Width ${im.w} /Height ${im.h} ${dict} /Length ${im.bytes.length} >>\nstream\n`, im.bytes, '\nendstream');
    let c = `q ${pw} 0 0 ${ph} 0 0 cm /Im0 Do Q`;
    if (logoJpg) { const f = v => v.toFixed(2); c += ` q ${f(lb.w * pw)} 0 0 ${f(lb.h * ph)} ${f(lb.x * pw)} ${f(ph - (lb.y + lb.h) * ph)} cm /Lg Do Q`; }
    obj(ct, `<< /Length ${c.length} >>\nstream\n${c}\nendstream`);
  });
  const total = first + n * 3 - 1, xref = len;
  push(`xref\n0 ${total + 1}\n0000000000 65535 f \n` + offs.slice(1, total + 1).map(o => String(o).padStart(10, '0') + ' 00000 n \n').join(''));
  push(`trailer\n<< /Size ${total + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
  return new Blob(parts, { type: 'application/pdf' });
}
const pdfName = s => String(s).replace(/[^\wऀ-ॿ-]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
async function savePdf(docs, filename, title, opt) {
  if (V2.pdfBusy) return;
  V2.pdfBusy = true; toast(L('Making PDF…', 'PDF बन रही है…'));
  try { const blob = await makePdf(docs, opt); await deliverFile(blob, filename, title); }
  catch (e) { console.error(e); toast(L('Could not make the PDF', 'PDF नहीं बन सकी')); }
  finally { V2.pdfBusy = false; }
}

/* ---------- what goes into each PDF ---------- */
const pdfDayHead = () => [t('period'), ...DAYS.map((d, i) => (S.lang === 'hi' ? DAYS_HI[i] : DAYS_LONG[i]))];
function pdfTimetableRows(cell) {
  const rows = [pdfDayHead()];
  PERIODS.forEach(pp => {
    rows.push([`P${pp.n}\n${pp.start}–${pp.end}`, ...DAYS.map((_, d) => cell(d, pp.n))]);
    if (pp.n === LUNCH.after) { const r = []; r.span = `${t('lunch').toUpperCase()}  ${LUNCH.start}–${LUNCH.end}`; rows.push(r); }
  });
  return rows;
}
function pdfClassDoc(cls) {
  const ct = S.classTeachers && S.classTeachers[cls];
  return {
    title: `${L('Class timetable', 'कक्षा समय-सारणी')} — ${cls}`,
    sub: ct ? `${L('Class teacher', 'कक्षा-शिक्षक')}: ${nameOf(ct)}` : '',
    sections: [{ rows: pdfTimetableRows((d, p) => { const l = lessonAt(cls, d, p); return l ? `${cellSubj(l)}\n${cellTeachers(l)}${l.j ? '\n(' + L('combined', 'संयुक्त') + ')' : ''}` : '—'; }), equalCols: true, firstColBold: true, boldFirstLine: true, fontSize: 31, fitPage: true }],
  };
}
function pdfTeacherDoc(tid) {
  const ctOf = Object.entries(S.classTeachers || {}).filter(([, v]) => v === tid).map(([k]) => k);
  return {
    title: `${L('Teacher timetable', 'शिक्षक समय-सारणी')} — ${nameOf(tid)}`,
    sub: `${L('Periods a week', 'साप्ताहिक पीरियड')}: ${weeklyLoad(tid)}${ctOf.length ? ' · ' + L('Class teacher of', 'कक्षा-शिक्षक') + ' ' + ctOf.join(', ') : ''}`,
    sections: [{ rows: pdfTimetableRows((d, p) => { const l = teacherLessonAt(tid, d, p); return l ? `${l.label}\n${subjName(l.s)}` : t('free'); }), equalCols: true, firstColBold: true, boldFirstLine: true, fontSize: 31, fitPage: true }],
  };
}
function pdfArrangementDoc(date) {
  const plan = S.plans[date];
  const rows = [[t('period'), t('class'), t('subject'), L('Absent teacher', 'अनुपस्थित शिक्षक'), L('Substitute', 'अरेंजमेंट शिक्षक'), L('Signature', 'हस्ताक्षर')]];
  if (plan) Object.values(plan.items).sort((a, b) => a.p - b.p || CLASSES.indexOf(a.cls) - CLASSES.indexOf(b.cls))
    .forEach(i => rows.push([`P${i.p}\n${periodTime(i.p)}`, i.cls, subjName(i.subject), nameOf(i.absentId), i.teacherId ? nameOf(i.teacherId) : L('NOT COVERED', 'खाली'), '']));
  const absent = absencesOn(date).map(a => `${nameOf(a.teacherId)} (${absenceLabel(a)})`).join(', ');
  return {
    title: `${L('Arrangement sheet', 'अरेंजमेंट शीट')} — ${fmtDate(date)}`,
    sub: plan ? (plan.status === 'published' ? L('Published', 'प्रकाशित') : L('Draft — not yet published', 'ड्राफ़्ट — अभी प्रकाशित नहीं')) : L('No arrangements for this day', 'इस दिन कोई अरेंजमेंट नहीं'),
    sections: [{ rows, firstColBold: true }],
    note: absent ? `${L('Absent today', 'आज अनुपस्थित')}: ${absent}` : '',
  };
}

Object.assign(ACTIONS, {
  pdfTimetable: () => {
    if (UI.ttMode === 'teacher') savePdf([pdfTeacherDoc(UI.ttTeacher)], `MTS-Timetable-${pdfName(nameOf(UI.ttTeacher))}.pdf`, nameOf(UI.ttTeacher), { landscape: true });
    else savePdf([pdfClassDoc(UI.ttClass)], `MTS-Timetable-${pdfName(UI.ttClass)}.pdf`, UI.ttClass, { landscape: true });
  },
  pdfTimetableAll: () => {
    if (UI.ttMode === 'teacher') savePdf(teachers().filter(x => weeklyLoad(x.id) > 0).sort((a, b) => a.name.localeCompare(b.name)).map(x => pdfTeacherDoc(x.id)), 'MTS-Timetable-All-Teachers.pdf', L('All teachers', 'सभी शिक्षक'), { landscape: true });
    else savePdf(CLASSES.map(pdfClassDoc), 'MTS-Timetable-All-Classes.pdf', L('All classes', 'सभी कक्षाएँ'), { landscape: true });
  },
  printSheet: () => savePdf([pdfArrangementDoc(UI.date)], `MTS-Arrangement-${UI.date}.pdf`, L('Arrangement sheet', 'अरेंजमेंट शीट')),
  printAttendance: () => { const ym = UI.reportMonth || todayISO().slice(0, 7); const sh = attendanceSheets(ym); savePdf([{ title: `${L('Staff attendance', 'स्टाफ़ हाज़िरी')} — ${ym}`, sections: [{ heading: sh[0].name, rows: sh[0].rows, firstColBold: true }, { heading: sh[1].name, rows: sh[1].rows, firstColBold: true, fontSize: 20 }] }], `MTS-Staff-Attendance-${ym}.pdf`, ym, { landscape: true }); },
  printSalary: () => { const ym = UI.reportMonth || todayISO().slice(0, 7); const sh = salarySheets(ym); savePdf([{ title: `${L('Salary-ready attendance', 'वेतन हेतु हाज़िरी')} — ${ym}`, sections: [{ heading: sh[0].name, rows: sh[0].rows, firstColBold: true }, { heading: sh[2].name, rows: sh[2].rows, firstColBold: true }] }], `MTS-Salary-Attendance-${ym}.pdf`, ym, { landscape: true }); },
  examPrint: el => { const e = examById(el.dataset.id); savePdf([{ title: `${e.name} — ${L('Invigilation chart', 'निरीक्षण चार्ट')}`, sections: [{ rows: examSheet(e).rows, firstColBold: true }] }], `MTS-${pdfName(e.name)}-Duties.pdf`, e.name, { landscape: true }); },
  printReport: () => { const ym = UI.reportMonth || todayISO().slice(0, 7); savePdf([{ title: `${L('Monthly report', 'मासिक रिपोर्ट')} — ${ym}`, sections: [{ heading: L('Attendance', 'हाज़िरी'), rows: attendanceSheets(ym)[0].rows, firstColBold: true }, { heading: L('Workload', 'कार्यभार'), rows: workloadSheet(ym).rows, firstColBold: true }, { heading: L('Leave left', 'शेष छुट्टी'), rows: leaveSheets()[0].rows, firstColBold: true }] }], `MTS-Monthly-Report-${ym}.pdf`, ym, { landscape: true }); },
});


/* Files given out by the app (PDF, Excel, copied report) are always in English, whatever language the app shows. */
function inEnglish(fn) { const keep = S.lang; S.lang = 'en'; try { return fn(); } finally { S.lang = keep; } }
Object.keys(ACTIONS).forEach(name => {
  const fn = ACTIONS[name], src = String(fn);
  if (/savePdf\(|deliverFile\(|makeXlsx\(/.test(src) || name === 'copyReport') ACTIONS[name] = el => inEnglish(() => fn(el));
});

boot();
